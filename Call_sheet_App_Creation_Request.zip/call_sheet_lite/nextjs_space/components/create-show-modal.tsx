
"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc-client";
import { toast } from "sonner";
import { useSession } from "next-auth/react";
import { Loader2 } from "lucide-react";

interface CreateShowModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function CreateShowModal({ isOpen, onClose, onSuccess }: CreateShowModalProps) {
  const { data: session } = useSession() || {};
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<"Pre-Production" | "Shooting" | "Wrapped">("Pre-Production");
  const [companyId, setCompanyId] = useState("");

  const { data: companies, isLoading: isLoadingCompanies } = trpc.companies.list.useQuery(undefined, {
    enabled: isOpen,
  });

  const createShowMutation = trpc.shows.create.useMutation({
    onSuccess: () => {
      const message = session?.user?.role === "DEVELOPER" 
        ? "Show created and approved successfully!" 
        : "Show created! Pending developer approval.";
      toast.success(message);
      onSuccess();
      setTitle("");
      setDescription("");
      setStatus("Pre-Production");
      setCompanyId("");
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create show");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!companyId) {
      toast.error("Please select a company");
      return;
    }

    createShowMutation.mutate({
      title,
      description,
      status,
      companyId,
    });
  };

  // Filter companies based on user role - Admins can only see their company
  const userCompanies = session?.user?.role === "ADMIN" && (session.user as any).companyId
    ? companies?.filter(c => c.id === (session.user as any).companyId)
    : companies;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="border-gray-800 bg-gray-900 text-white sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">Create New Show</DialogTitle>
          <DialogDescription className="text-gray-400">
            Add a new production show. {session?.user?.role !== "DEVELOPER" && "Requires developer approval."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="border-gray-700 bg-gray-800 text-white"
              placeholder="Enter show title"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="company">Company *</Label>
            {isLoadingCompanies ? (
              <div className="flex items-center justify-center py-3">
                <Loader2 className="h-5 w-5 animate-spin text-amber-500" />
              </div>
            ) : (
              <Select value={companyId} onValueChange={setCompanyId}>
                <SelectTrigger className="border-gray-700 bg-gray-800 text-white">
                  <SelectValue placeholder="Select a company" />
                </SelectTrigger>
                <SelectContent className="border-gray-700 bg-gray-800 text-white">
                  {userCompanies && userCompanies.length > 0 ? (
                    userCompanies.map((company) => (
                      <SelectItem key={company.id} value={company.id}>
                        {company.name}
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-2 text-sm text-gray-400">No companies available</div>
                  )}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="border-gray-700 bg-gray-800 text-white"
              placeholder="Enter show description"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Production Status</Label>
            <Select value={status} onValueChange={(value: any) => setStatus(value)}>
              <SelectTrigger className="border-gray-700 bg-gray-800 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-gray-700 bg-gray-800 text-white">
                <SelectItem value="Pre-Production">Pre-Production</SelectItem>
                <SelectItem value="Shooting">Shooting</SelectItem>
                <SelectItem value="Wrapped">Wrapped</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-gray-700 bg-gray-800 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createShowMutation.isPending || !title || !companyId}
              className="bg-amber-500 text-black hover:bg-amber-600"
            >
              {createShowMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create Show
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
