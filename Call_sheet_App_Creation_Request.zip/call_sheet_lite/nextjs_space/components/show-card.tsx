
"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Film, Clock, Edit, Trash2 } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";
import { useSession } from "next-auth/react";

interface ShowCardProps {
  show: {
    id: string;
    title: string;
    description: string | null;
    status: string;
    creatorId?: string;
    _count?: {
      scenes: number;
    };
  };
  onEdit?: (show: ShowCardProps['show']) => void;
  onDelete?: (showId: string) => void;
}

export function ShowCard({ show, onEdit, onDelete }: ShowCardProps) {
  const { data: session } = useSession() || {};
  const statusColors = {
    "Pre-Production": "bg-blue-500/20 text-blue-400 border-blue-500/30",
    "Shooting": "bg-amber-500/20 text-amber-400 border-amber-500/30",
    "Wrapped": "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  };

  const statusColor = statusColors[show.status as keyof typeof statusColors] || statusColors["Pre-Production"];

  // Check if user can manage this show (DEVELOPER can manage all, others can manage their own)
  const canManage = session?.user?.role === "DEVELOPER" || 
                    session?.user?.id === show.creatorId;

  const handleEdit = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onEdit?.(show);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onDelete?.(show.id);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -4 }}
    >
      <Link href={`/shows/${show.id}`}>
        <Card className="group relative overflow-hidden border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 transition-all hover:border-amber-500/50 hover:shadow-lg hover:shadow-amber-500/10">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
          
          <div className="relative">
            <div className="mb-4 flex items-start justify-between gap-2">
              <div className="flex items-center space-x-2 flex-1 min-w-0">
                <Film className="h-5 w-5 text-amber-500 flex-shrink-0" />
                <h3 className="text-xl font-semibold text-white truncate">{show.title}</h3>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Badge className={`${statusColor} border`}>
                  {show.status}
                </Badge>
                {canManage && onEdit && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleEdit}
                    className="h-8 w-8 text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                )}
                {canManage && onDelete && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleDelete}
                    className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>

            {show.description && (
              <p className="mb-4 line-clamp-2 text-sm text-gray-400">
                {show.description}
              </p>
            )}

            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Clock className="h-4 w-4" />
              <span>{show._count?.scenes || 0} scenes</span>
            </div>
          </div>
        </Card>
      </Link>
    </motion.div>
  );
}
