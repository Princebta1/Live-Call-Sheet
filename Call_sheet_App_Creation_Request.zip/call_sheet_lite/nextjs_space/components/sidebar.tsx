"use client";

import { useSession } from "next-auth/react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  LayoutDashboard, 
  Clapperboard, 
  Users, 
  Building2, 
  ClipboardCheck,
  Film,
  ClipboardList,
  Calendar,
  Megaphone,
  Inbox,
  User,
  MessageCircle,
  UserPlus,
  Shield
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: string[];
}

const navItems: NavItem[] = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
    roles: ["DEVELOPER", "ADMIN", "PRODUCTION_ADMIN", "CREW", "ACTOR"],
  },
  {
    label: "Shows",
    href: "/shows",
    icon: Clapperboard,
    roles: ["DEVELOPER", "ADMIN", "PRODUCTION_ADMIN", "CREW", "ACTOR"],
  },
  {
    label: "Messages",
    href: "/conversations",
    icon: MessageCircle,
    roles: ["DEVELOPER", "ADMIN", "PRODUCTION_ADMIN", "CREW", "ACTOR"],
  },
  {
    label: "Users",
    href: "/admin/users",
    icon: Users,
    roles: ["DEVELOPER", "ADMIN", "PRODUCTION_ADMIN"],
  },
  {
    label: "Companies",
    href: "/admin/companies",
    icon: Building2,
    roles: ["DEVELOPER", "ADMIN"],
  },
  {
    label: "Show Approvals",
    href: "/admin/approvals",
    icon: ClipboardCheck,
    roles: ["DEVELOPER"],
  },
  {
    label: "User Approvals",
    href: "/admin/user-approvals",
    icon: UserPlus,
    roles: ["DEVELOPER"],
  },
  {
    label: "Roles & Permissions",
    href: "/admin/roles",
    icon: Shield,
    roles: ["DEVELOPER", "ADMIN", "PRODUCTION_ADMIN"],
  },
  {
    label: "Call Sheet",
    href: "/actor/call-sheet",
    icon: ClipboardList,
    roles: ["ACTOR"],
  },
  {
    label: "My Scenes",
    href: "/actor/my-scenes",
    icon: Film,
    roles: ["ACTOR"],
  },
  {
    label: "Calendar",
    href: "/actor/calendar",
    icon: Calendar,
    roles: ["ACTOR"],
  },
  {
    label: "Announcements",
    href: "/actor/announcements",
    icon: Megaphone,
    roles: ["ACTOR"],
  },
  {
    label: "Inbox",
    href: "/actor/inbox",
    icon: Inbox,
    roles: ["ACTOR"],
  },
  {
    label: "Profile",
    href: "/actor/profile",
    icon: User,
    roles: ["ACTOR"],
  },
];

// Desktop Sidebar Component
function DesktopSidebar() {
  const { data: session, status } = useSession() || {};
  const pathname = usePathname();

  if (status !== "authenticated" || !session?.user) {
    return null;
  }

  if (pathname?.startsWith("/auth/")) {
    return null;
  }

  const userRole = session.user.role || "CREW";
  const filteredNavItems = navItems.filter((item) =>
    item.roles.includes(userRole)
  );

  return (
    <aside className="hidden md:flex fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-gray-900/95 border-r border-gray-800 transition-all duration-300 z-30">
      <div className="flex flex-col w-full">
        <nav className="flex-1 overflow-y-auto py-4">
          {filteredNavItems.map((item) => {
            const isActive = pathname === item.href || pathname?.startsWith(item.href + "/");
            const Icon = item.icon;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-all",
                  isActive
                    ? "bg-amber-600 text-white"
                    : "text-gray-300 hover:bg-gray-800 hover:text-white"
                )}
              >
                <Icon className="h-5 w-5 flex-shrink-0" />
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}

// Mobile Bottom Navigation Component (Floating)
function MobileBottomNav() {
  const { data: session, status } = useSession() || {};
  const pathname = usePathname();

  if (status !== "authenticated" || !session?.user) {
    return null;
  }

  if (pathname?.startsWith("/auth/")) {
    return null;
  }

  const userRole = session.user.role || "CREW";
  // Get top 5 most relevant items for bottom nav
  const filteredNavItems = navItems
    .filter((item) => item.roles.includes(userRole))
    .slice(0, 5);

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 pointer-events-none pb-safe">
      <div className="px-4 pb-4">
        <div className="bg-gray-900/95 backdrop-blur-md border border-gray-800 rounded-2xl shadow-2xl pointer-events-auto">
          <div className="flex items-center justify-around px-2 py-3">
            {filteredNavItems.map((item) => {
              const isActive = pathname === item.href || pathname?.startsWith(item.href + "/");
              const Icon = item.icon;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-lg transition-all min-w-[60px]",
                    isActive
                      ? "bg-amber-600 text-white"
                      : "text-gray-400 hover:text-white active:bg-gray-800"
                  )}
                >
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  <span className="text-[10px] font-medium truncate max-w-full">
                    {item.label}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}

// Main Sidebar Export
export default function Sidebar() {
  return (
    <>
      <MobileBottomNav />
      <DesktopSidebar />
    </>
  );
}
