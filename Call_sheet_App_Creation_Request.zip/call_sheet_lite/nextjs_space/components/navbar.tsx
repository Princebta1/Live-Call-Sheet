
"use client";

import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import Image from "next/image";
import { useRouter, usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Film, LogOut, User, ArrowLeft } from "lucide-react";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const { data: session } = useSession() || {};
  const router = useRouter();
  const pathname = usePathname();

  const roleColors = {
    DEVELOPER: "bg-red-500/10 text-red-400 border-red-500/30",
    PRODUCTION_ADMIN: "bg-blue-500/10 text-blue-400 border-blue-500/30",
    ADMIN: "bg-purple-500/10 text-purple-400 border-purple-500/30",
    CREW: "bg-gray-500/10 text-gray-400 border-gray-500/30",
    ACTOR: "bg-amber-500/10 text-amber-400 border-amber-500/30",
  };

  const roleLabels = {
    DEVELOPER: "Developer",
    PRODUCTION_ADMIN: "Production Admin",
    ADMIN: "Admin",
    CREW: "Crew",
    ACTOR: "Actor",
  };

  const showBackButton = 
    pathname !== "/" && 
    pathname !== "/dashboard" && 
    pathname !== "/auth/login" && 
    pathname !== "/auth/signup";

  // Hide navbar on auth pages
  const isAuthPage = pathname?.startsWith("/auth/");
  
  if (isAuthPage) {
    return null;
  }

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-amber-500/20 bg-black/80 backdrop-blur-md">
      <div className="mx-auto max-w-full px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-4">
            {showBackButton && session?.user && (
              <button
                onClick={() => router.back()}
                className="flex items-center text-gray-400 hover:text-amber-500 transition-colors"
                title="Go back"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            )}
            
            <Link href="/dashboard" className="flex items-center">
              <div className="relative h-14 w-14 sm:h-18 sm:w-18">
                <Image
                  src="/logo.png"
                  alt="Call Sheet Logo"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
            </Link>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-4">
            {session?.user ? (
              <>
                {/* Desktop user info */}
                <Link href="/profile" className="hidden sm:flex">
                  <div className="flex items-center space-x-3 text-sm text-gray-300 hover:text-amber-500 transition-colors cursor-pointer">
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4" />
                      <span className="hidden md:inline">{session.user.name}</span>
                    </div>
                    {session.user.role && (
                      <Badge className={`${roleColors[session.user.role as keyof typeof roleColors]} hidden lg:flex`}>
                        {roleLabels[session.user.role as keyof typeof roleLabels]}
                      </Badge>
                    )}
                  </div>
                </Link>

                {/* Mobile user menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild className="sm:hidden">
                    <Button variant="ghost" size="icon" className="text-gray-300">
                      <User className="h-5 w-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-gray-900 border-gray-800">
                    <DropdownMenuItem asChild>
                      <Link href="/profile" className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <div>
                          <p className="font-medium text-white">{session.user.name}</p>
                          {session.user.role && (
                            <p className="text-xs text-gray-400">
                              {roleLabels[session.user.role as keyof typeof roleLabels]}
                            </p>
                          )}
                        </div>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => signOut({ callbackUrl: "/auth/login" })}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Desktop sign out button */}
                <Button
                  onClick={() => signOut({ callbackUrl: "/auth/login" })}
                  variant="ghost"
                  size="sm"
                  className="hidden sm:flex text-gray-300 hover:text-amber-500"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  <span className="hidden md:inline">Sign Out</span>
                </Button>
              </>
            ) : null}
          </div>
        </div>
      </div>
    </nav>
  );
}
