import React from 'react';
import { Card } from './card';

interface ResponsiveTableProps {
  children: React.ReactNode;
  className?: string;
}

export function ResponsiveTable({ children, className = '' }: ResponsiveTableProps) {
  return (
    <div className="w-full overflow-x-auto -mx-4 sm:mx-0">
      <div className="inline-block min-w-full align-middle">
        <div className={`overflow-hidden ${className}`}>
          {children}
        </div>
      </div>
    </div>
  );
}

export function ResponsiveCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <Card className={`w-full ${className}`}>
      {children}
    </Card>
  );
}
