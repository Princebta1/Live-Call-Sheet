
"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc-client";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

interface CreateSceneModalProps {
  isOpen: boolean;
  onClose: () => void;
  showId: string;
  onSuccess: () => void;
}

export function CreateSceneModal({ isOpen, onClose, showId, onSuccess }: CreateSceneModalProps) {
  const [sceneNumber, setSceneNumber] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [estimatedDuration, setEstimatedDuration] = useState("");
  const [selectedActorIds, setSelectedActorIds] = useState<string[]>([]);

  // Fetch actors for the show
  const { data: actors, isLoading: actorsLoading } = trpc.actors.list.useQuery({ showId });

  const createSceneMutation = trpc.scenes.create.useMutation({
    onSuccess: () => {
      toast.success("Scene created successfully!");
      onSuccess();
      setSceneNumber("");
      setName("");
      setDescription("");
      setEstimatedDuration("");
      setSelectedActorIds([]);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create scene");
    },
  });

  const handleActorToggle = (actorId: string) => {
    setSelectedActorIds((prev) =>
      prev.includes(actorId)
        ? prev.filter((id) => id !== actorId)
        : [...prev, actorId]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedActorIds.length === 0) {
      toast.error("Please select at least one actor for this scene");
      return;
    }

    const durationInSeconds = estimatedDuration
      ? parseInt(estimatedDuration) * 60
      : undefined;

    createSceneMutation.mutate({
      showId,
      sceneNumber,
      name,
      description,
      estimatedDuration: durationInSeconds,
      actorIds: selectedActorIds,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="border-gray-800 bg-gray-900 text-white sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">Add New Scene</DialogTitle>
          <DialogDescription className="text-gray-400">
            Create a new scene for this production
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="sceneNumber">Scene Number</Label>
            <Input
              id="sceneNumber"
              placeholder="e.g., 1A, 12, 25B"
              value={sceneNumber}
              onChange={(e) => setSceneNumber(e.target.value)}
              required
              className="border-gray-700 bg-gray-950"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Scene Name</Label>
            <Input
              id="name"
              placeholder="e.g., Opening Sequence"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="border-gray-700 bg-gray-950"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              placeholder="Brief description of the scene..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="border-gray-700 bg-gray-950"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="estimatedDuration">Estimated Duration (minutes)</Label>
            <Input
              id="estimatedDuration"
              type="number"
              placeholder="e.g., 30"
              value={estimatedDuration}
              onChange={(e) => setEstimatedDuration(e.target.value)}
              className="border-gray-700 bg-gray-950"
              min="1"
            />
            <p className="text-xs text-gray-500">
              How long do you expect this scene to take?
            </p>
          </div>

          <div className="space-y-2">
            <Label>Cast Members <span className="text-red-500">*</span></Label>
            <div className="rounded-md border border-gray-700 bg-gray-950 p-3 max-h-48 overflow-y-auto">
              {actorsLoading ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-5 w-5 animate-spin text-amber-500" />
                  <span className="ml-2 text-sm text-gray-400">Loading actors...</span>
                </div>
              ) : actors && actors.length > 0 ? (
                <div className="space-y-2">
                  {actors.map((actor) => (
                    <div key={actor.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`actor-${actor.id}`}
                        checked={selectedActorIds.includes(actor.id)}
                        onCheckedChange={() => handleActorToggle(actor.id)}
                      />
                      <label
                        htmlFor={`actor-${actor.id}`}
                        className="text-sm cursor-pointer flex-1"
                      >
                        {actor.name} <span className="text-gray-500">({actor.role})</span>
                      </label>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-400 text-center py-2">
                  No actors available. Please add actors to this show first.
                </p>
              )}
            </div>
            <p className="text-xs text-gray-500">
              Select at least one actor who will be in this scene
            </p>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-amber-600 hover:bg-amber-700"
              disabled={createSceneMutation.isPending || selectedActorIds.length === 0}
            >
              {createSceneMutation.isPending ? "Creating..." : "Create Scene"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
