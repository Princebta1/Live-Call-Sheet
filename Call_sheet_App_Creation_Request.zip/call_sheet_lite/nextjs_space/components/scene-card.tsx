
"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Play, Pause, Square, RotateCcw, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc-client";
import { toast } from "sonner";

interface SceneCardProps {
  scene: {
    id: string;
    sceneNumber: string;
    name: string;
    description: string | null;
    estimatedDuration: number | null;
    actualElapsedTime: number;
    status: string;
    timerStartedAt: Date | null;
    timerPausedAt: Date | null;
    accumulatedPauseTime: number;
    sceneActors?: Array<{
      actor: {
        id: string;
        name: string;
        role: string;
      };
    }>;
  };
  onUpdate: () => void;
}

export function SceneCard({ scene, onUpdate }: SceneCardProps) {
  const { data: session } = useSession() || {};
  const [currentElapsed, setCurrentElapsed] = useState(scene.actualElapsedTime);

  const userRole = session?.user?.role;
  const canManageScenes = userRole === "ADMIN" || userRole === "PRODUCTION_ADMIN" || userRole === "DEVELOPER";

  const startTimerMutation = trpc.scenes.startTimer.useMutation({
    onSuccess: () => {
      toast.success("Timer started!");
      onUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const pauseTimerMutation = trpc.scenes.pauseTimer.useMutation({
    onSuccess: () => {
      toast.success("Timer paused!");
      onUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resumeTimerMutation = trpc.scenes.resumeTimer.useMutation({
    onSuccess: () => {
      toast.success("Timer resumed!");
      onUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const stopTimerMutation = trpc.scenes.stopTimer.useMutation({
    onSuccess: () => {
      toast.success("Scene completed!");
      onUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resetTimerMutation = trpc.scenes.resetTimer.useMutation({
    onSuccess: () => {
      toast.success("Timer reset!");
      onUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteSceneMutation = trpc.scenes.delete.useMutation({
    onSuccess: () => {
      toast.success("Scene deleted!");
      onUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (scene.status === "In Progress" && scene.timerStartedAt) {
      interval = setInterval(() => {
        const startTime = new Date(scene.timerStartedAt!).getTime();
        const now = Date.now();
        const elapsed = Math.floor((now - startTime) / 1000) - scene.accumulatedPauseTime;
        setCurrentElapsed(Math.max(0, elapsed));
      }, 100);
    } else {
      setCurrentElapsed(scene.actualElapsedTime);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [scene.status, scene.timerStartedAt, scene.actualElapsedTime, scene.accumulatedPauseTime]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleStart = () => startTimerMutation.mutate({ id: scene.id });
  const handlePause = () => pauseTimerMutation.mutate({ id: scene.id });
  const handleResume = () => resumeTimerMutation.mutate({ id: scene.id });
  const handleStop = () => stopTimerMutation.mutate({ id: scene.id });
  const handleReset = () => {
    if (confirm("Are you sure you want to reset this scene's timer?")) {
      resetTimerMutation.mutate({ id: scene.id });
    }
  };
  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this scene?")) {
      deleteSceneMutation.mutate({ id: scene.id });
    }
  };

  const isLoading =
    startTimerMutation.isPending ||
    pauseTimerMutation.isPending ||
    resumeTimerMutation.isPending ||
    stopTimerMutation.isPending ||
    resetTimerMutation.isPending ||
    deleteSceneMutation.isPending;

  const statusColors = {
    "Not Started": "bg-gray-500/10 text-gray-400 border-gray-500/30",
    "In Progress": "bg-amber-500/10 text-amber-400 border-amber-500/30",
    "Paused": "bg-blue-500/10 text-blue-400 border-blue-500/30",
    "Completed": "bg-green-500/10 text-green-400 border-green-500/30",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-4 sm:p-6">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
              <span className="text-xs sm:text-sm font-medium text-amber-500">#{scene.sceneNumber}</span>
              <Badge className={statusColors[scene.status as keyof typeof statusColors]}>
                {scene.status}
              </Badge>
            </div>
            <h3 className="mt-2 text-lg sm:text-xl font-bold text-white">{scene.name}</h3>
            {scene.description && (
              <p className="mt-1 text-xs sm:text-sm text-gray-400 line-clamp-2">{scene.description}</p>
            )}
            {scene.sceneActors && scene.sceneActors.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {scene.sceneActors.map((sa) => (
                  <Badge
                    key={sa.actor.id}
                    variant="outline"
                    className="text-xs bg-amber-500/10 text-amber-400 border-amber-500/30"
                  >
                    {sa.actor.name}
                  </Badge>
                ))}
              </div>
            )}
          </div>
          {canManageScenes && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              disabled={isLoading}
              className="text-red-400 hover:bg-red-500/10 hover:text-red-300 flex-shrink-0"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        <div className="mt-4 sm:mt-6 flex items-center justify-between rounded-lg bg-gray-950/50 p-3 sm:p-4">
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-amber-500" />
            <div>
              <p className="text-xl sm:text-2xl font-bold text-white">{formatTime(currentElapsed)}</p>
              {scene.estimatedDuration && (
                <p className="text-xs text-gray-500">
                  Est: {formatTime(scene.estimatedDuration)}
                  {currentElapsed > scene.estimatedDuration && (
                    <span className="ml-2 text-red-400">
                      (+{formatTime(currentElapsed - scene.estimatedDuration)} over)
                    </span>
                  )}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 sm:flex sm:flex-wrap gap-2">
          {scene.status === "Not Started" && (
            <Button
              onClick={handleStart}
              disabled={isLoading}
              className="bg-green-600 hover:bg-green-700 w-full sm:w-auto"
            >
              <Play className="mr-2 h-4 w-4" />
              Start
            </Button>
          )}

          {scene.status === "In Progress" && (
            <>
              <Button
                onClick={handlePause}
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Pause className="mr-2 h-4 w-4" />
                Pause
              </Button>
              <Button
                onClick={handleStop}
                disabled={isLoading}
                className="bg-red-600 hover:bg-red-700"
              >
                <Square className="mr-2 h-4 w-4" />
                Stop
              </Button>
            </>
          )}

          {scene.status === "Paused" && (
            <>
              <Button
                onClick={handleResume}
                disabled={isLoading}
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="mr-2 h-4 w-4" />
                Resume
              </Button>
              <Button
                onClick={handleStop}
                disabled={isLoading}
                className="bg-red-600 hover:bg-red-700"
              >
                <Square className="mr-2 h-4 w-4" />
                Stop
              </Button>
            </>
          )}

          {(scene.status === "Completed" || scene.status === "Paused") && canManageScenes && (
            <Button
              onClick={handleReset}
              disabled={isLoading}
              variant="outline"
              className="border-gray-700"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
