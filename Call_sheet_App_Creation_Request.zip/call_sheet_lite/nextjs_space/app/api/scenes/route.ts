
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST create a new scene
export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { showId, sceneNumber, name, description, estimatedDuration } = body;

    if (!showId || !sceneNumber || !name) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Verify user owns the show
    const show = await prisma.show.findFirst({
      where: {
        id: showId,
        creatorId: session.user.id,
      },
    });

    if (!show) {
      return NextResponse.json({ error: "Show not found" }, { status: 404 });
    }

    const scene = await prisma.scene.create({
      data: {
        showId,
        sceneNumber,
        name,
        description: description ?? null,
        estimatedDuration: estimatedDuration ? parseInt(estimatedDuration) : null,
      },
    });

    return NextResponse.json({ scene }, { status: 201 });
  } catch (error) {
    console.error("Error creating scene:", error);
    return NextResponse.json(
      { error: "Failed to create scene" },
      { status: 500 }
    );
  }
}
