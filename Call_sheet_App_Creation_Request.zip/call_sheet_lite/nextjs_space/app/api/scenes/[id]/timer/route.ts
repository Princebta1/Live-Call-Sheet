
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST timer actions: start, pause, resume, stop, reset
export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { action } = body;

    // Verify user owns the show
    const existingScene = await prisma.scene.findFirst({
      where: {
        id: params.id,
        show: {
          creatorId: session.user.id,
        },
      },
    });

    if (!existingScene) {
      return NextResponse.json({ error: "Scene not found" }, { status: 404 });
    }

    const now = new Date();
    let updateData: any = {};

    switch (action) {
      case "start":
        if (existingScene.status !== "Not Started") {
          return NextResponse.json(
            { error: "Scene already started" },
            { status: 400 }
          );
        }
        updateData = {
          status: "In Progress",
          timerStartedAt: now,
          timerPausedAt: null,
          actualElapsedTime: 0,
          accumulatedPauseTime: 0,
        };
        break;

      case "pause":
        if (existingScene.status !== "In Progress") {
          return NextResponse.json(
            { error: "Timer is not running" },
            { status: 400 }
          );
        }
        // Calculate elapsed time up to now
        const elapsedBeforePause = existingScene.timerStartedAt
          ? Math.floor(
              (now.getTime() - existingScene.timerStartedAt.getTime()) / 1000
            ) - existingScene.accumulatedPauseTime
          : 0;
        
        updateData = {
          status: "Paused",
          timerPausedAt: now,
          actualElapsedTime: Math.max(0, elapsedBeforePause),
        };
        break;

      case "resume":
        if (existingScene.status !== "Paused") {
          return NextResponse.json(
            { error: "Timer is not paused" },
            { status: 400 }
          );
        }
        // Calculate pause duration and add to accumulated pause time
        const pauseDuration = existingScene.timerPausedAt
          ? Math.floor(
              (now.getTime() - existingScene.timerPausedAt.getTime()) / 1000
            )
          : 0;
        
        updateData = {
          status: "In Progress",
          timerPausedAt: null,
          accumulatedPauseTime: existingScene.accumulatedPauseTime + pauseDuration,
        };
        break;

      case "stop":
        if (existingScene.status === "Completed" || existingScene.status === "Not Started") {
          return NextResponse.json(
            { error: "Invalid timer state" },
            { status: 400 }
          );
        }
        // Calculate final elapsed time
        let finalElapsed = existingScene.actualElapsedTime;
        
        if (existingScene.status === "In Progress" && existingScene.timerStartedAt) {
          finalElapsed = Math.floor(
            (now.getTime() - existingScene.timerStartedAt.getTime()) / 1000
          ) - existingScene.accumulatedPauseTime;
        }
        
        updateData = {
          status: "Completed",
          actualElapsedTime: Math.max(0, finalElapsed),
          timerPausedAt: null,
        };
        break;

      case "reset":
        updateData = {
          status: "Not Started",
          timerStartedAt: null,
          timerPausedAt: null,
          actualElapsedTime: 0,
          accumulatedPauseTime: 0,
        };
        break;

      default:
        return NextResponse.json(
          { error: "Invalid action" },
          { status: 400 }
        );
    }

    const scene = await prisma.scene.update({
      where: { id: params.id },
      data: updateData,
    });

    return NextResponse.json({ scene });
  } catch (error) {
    console.error("Error updating timer:", error);
    return NextResponse.json(
      { error: "Failed to update timer" },
      { status: 500 }
    );
  }
}
