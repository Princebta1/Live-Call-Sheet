
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET a single scene
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const scene = await prisma.scene.findFirst({
      where: {
        id: params.id,
        show: {
          creatorId: session.user.id,
        },
      },
      include: {
        show: true,
      },
    });

    if (!scene) {
      return NextResponse.json({ error: "Scene not found" }, { status: 404 });
    }

    return NextResponse.json({ scene });
  } catch (error) {
    console.error("Error fetching scene:", error);
    return NextResponse.json(
      { error: "Failed to fetch scene" },
      { status: 500 }
    );
  }
}

// PATCH update a scene
export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { sceneNumber, name, description, estimatedDuration } = body;

    // Verify user owns the show
    const existingScene = await prisma.scene.findFirst({
      where: {
        id: params.id,
        show: {
          creatorId: session.user.id,
        },
      },
    });

    if (!existingScene) {
      return NextResponse.json({ error: "Scene not found" }, { status: 404 });
    }

    const scene = await prisma.scene.update({
      where: { id: params.id },
      data: {
        ...(sceneNumber && { sceneNumber }),
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(estimatedDuration !== undefined && { 
          estimatedDuration: estimatedDuration ? parseInt(estimatedDuration) : null 
        }),
      },
    });

    return NextResponse.json({ scene });
  } catch (error) {
    console.error("Error updating scene:", error);
    return NextResponse.json(
      { error: "Failed to update scene" },
      { status: 500 }
    );
  }
}

// DELETE a scene
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify user owns the show
    const existingScene = await prisma.scene.findFirst({
      where: {
        id: params.id,
        show: {
          creatorId: session.user.id,
        },
      },
    });

    if (!existingScene) {
      return NextResponse.json({ error: "Scene not found" }, { status: 404 });
    }

    await prisma.scene.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: "Scene deleted" });
  } catch (error) {
    console.error("Error deleting scene:", error);
    return NextResponse.json(
      { error: "Failed to delete scene" },
      { status: 500 }
    );
  }
}
