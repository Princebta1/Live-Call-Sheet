
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET a single show by ID
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const show = await prisma.show.findFirst({
      where: {
        id: params.id,
        creatorId: session.user.id,
      },
      include: {
        scenes: {
          orderBy: {
            sceneNumber: "asc",
          },
        },
        _count: {
          select: { scenes: true },
        },
      },
    });

    if (!show) {
      return NextResponse.json({ error: "Show not found" }, { status: 404 });
    }

    return NextResponse.json({ show });
  } catch (error) {
    console.error("Error fetching show:", error);
    return NextResponse.json(
      { error: "Failed to fetch show" },
      { status: 500 }
    );
  }
}

// PATCH update a show
export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { title, description, status } = body;

    // Verify ownership
    const existingShow = await prisma.show.findFirst({
      where: {
        id: params.id,
        creatorId: session.user.id,
      },
    });

    if (!existingShow) {
      return NextResponse.json({ error: "Show not found" }, { status: 404 });
    }

    const show = await prisma.show.update({
      where: { id: params.id },
      data: {
        ...(title && { title }),
        ...(description !== undefined && { description }),
        ...(status && { status }),
      },
    });

    return NextResponse.json({ show });
  } catch (error) {
    console.error("Error updating show:", error);
    return NextResponse.json(
      { error: "Failed to update show" },
      { status: 500 }
    );
  }
}

// DELETE a show
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify ownership
    const existingShow = await prisma.show.findFirst({
      where: {
        id: params.id,
        creatorId: session.user.id,
      },
    });

    if (!existingShow) {
      return NextResponse.json({ error: "Show not found" }, { status: 404 });
    }

    await prisma.show.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: "Show deleted" });
  } catch (error) {
    console.error("Error deleting show:", error);
    return NextResponse.json(
      { error: "Failed to delete show" },
      { status: 500 }
    );
  }
}
