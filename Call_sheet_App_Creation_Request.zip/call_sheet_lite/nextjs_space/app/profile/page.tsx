
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc-client";
import { Loader2, User, Users, Mail, Shield, Calendar, Building2, Clapperboard, AlertCircle, Lock, Eye, EyeOff } from "lucide-react";
import { useEffect, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";

export default function ProfilePage() {
  const router = useRouter();
  const { data: session, status, update } = useSession() || {};
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const { data: profile, isLoading } = trpc.users.getProfile.useQuery(undefined, {
    enabled: status === "authenticated" && !!session?.user,
  });

  const changePasswordMutation = trpc.users.changePassword.useMutation({
    onSuccess: async () => {
      toast.success("Password changed successfully!");
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
      setShowPasswordForm(false);
      // Update session to clear mustChangePassword flag if it was set
      if (update) {
        await update();
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to change password");
    },
  });

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/login");
    }
  }, [status, router]);

  const handleChangePassword = () => {
    // Validation
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      toast.error("Please fill in all password fields");
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast.error("New password must be at least 6 characters long");
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error("New passwords do not match");
      return;
    }

    changePasswordMutation.mutate({
      currentPassword: passwordData.currentPassword,
      newPassword: passwordData.newPassword,
    });
  };

  if (status === "loading" || isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gradient-to-br from-black via-gray-900 to-black">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!session || !profile) {
    return null;
  }

  const roleColors = {
    DEVELOPER: "bg-red-500/10 text-red-400 border-red-500/30",
    PRODUCTION_ADMIN: "bg-blue-500/10 text-blue-400 border-blue-500/30",
    ADMIN: "bg-purple-500/10 text-purple-400 border-purple-500/30",
    CREW: "bg-gray-500/10 text-gray-400 border-gray-500/30",
    ACTOR: "bg-amber-500/10 text-amber-400 border-amber-500/30",
  };

  const roleLabels = {
    DEVELOPER: "Developer",
    PRODUCTION_ADMIN: "Production Admin",
    ADMIN: "Admin",
    CREW: "Crew",
    ACTOR: "Actor",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold text-white">User Profile</h1>
          <p className="text-gray-400">View your account information and assignments</p>
        </div>

        {/* Account Status Alert */}
        {!profile.isActive && (
          <div className="mb-6 rounded-lg border border-red-500/30 bg-red-500/10 p-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
              <div>
                <p className="font-semibold text-red-400">Account Deactivated</p>
                <p className="text-sm text-red-300/80">
                  Your account has been deactivated. Please contact production for access.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Profile Information */}
        <Card className="mb-6 border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
          <h2 className="mb-4 text-xl font-semibold text-white">Profile Information</h2>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <User className="h-5 w-5 text-amber-500" />
              <div className="flex-1">
                <p className="text-sm text-gray-400">Name</p>
                <p className="text-white">{profile.name}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Mail className="h-5 w-5 text-amber-500" />
              <div className="flex-1">
                <p className="text-sm text-gray-400">Email</p>
                <p className="text-white">{profile.email}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Shield className="h-5 w-5 text-amber-500" />
              <div className="flex-1">
                <p className="text-sm text-gray-400">Role</p>
                <Badge className={roleColors[profile.role as keyof typeof roleColors]}>
                  {roleLabels[profile.role as keyof typeof roleLabels]}
                </Badge>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Calendar className="h-5 w-5 text-amber-500" />
              <div className="flex-1">
                <p className="text-sm text-gray-400">Member Since</p>
                <p className="text-white">{new Date(profile.createdAt).toLocaleDateString()}</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Password Change Section */}
        <Card className="mb-6 border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Security</h2>
            {!showPasswordForm && (
              <Button
                onClick={() => setShowPasswordForm(true)}
                variant="outline"
                className="border-amber-500/50 text-amber-500 hover:bg-amber-500/10"
              >
                <Lock className="h-4 w-4 mr-2" />
                Change Password
              </Button>
            )}
          </div>

          {showPasswordForm ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword" className="text-gray-300">Current Password</Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    type={showCurrentPassword ? "text" : "password"}
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                    className="bg-gray-950 border-gray-700 text-white pr-10"
                    placeholder="Enter current password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300"
                  >
                    {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword" className="text-gray-300">New Password</Label>
                <div className="relative">
                  <Input
                    id="newPassword"
                    type={showNewPassword ? "text" : "password"}
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                    className="bg-gray-950 border-gray-700 text-white pr-10"
                    placeholder="Enter new password (min. 6 characters)"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300"
                  >
                    {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-gray-300">Confirm New Password</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                    className="bg-gray-950 border-gray-700 text-white pr-10"
                    placeholder="Confirm new password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300"
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="flex space-x-3 pt-2">
                <Button
                  onClick={handleChangePassword}
                  disabled={changePasswordMutation.isPending}
                  className="bg-amber-500 hover:bg-amber-600 text-black"
                >
                  {changePasswordMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Changing...
                    </>
                  ) : (
                    "Change Password"
                  )}
                </Button>
                <Button
                  onClick={() => {
                    setShowPasswordForm(false);
                    setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
                  }}
                  variant="outline"
                  className="border-gray-700 text-gray-300 hover:bg-gray-800"
                  disabled={changePasswordMutation.isPending}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-gray-400 text-sm">
              Click "Change Password" to update your account security credentials.
            </p>
          )}
        </Card>

        {/* Company Assignment (for Admins) */}
        {profile.role === "ADMIN" && profile.company && (
          <Card className="mb-6 border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <h2 className="mb-4 text-xl font-semibold text-white">Company Assignment</h2>
            
            <div className="flex items-start space-x-3">
              <Building2 className="h-5 w-5 text-green-500 mt-1" />
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <p className="text-lg font-medium text-white">{profile.company.name}</p>
                  {!profile.company.isActive && (
                    <Badge className="bg-red-500/10 text-red-400 border-red-500/30">
                      Deactivated
                    </Badge>
                  )}
                </div>
                {!profile.company.isActive && (
                  <p className="mt-2 text-sm text-red-400">
                    This company has been deactivated. Please contact production for access.
                  </p>
                )}
                <Link href="/admin/companies">
                  <p className="mt-2 text-sm text-amber-500 hover:text-amber-400 cursor-pointer">
                    View company details →
                  </p>
                </Link>
              </div>
            </div>
          </Card>
        )}

        {/* Show Assignment (for Production Admins) */}
        {profile.role === "PRODUCTION_ADMIN" && profile.assignedShow && (
          <Card className="mb-6 border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <h2 className="mb-4 text-xl font-semibold text-white">Show Assignment</h2>
            
            <div className="flex items-start space-x-3">
              <Clapperboard className="h-5 w-5 text-blue-500 mt-1" />
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <p className="text-lg font-medium text-white">{profile.assignedShow.title}</p>
                  {!profile.assignedShow.isActive && (
                    <Badge className="bg-red-500/10 text-red-400 border-red-500/30">
                      Deactivated
                    </Badge>
                  )}
                  {!profile.assignedShow.isApproved && (
                    <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/30">
                      Pending Approval
                    </Badge>
                  )}
                </div>
                {!profile.assignedShow.isActive && (
                  <p className="mt-2 text-sm text-red-400">
                    This show has been deactivated. Please contact production for access.
                  </p>
                )}
                {!profile.assignedShow.isApproved && (
                  <p className="mt-2 text-sm text-yellow-400">
                    This show is pending developer approval. You'll have access once it's approved.
                  </p>
                )}
                {profile.assignedShow.isActive && profile.assignedShow.isApproved && (
                  <Link href={`/shows/${profile.assignedShow.id}`}>
                    <p className="mt-2 text-sm text-amber-500 hover:text-amber-400 cursor-pointer">
                      View show details →
                    </p>
                  </Link>
                )}
              </div>
            </div>
          </Card>
        )}

        {/* System Access (for Developers) */}
        {profile.role === "DEVELOPER" && (
          <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <h2 className="mb-4 text-xl font-semibold text-white">System Access</h2>
            
            <div className="grid gap-4 md:grid-cols-2">
              <Link href="/admin/users">
                <div className="cursor-pointer rounded-lg border border-gray-800 p-4 hover:border-purple-500/50 transition-colors">
                  <Users className="h-6 w-6 text-purple-500 mb-2" />
                  <p className="font-medium text-white">User Management</p>
                  <p className="text-sm text-gray-400">Manage all system users</p>
                </div>
              </Link>

              <Link href="/admin/companies">
                <div className="cursor-pointer rounded-lg border border-gray-800 p-4 hover:border-green-500/50 transition-colors">
                  <Building2 className="h-6 w-6 text-green-500 mb-2" />
                  <p className="font-medium text-white">Company Management</p>
                  <p className="text-sm text-gray-400">Manage production companies</p>
                </div>
              </Link>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
