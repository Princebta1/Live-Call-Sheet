'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User as UserIcon, Mail, Film, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';

export default function ActorProfilePage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};

  const { data: user } = trpc.users.getProfile.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  const { data: scenes } = trpc.actorScenes.myScenes.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    } else if (session?.user?.role !== 'ACTOR') {
      router.push('/dashboard');
    }
  }, [status, session, router]);

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  const totalScenes = scenes?.length || 0;
  const completedScenes = scenes?.filter((s: any) => s.status === 'Completed').length || 0;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <UserIcon className="h-8 w-8 text-amber-500" />
          My Profile
        </h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserIcon className="h-5 w-5 text-amber-500" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Name</label>
              <p className="text-lg font-semibold text-white">{user?.name}</p>
            </div>
            <div>
              <label className="text-sm text-gray-400">Email</label>
              <p className="flex items-center gap-2 text-white">
                <Mail className="h-4 w-4" />
                {user?.email}
              </p>
            </div>
            <div>
              <label className="text-sm text-gray-400">Role</label>
              <div className="mt-1">
                <Badge>{user?.role}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Film className="h-5 w-5 text-amber-500" />
              Scene Statistics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Total Scenes</label>
              <p className="text-3xl font-bold text-white">{totalScenes}</p>
            </div>
            <div>
              <label className="text-sm text-gray-400">Completed Scenes</label>
              <p className="text-3xl font-bold text-green-400">{completedScenes}</p>
            </div>
            <div>
              <label className="text-sm text-gray-400">Completion Rate</label>
              <p className="text-2xl font-bold text-amber-400">
                {totalScenes > 0 ? Math.round((completedScenes / totalScenes) * 100) : 0}%
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
