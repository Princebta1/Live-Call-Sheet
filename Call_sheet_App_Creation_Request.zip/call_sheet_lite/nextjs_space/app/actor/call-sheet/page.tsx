'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ClipboardList, Calendar, Clock, Film, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { format } from 'date-fns';

export default function CallSheetPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};

  const { data: scenes, isLoading } = trpc.actorScenes.callSheet.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    } else if (session?.user?.role !== 'ACTOR') {
      router.push('/dashboard');
    }
  }, [status, session, router]);

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    'Not Started': 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    'In Progress': 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    'Paused': 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    'Completed': 'bg-green-500/10 text-green-400 border-green-500/30',
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <ClipboardList className="h-8 w-8 text-amber-500" />
          Call Sheet
        </h1>
        <p className="mt-2 text-gray-400">Your upcoming scenes</p>
      </div>

      {!scenes || scenes.length === 0 ? (
        <Card className="bg-gray-900/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ClipboardList className="mb-4 h-12 w-12 text-gray-500" />
            <p className="text-gray-400">No upcoming scenes scheduled</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {scenes.map((scene: any) => (
            <Card key={scene.id} className="bg-gray-900/50">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Film className="h-5 w-5 text-amber-500" />
                      Scene {scene.sceneNumber}: {scene.name}
                    </CardTitle>
                    <p className="mt-1 text-sm text-gray-400">{scene.show.title}</p>
                  </div>
                  <Badge className={statusColors[scene.status]}>
                    {scene.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {scene.description && (
                  <p className="mb-4 text-gray-300">{scene.description}</p>
                )}
                <div className="flex flex-wrap gap-4 text-sm">
                  {scene.scheduledDate && (
                    <div className="flex items-center gap-2 text-gray-400">
                      <Calendar className="h-4 w-4" />
                      {format(new Date(scene.scheduledDate), 'PPP')}
                    </div>
                  )}
                  {scene.estimatedDuration && (
                    <div className="flex items-center gap-2 text-gray-400">
                      <Clock className="h-4 w-4" />
                      Est: {Math.floor(scene.estimatedDuration / 60)} minutes
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
