'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, startOfWeek, endOfWeek } from 'date-fns';
import { useState } from 'react';

export default function ActorCalendarPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const { data: scenes, isLoading } = trpc.actorScenes.myScenes.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    } else if (session?.user?.role !== 'ACTOR') {
      router.push('/dashboard');
    }
  }, [status, session, router]);

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const scenesByDate = (scenes || []).reduce((acc: Record<string, any[]>, scene: any) => {
    if (scene.scheduledDate) {
      const dateKey = format(new Date(scene.scheduledDate), 'yyyy-MM-dd');
      if (!acc[dateKey]) acc[dateKey] = [];
      acc[dateKey].push(scene);
    }
    return acc;
  }, {});

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <CalendarIcon className="h-8 w-8 text-amber-500" />
          My Calendar
        </h1>
        <p className="mt-2 text-gray-400">{format(currentMonth, 'MMMM yyyy')}</p>
      </div>

      <Card className="bg-gray-900/50">
        <CardContent className="p-6">
          <div className="grid grid-cols-7 gap-2 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-sm font-semibold text-gray-400 p-2">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {calendarDays.map((day, index) => {
              const dateKey = format(day, 'yyyy-MM-dd');
              const scenesForDay = scenesByDate[dateKey] || [];
              const isCurrentMonth = isSameMonth(day, currentMonth);

              return (
                <div
                  key={index}
                  className={`min-h-[100px] p-2 border rounded-lg ${
                    isCurrentMonth ? 'bg-gray-800 border-gray-700' : 'bg-gray-900/50 border-gray-800'
                  }`}
                >
                  <div className={`text-sm font-medium mb-1 ${isCurrentMonth ? 'text-white' : 'text-gray-600'}`}>
                    {format(day, 'd')}
                  </div>
                  {scenesForDay.length > 0 && (
                    <div className="space-y-1">
                      {scenesForDay.map((scene: any) => (
                        <div key={scene.id} className="text-xs truncate p-1 rounded bg-amber-500/20 text-amber-300">
                          {scene.sceneNumber}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
