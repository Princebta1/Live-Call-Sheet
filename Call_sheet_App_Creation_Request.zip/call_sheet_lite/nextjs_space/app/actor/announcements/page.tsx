'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Megaphone, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { format } from 'date-fns';

export default function ActorAnnouncementsPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};

  const { data: scenes } = trpc.actorScenes.myScenes.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  // Get unique show IDs
  const showIds = scenes ? [...new Set(scenes.map((s: any) => s.show.id))] : [];

  // Fetch announcements for all shows
  const announcementsQueries = showIds.map((showId: string) =>
    trpc.announcements.list.useQuery(
      { showId },
      { enabled: !!showId }
    )
  );

  const allAnnouncements = announcementsQueries
    .flatMap((q) => q.data || [])
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    } else if (session?.user?.role !== 'ACTOR') {
      router.push('/dashboard');
    }
  }, [status, session, router]);

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  const priorityColors: Record<string, string> = {
    low: 'bg-gray-500/10 text-gray-400 border-gray-500/30',
    normal: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    high: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    urgent: 'bg-red-500/10 text-red-400 border-red-500/30',
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Megaphone className="h-8 w-8 text-amber-500" />
          Announcements
        </h1>
        <p className="mt-2 text-gray-400">Production updates and notices</p>
      </div>

      {allAnnouncements.length === 0 ? (
        <Card className="bg-gray-900/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Megaphone className="mb-4 h-12 w-12 text-gray-500" />
            <p className="text-gray-400">No announcements yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {allAnnouncements.map((announcement: any) => (
            <Card key={announcement.id} className="bg-gray-900/50">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-white">{announcement.title}</h3>
                  <Badge className={priorityColors[announcement.priority]}>
                    {announcement.priority}
                  </Badge>
                </div>
                <p className="mb-4 text-gray-300">{announcement.content}</p>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span>By: {announcement.createdBy.name}</span>
                  <span>•</span>
                  <span>{format(new Date(announcement.createdAt), 'PPp')}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
