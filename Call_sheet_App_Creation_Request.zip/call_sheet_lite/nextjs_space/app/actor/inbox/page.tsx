'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Inbox, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { format } from 'date-fns';

export default function ActorInboxPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};

  const { data: scenes } = trpc.actorScenes.myScenes.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  const showIds = scenes ? [...new Set(scenes.map((s: any) => s.show.id))] : [];

  const messagesQueries = showIds.map((showId: string) =>
    trpc.messages.list.useQuery(
      { showId },
      { enabled: !!showId, refetchInterval: 5000 }
    )
  );

  const allMessages = messagesQueries
    .flatMap((q) => q.data || [])
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    } else if (session?.user?.role !== 'ACTOR') {
      router.push('/dashboard');
    }
  }, [status, session, router]);

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Inbox className="h-8 w-8 text-amber-500" />
          Inbox
        </h1>
        <p className="mt-2 text-gray-400">Production messages</p>
      </div>

      {allMessages.length === 0 ? (
        <Card className="bg-gray-900/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Inbox className="mb-4 h-12 w-12 text-gray-500" />
            <p className="text-gray-400">No messages yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {allMessages.map((message: any) => (
            <Card key={message.id} className="bg-gray-900/50">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-white">{message.sender.name}</p>
                    <p className="text-xs text-gray-500">{message.sender.role}</p>
                  </div>
                  <p className="text-xs text-gray-500">
                    {format(new Date(message.createdAt), 'PPp')}
                  </p>
                </div>
                <p className="text-gray-300 whitespace-pre-wrap">{message.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
