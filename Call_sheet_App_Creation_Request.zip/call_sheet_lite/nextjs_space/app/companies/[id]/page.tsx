
'use client';

import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { useEffect } from 'react';
import { trpc } from '@/lib/trpc-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, Building2, Users, Film, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function CompanyProfilePage() {
  const router = useRouter();
  const params = useParams();
  const companyId = params.id as string;
  const { data: session, status } = useSession() || {};

  const { data: companies, isLoading: companiesLoading } = trpc.companies.list.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  const company = companies?.find((c) => c.id === companyId);

  const { data: shows, isLoading: showsLoading } = trpc.shows.list.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
    }
  );

  const companyShows = shows?.filter((show) => show.companyId === companyId);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    }
  }, [status, router]);

  if (status === 'loading' || companiesLoading || showsLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!company) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <Building2 className="h-16 w-16 text-gray-500" />
        <h2 className="text-2xl font-bold text-white">Company Not Found</h2>
        <Button onClick={() => router.push('/admin/companies')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Companies
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Company Header */}
      <div className="mb-8">
        <Button
          variant="ghost"
          onClick={() => router.push('/admin/companies')}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Companies
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Building2 className="h-6 w-6 text-amber-500" />
                  {company.name}
                  <Badge variant={company.isActive ? 'default' : 'destructive'}>
                    {company.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </CardTitle>
                {company.description && (
                  <p className="mt-2 text-gray-400">{company.description}</p>
                )}
              </div>
            </div>
          </CardHeader>
        </Card>
      </div>

      {/* Company Statistics */}
      <div className="mb-8 grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Film className="h-5 w-5 text-blue-500" />
              Total Shows
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white">{companyShows?.length || 0}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Users className="h-5 w-5 text-green-500" />
              Company Admins
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white">{company.admins?.length || 0}</p>
          </CardContent>
        </Card>
      </div>

      {/* Company Shows */}
      <div>
        <h2 className="mb-4 text-2xl font-bold text-white">Company Shows</h2>
        {!companyShows || companyShows.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Film className="mb-4 h-12 w-12 text-gray-500" />
              <p className="text-gray-400">No shows found for this company</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {companyShows.map((show) => (
              <Link key={show.id} href={`/shows/${show.id}`}>
                <Card className="cursor-pointer transition-colors hover:border-amber-500">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg">{show.title}</CardTitle>
                      <div className="flex flex-col gap-2">
                        <Badge variant={show.isActive ? 'default' : 'destructive'}>
                          {show.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                        <Badge variant={show.isApproved ? 'default' : 'secondary'}>
                          {show.isApproved ? 'Approved' : 'Pending'}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {show.description && (
                      <p className="mb-3 line-clamp-2 text-sm text-gray-400">
                        {show.description}
                      </p>
                    )}
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Film className="h-4 w-4" />
                      <span>{show._count?.scenes || 0} scenes</span>
                    </div>
                    <div className="mt-2">
                      <Badge variant="outline">{show.status}</Badge>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
