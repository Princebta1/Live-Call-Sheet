
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Film, Clock, Play, CheckCircle } from "lucide-react";

export default async function Home() {
  const session = await getServerSession(authOptions);

  if (session) {
    redirect("/dashboard");
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center">
          <div className="mb-8 flex justify-center">
            <div className="relative h-64 w-64 sm:h-80 sm:w-80 lg:h-96 lg:w-96">
              <Image
                src="/logo.png"
                alt="Call Sheet Logo"
                fill
                className="object-contain drop-shadow-2xl"
                priority
              />
            </div>
          </div>
          <p className="mx-auto mb-12 max-w-2xl text-xl text-gray-300">
            Track production scenes with real-time timers. Manage your film and TV shoots efficiently with professional-grade tools.
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/auth/signup">
              <Button size="lg" className="text-lg">
                Get Started
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="text-lg">
                Sign In
              </Button>
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="mt-24 grid gap-8 md:grid-cols-3">
          <div className="rounded-lg border border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 shadow-lg">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-amber-500/10">
              <Clock className="h-6 w-6 text-amber-500" />
            </div>
            <h3 className="mb-2 text-xl font-semibold text-white">Real-Time Timers</h3>
            <p className="text-gray-400">
              Track scene shooting duration with precision. Start, pause, and stop timers for each scene.
            </p>
          </div>

          <div className="rounded-lg border border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 shadow-lg">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-blue-500/10">
              <Play className="h-6 w-6 text-blue-500" />
            </div>
            <h3 className="mb-2 text-xl font-semibold text-white">Scene Management</h3>
            <p className="text-gray-400">
              Organize your production with detailed scene information and status tracking.
            </p>
          </div>

          <div className="rounded-lg border border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 shadow-lg">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-500/10">
              <CheckCircle className="h-6 w-6 text-emerald-500" />
            </div>
            <h3 className="mb-2 text-xl font-semibold text-white">Production Tracking</h3>
            <p className="text-gray-400">
              Monitor multiple shows and track progress from pre-production to wrapped.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
