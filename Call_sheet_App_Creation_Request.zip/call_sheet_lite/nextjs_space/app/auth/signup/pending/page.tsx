
"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Film, Clock, Mail } from "lucide-react";

export default function PendingApprovalPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-black via-gray-900 to-black px-4">
      <div className="w-full max-w-2xl">
        <div className="mb-8 text-center">
          <Link href="/" className="inline-flex items-center space-x-2">
            <Film className="h-10 w-10 text-amber-500" />
            <span className="text-2xl font-bold bg-gradient-to-r from-amber-500 to-amber-300 bg-clip-text text-transparent">
              Call Sheet
            </span>
          </Link>
        </div>

        <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/10">
              <Clock className="h-8 w-8 text-amber-500" />
            </div>
            <CardTitle className="text-2xl text-white">Registration Submitted</CardTitle>
            <CardDescription className="text-gray-400">
              Your account is pending review
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert className="border-amber-500/50 bg-amber-500/10">
              <Mail className="h-4 w-4 text-amber-500" />
              <AlertDescription className="text-gray-200">
                Your application has been submitted and is pending administrator approval. 
                Please wait or contact your administrator for an update on your approval status.
              </AlertDescription>
            </Alert>

            <div className="space-y-4 rounded-lg border border-gray-800 bg-gray-900/50 p-4">
              <h3 className="font-semibold text-white">What happens next?</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="flex items-start">
                  <span className="mr-2 text-amber-500">•</span>
                  <span>A developer will review your registration details</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-amber-500">•</span>
                  <span>You will receive access once your account is approved</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-amber-500">•</span>
                  <span>You can try logging in after approval to access the platform</span>
                </li>
              </ul>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <Button
                variant="outline"
                className="flex-1 border-gray-700 hover:bg-gray-800"
                asChild
              >
                <Link href="/auth/login">
                  Go to Login
                </Link>
              </Button>
              <Button
                variant="outline"
                className="flex-1 border-gray-700 hover:bg-gray-800"
                asChild
              >
                <Link href="/">
                  Back to Home
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
