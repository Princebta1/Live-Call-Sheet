
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Link from "next/link";
import { Film, Plus, Clock, Users, Building2, TrendingUp, Play, CheckCircle, Pause, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc-client";
import { useEffect } from "react";

export default function DashboardPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};

  const { data: stats, isLoading } = trpc.stats.overall.useQuery(undefined, {
    enabled: status === "authenticated" && !!session?.user,
  });
  const { data: userStats } = trpc.stats.users.useQuery(undefined, {
    enabled: status === "authenticated" && session?.user?.role === "DEVELOPER",
  });
  const { data: companyStats } = trpc.stats.companies.useQuery(undefined, {
    enabled: status === "authenticated" && (session?.user?.role === "DEVELOPER" || session?.user?.role === "ADMIN"),
  });

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/login");
    }
  }, [status, router]);

  if (status === "loading" || isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gradient-to-br from-black via-gray-900 to-black">
        <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!session) {
    return null;
  }

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return `${hrs}h ${mins}m`;
  };

  const scenesByStatus = {
    "Not Started": stats?.sceneStats.find(s => s.status === "Not Started")?.count || 0,
    "In Progress": stats?.sceneStats.find(s => s.status === "In Progress")?.count || 0,
    "Paused": stats?.sceneStats.find(s => s.status === "Paused")?.count || 0,
    "Completed": stats?.sceneStats.find(s => s.status === "Completed")?.count || 0,
  };

  const showsByStatus = {
    "Pre-Production": stats?.showStats.find(s => s.status === "Pre-Production")?.count || 0,
    "Shooting": stats?.showStats.find(s => s.status === "Shooting")?.count || 0,
    "Wrapped": stats?.showStats.find(s => s.status === "Wrapped")?.count || 0,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold text-white">
            Welcome back, <span className="text-amber-500">{session.user?.name}</span>
          </h1>
          <p className="text-gray-400">
            {session.user?.role === "DEVELOPER" && "System-wide analytics and management"}
            {session.user?.role === "ADMIN" && "Company production overview"}
            {session.user?.role === "PRODUCTION_ADMIN" && "Show production management"}
            {(session.user?.role === "CREW" || session.user?.role === "ACTOR") && "Your production dashboard"}
          </p>
        </div>

        {/* Quick Stats */}
        <div className="mb-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Shows</p>
                <p className="text-2xl sm:text-3xl font-bold text-white">{stats?.totalShows || 0}</p>
              </div>
              <Film className="h-10 w-10 text-amber-500" />
            </div>
          </Card>

          <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Scenes</p>
                <p className="text-2xl sm:text-3xl font-bold text-white">{stats?.totalScenes || 0}</p>
              </div>
              <Clock className="h-10 w-10 text-blue-500" />
            </div>
          </Card>

          {session.user?.role === "DEVELOPER" && (
            <>
              <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Total Users</p>
                    <p className="text-2xl sm:text-3xl font-bold text-white">{stats?.totalUsers || 0}</p>
                  </div>
                  <Users className="h-10 w-10 text-purple-500" />
                </div>
              </Card>

              <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Companies</p>
                    <p className="text-2xl sm:text-3xl font-bold text-white">{stats?.totalCompanies || 0}</p>
                  </div>
                  <Building2 className="h-10 w-10 text-green-500" />
                </div>
              </Card>
            </>
          )}

          {session.user?.role !== "DEVELOPER" && (
            <>
              <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Actual Time</p>
                    <p className="text-2xl sm:text-3xl font-bold text-white">{formatTime(stats?.totalActualTime || 0)}</p>
                  </div>
                  <TrendingUp className="h-10 w-10 text-emerald-500" />
                </div>
              </Card>

              <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Estimated Time</p>
                    <p className="text-2xl sm:text-3xl font-bold text-white">{formatTime(stats?.totalEstimatedTime || 0)}</p>
                  </div>
                  <Clock className="h-10 w-10 text-amber-500" />
                </div>
              </Card>
            </>
          )}
        </div>

        {/* Charts and Analytics */}
        <div className="mb-8 grid gap-6 md:grid-cols-2">
          {/* Scene Status Breakdown */}
          <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Scene Status Breakdown</h3>
            <div className="space-y-3">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-3 w-3 rounded-full bg-gray-500"></div>
                    <span className="text-sm text-gray-300">Not Started</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{scenesByStatus["Not Started"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-gray-500"
                    style={{ width: `${stats?.totalScenes ? (scenesByStatus["Not Started"] / stats.totalScenes) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Play className="h-3 w-3 text-amber-500" />
                    <span className="text-sm text-gray-300">In Progress</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{scenesByStatus["In Progress"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-amber-500"
                    style={{ width: `${stats?.totalScenes ? (scenesByStatus["In Progress"] / stats.totalScenes) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Pause className="h-3 w-3 text-blue-500" />
                    <span className="text-sm text-gray-300">Paused</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{scenesByStatus["Paused"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-blue-500"
                    style={{ width: `${stats?.totalScenes ? (scenesByStatus["Paused"] / stats.totalScenes) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    <span className="text-sm text-gray-300">Completed</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{scenesByStatus["Completed"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-green-500"
                    style={{ width: `${stats?.totalScenes ? (scenesByStatus["Completed"] / stats.totalScenes) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </Card>

          {/* Show Status Breakdown */}
          <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Show Status Distribution</h3>
            <div className="space-y-3">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                    <span className="text-sm text-gray-300">Pre-Production</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{showsByStatus["Pre-Production"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-blue-500"
                    style={{ width: `${stats?.totalShows ? (showsByStatus["Pre-Production"] / stats.totalShows) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-3 w-3 rounded-full bg-amber-500"></div>
                    <span className="text-sm text-gray-300">Shooting</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{showsByStatus["Shooting"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-amber-500"
                    style={{ width: `${stats?.totalShows ? (showsByStatus["Shooting"] / stats.totalShows) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-3 w-3 rounded-full bg-green-500"></div>
                    <span className="text-sm text-gray-300">Wrapped</span>
                  </div>
                  <span className="text-sm font-semibold text-white">{showsByStatus["Wrapped"]}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-800">
                  <div
                    className="h-full bg-green-500"
                    style={{ width: `${stats?.totalShows ? (showsByStatus["Wrapped"] / stats.totalShows) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Recent Activity */}
        {stats?.recentScenes && stats.recentScenes.length > 0 && (
          <Card className="mb-8 border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Recent Activity</h3>
            <div className="space-y-3">
              {stats.recentScenes.map((scene) => (
                <div key={scene.id} className="flex items-center justify-between rounded-lg border border-gray-800 p-3">
                  <div className="flex-1">
                    <Link href={`/shows/${scene.show.id}`} className="hover:text-amber-500">
                      <p className="font-medium text-white">{scene.name}</p>
                      <p className="text-sm text-gray-400">{scene.show.title} • Scene {scene.sceneNumber}</p>
                    </Link>
                  </div>
                  <div className={`rounded-full px-3 py-1 text-xs font-medium ${
                    scene.status === "Completed" ? "bg-green-500/10 text-green-400" :
                    scene.status === "In Progress" ? "bg-amber-500/10 text-amber-400" :
                    "bg-blue-500/10 text-blue-400"
                  }`}>
                    {scene.status}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Quick Actions */}
        <div className="grid gap-6 md:grid-cols-3">
          <Link href="/shows">
            <Card className="group cursor-pointer border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 transition-all hover:border-amber-500/50 hover:shadow-lg hover:shadow-amber-500/10">
              <Film className="mb-4 h-10 w-10 text-amber-500" />
              <h3 className="mb-2 text-xl font-semibold text-white">Manage Shows</h3>
              <p className="text-gray-400">View and manage all your production shows</p>
            </Card>
          </Link>

          {session.user?.role === "DEVELOPER" && (
            <Link href="/admin/users">
              <Card className="group cursor-pointer border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 transition-all hover:border-purple-500/50 hover:shadow-lg hover:shadow-purple-500/10">
                <Users className="mb-4 h-10 w-10 text-purple-500" />
                <h3 className="mb-2 text-xl font-semibold text-white">User Management</h3>
                <p className="text-gray-400">Add, edit, and manage user accounts</p>
              </Card>
            </Link>
          )}

          {(session.user?.role === "DEVELOPER" || session.user?.role === "ADMIN") && (
            <Link href="/admin/companies">
              <Card className="group cursor-pointer border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6 transition-all hover:border-green-500/50 hover:shadow-lg hover:shadow-green-500/10">
                <Building2 className="mb-4 h-10 w-10 text-green-500" />
                <h3 className="mb-2 text-xl font-semibold text-white">Companies</h3>
                <p className="text-gray-400">Manage production companies</p>
              </Card>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
