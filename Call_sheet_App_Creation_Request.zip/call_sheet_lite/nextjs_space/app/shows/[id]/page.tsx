
'use client';

import { useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';

export default function ShowPage() {
  const router = useRouter();
  const params = useParams();
  const showId = params.id as string;

  useEffect(() => {
    // Redirect to scenes page by default
    router.replace(`/shows/${showId}/scenes`);
  }, [router, showId]);

  return null;
}
