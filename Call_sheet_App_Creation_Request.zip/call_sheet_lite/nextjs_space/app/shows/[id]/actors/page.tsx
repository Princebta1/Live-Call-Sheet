'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { PlusCircle, Users, Loader2, Trash2, Edit, Mail, Phone, User } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { toast } from 'sonner';

export default function ActorsPage() {
  const params = useParams();
  const { data: session, status } = useSession() || {};
  const showId = params?.id as string;

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [deletingActor, setDeletingActor] = useState<any>(null);
  const [editingActor, setEditingActor] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    character: '',
    email: '',
    phone: '',
    notes: '',
    assignedProductionAdminId: '',
  });

  const { data: actors, refetch } = trpc.actors.list.useQuery(
    { showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
    }
  );

  // Fetch production admins for the show
  const { data: productionAdmins, isLoading: loadingProductionAdmins } = trpc.users.list.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
      select: (data) => data.filter((user: any) => 
        user.role === 'PRODUCTION_ADMIN' && user.assignedShowId === showId
      ),
    }
  );

  const createMutation = trpc.actors.create.useMutation({
    onSuccess: () => {
      toast.success('Actor added successfully');
      setIsCreateDialogOpen(false);
      setFormData({ name: '', role: '', character: '', email: '', phone: '', notes: '', assignedProductionAdminId: '' });
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to add actor');
    },
  });

  const updateMutation = trpc.actors.update.useMutation({
    onSuccess: () => {
      toast.success('Actor updated successfully');
      setIsEditDialogOpen(false);
      setEditingActor(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update actor');
    },
  });

  const deleteMutation = trpc.actors.delete.useMutation({
    onSuccess: () => {
      toast.success('Actor removed successfully');
      setDeletingActor(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to remove actor');
    },
  });

  const canManage =
    session?.user?.role === 'DEVELOPER' ||
    session?.user?.role === 'ADMIN' ||
    session?.user?.role === 'PRODUCTION_ADMIN';

  const handleCreate = () => {
    if (!formData.name || !formData.role) {
      toast.error('Please fill in name and role');
      return;
    }
    if (!formData.assignedProductionAdminId) {
      toast.error('Please select a Production Admin');
      return;
    }
    createMutation.mutate({
      showId,
      assignedProductionAdminId: formData.assignedProductionAdminId,
      name: formData.name,
      role: formData.role,
      character: formData.character || null,
      email: formData.email || null,
      phone: formData.phone || null,
      notes: formData.notes || null,
      photoUrl: null,
    });
  };

  const handleEdit = () => {
    if (!editingActor) return;
    updateMutation.mutate({
      id: editingActor.id,
      assignedProductionAdminId: formData.assignedProductionAdminId,
      name: formData.name,
      role: formData.role,
      character: formData.character || null,
      email: formData.email || null,
      phone: formData.phone || null,
      notes: formData.notes || null,
    });
  };

  const openEditDialog = (actor: any) => {
    setEditingActor(actor);
    setFormData({
      name: actor.name,
      role: actor.role,
      character: actor.character || '',
      email: actor.email || '',
      phone: actor.phone || '',
      notes: actor.notes || '',
      assignedProductionAdminId: actor.assignedProductionAdminId || '',
    });
    setIsEditDialogOpen(true);
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-xl font-semibold text-white">
          Actors ({actors?.length || 0})
        </h2>
        {canManage && (
          <Button
            onClick={() => setIsCreateDialogOpen(true)}
            className="bg-amber-600 hover:bg-amber-700"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Actor
          </Button>
        )}
      </div>

      {!actors || actors.length === 0 ? (
        <Card className="bg-gray-900/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="mb-4 h-12 w-12 text-gray-500" />
            <p className="text-gray-400">No actors added yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {actors.map((actor) => (
            <Card key={actor.id} className="bg-gray-900/50">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white">{actor.name}</h3>
                    <p className="text-sm text-amber-400">{actor.role}</p>
                    {actor.character && (
                      <p className="text-sm text-gray-300 italic">as {actor.character}</p>
                    )}
                    {actor.assignedProductionAdmin && (
                      <div className="mt-2 flex items-center gap-2 text-sm text-blue-400">
                        <User className="h-4 w-4" />
                        <span className="truncate">PA: {actor.assignedProductionAdmin.name}</span>
                      </div>
                    )}
                    {actor.email && (
                      <div className="mt-2 flex items-center gap-2 text-sm text-gray-400">
                        <Mail className="h-4 w-4" />
                        <span className="truncate">{actor.email}</span>
                      </div>
                    )}
                    {actor.phone && (
                      <div className="mt-1 flex items-center gap-2 text-sm text-gray-400">
                        <Phone className="h-4 w-4" />
                        <span>{actor.phone}</span>
                      </div>
                    )}
                    {actor.notes && (
                      <p className="mt-2 text-sm text-gray-300 line-clamp-2">{actor.notes}</p>
                    )}
                  </div>
                  {canManage && (
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditDialog(actor)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setDeletingActor(actor)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="bg-gray-900 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Actor</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="role">Role *</Label>
              <Input
                id="role"
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="bg-gray-800 border-gray-700"
                placeholder="e.g., Lead, Supporting, Background"
              />
            </div>
            <div>
              <Label htmlFor="character">Character</Label>
              <Input
                id="character"
                value={formData.character}
                onChange={(e) => setFormData({ ...formData, character: e.target.value })}
                className="bg-gray-800 border-gray-700"
                placeholder="Character name in the show"
              />
            </div>
            <div>
              <Label htmlFor="productionAdmin">Assigned Production Admin *</Label>
              {loadingProductionAdmins ? (
                <div className="flex items-center justify-center p-3 bg-gray-800 rounded-md border border-gray-700">
                  <Loader2 className="h-4 w-4 animate-spin text-amber-500 mr-2" />
                  <span className="text-sm text-gray-400">Loading...</span>
                </div>
              ) : productionAdmins && productionAdmins.length > 0 ? (
                <Select
                  value={formData.assignedProductionAdminId}
                  onValueChange={(value) => setFormData({ ...formData, assignedProductionAdminId: value })}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-700">
                    <SelectValue placeholder="Select a Production Admin" />
                  </SelectTrigger>
                  <SelectContent>
                    {productionAdmins.map((admin: any) => (
                      <SelectItem key={admin.id} value={admin.id}>
                        {admin.name} ({admin.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <div className="p-3 bg-gray-800 rounded-md border border-gray-700 text-sm text-gray-400">
                  No Production Admins assigned to this show. Please assign a Production Admin first.
                </div>
              )}
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleCreate}
                disabled={createMutation.isPending}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Add
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-gray-900 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Actor</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-name">Name *</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-role">Role *</Label>
              <Input
                id="edit-role"
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-character">Character</Label>
              <Input
                id="edit-character"
                value={formData.character}
                onChange={(e) => setFormData({ ...formData, character: e.target.value })}
                className="bg-gray-800 border-gray-700"
                placeholder="Character name in the show"
              />
            </div>
            <div>
              <Label htmlFor="edit-productionAdmin">Assigned Production Admin *</Label>
              {loadingProductionAdmins ? (
                <div className="flex items-center justify-center p-3 bg-gray-800 rounded-md border border-gray-700">
                  <Loader2 className="h-4 w-4 animate-spin text-amber-500 mr-2" />
                  <span className="text-sm text-gray-400">Loading...</span>
                </div>
              ) : productionAdmins && productionAdmins.length > 0 ? (
                <Select
                  value={formData.assignedProductionAdminId}
                  onValueChange={(value) => setFormData({ ...formData, assignedProductionAdminId: value })}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-700">
                    <SelectValue placeholder="Select a Production Admin" />
                  </SelectTrigger>
                  <SelectContent>
                    {productionAdmins.map((admin: any) => (
                      <SelectItem key={admin.id} value={admin.id}>
                        {admin.name} ({admin.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <div className="p-3 bg-gray-800 rounded-md border border-gray-700 text-sm text-gray-400">
                  No Production Admins assigned to this show. Please assign a Production Admin first.
                </div>
              )}
            </div>
            <div>
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-phone">Phone</Label>
              <Input
                id="edit-phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-notes">Notes</Label>
              <Textarea
                id="edit-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleEdit}
                disabled={updateMutation.isPending}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deletingActor}
        onOpenChange={() => setDeletingActor(null)}
      >
        <AlertDialogContent className="bg-gray-900 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Actor</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to remove {deletingActor?.name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteMutation.mutate({ id: deletingActor.id })}
              className="bg-red-600 hover:bg-red-700"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
