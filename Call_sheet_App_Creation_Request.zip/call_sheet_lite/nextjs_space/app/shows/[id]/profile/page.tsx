'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Film, Users, Calendar, Clock, Building2, User, Edit, PlusCircle, Trash2, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function ProfilePage() {
  const params = useParams();
  const { data: session, status } = useSession() || {};
  const showId = params?.id as string;

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [removingAdmin, setRemovingAdmin] = useState<any>(null);
  const [editFormData, setEditFormData] = useState({
    title: '',
    description: '',
    status: '',
  });

  const { data: show, refetch } = trpc.shows.getById.useQuery(
    { id: showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
    }
  );

  // Fetch all production admins (not assigned to any show or assigned to this show)
  const { data: availableProductionAdmins, isLoading: loadingAdmins } = trpc.users.list.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user && session?.user?.role === 'DEVELOPER',
      select: (data) => data.filter((user: any) => 
        user.role === 'PRODUCTION_ADMIN' && (!user.assignedShowId || user.assignedShowId === showId)
      ),
    }
  );

  const updateShowMutation = trpc.shows.update.useMutation({
    onSuccess: () => {
      toast.success('Show updated successfully');
      setIsEditDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update show');
    },
  });

  const assignProductionAdminMutation = trpc.shows.assignProductionAdmin.useMutation({
    onSuccess: () => {
      toast.success('Production Admin assigned successfully');
      setIsAssignDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to assign Production Admin');
    },
  });

  const removeProductionAdminMutation = trpc.shows.removeProductionAdmin.useMutation({
    onSuccess: () => {
      toast.success('Production Admin removed successfully');
      setRemovingAdmin(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to remove Production Admin');
    },
  });

  const isDeveloper = session?.user?.role === 'DEVELOPER';

  if (!show) return null;

  // Calculate statistics
  const totalScenes = show.scenes?.length || 0;
  const completedScenes = show.scenes?.filter((s) => s.status === 'Completed').length || 0;
  const inProgressScenes = show.scenes?.filter((s) => s.status === 'In Progress').length || 0;
  const totalProductionTime = show.scenes?.reduce((acc, scene) => acc + (scene.actualElapsedTime || 0), 0) || 0;

  const openEditDialog = () => {
    setEditFormData({
      title: show.title,
      description: show.description || '',
      status: show.status,
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = () => {
    if (!editFormData.title) {
      toast.error('Title is required');
      return;
    }
    updateShowMutation.mutate({
      id: showId,
      title: editFormData.title,
      description: editFormData.description || undefined,
      status: editFormData.status as "Pre-Production" | "Shooting" | "Wrapped" | undefined,
    });
  };

  const handleAssignAdmin = (userId: string) => {
    assignProductionAdminMutation.mutate({
      showId,
      userId,
    });
  };

  const handleRemoveAdmin = () => {
    if (!removingAdmin) return;
    removeProductionAdminMutation.mutate({
      showId,
      userId: removingAdmin.id,
    });
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div>
      <h2 className="mb-6 text-xl font-semibold text-white">Show Profile</h2>

      <div className="grid gap-6">
        {/* Basic Information */}
        <Card className="bg-gray-900/50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Film className="h-5 w-5 text-amber-500" />
                Basic Information
              </CardTitle>
              {isDeveloper && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={openEditDialog}
                  className="text-amber-500 hover:text-amber-400"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Title</label>
              <p className="text-lg font-semibold text-white">{show.title}</p>
            </div>
            {show.description && (
              <div>
                <label className="text-sm text-gray-400">Description</label>
                <p className="text-white">{show.description}</p>
              </div>
            )}
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="text-sm text-gray-400">Status</label>
                <div className="mt-1">
                  <Badge variant="outline">{show.status}</Badge>
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400">Active Status</label>
                <div className="mt-1">
                  <Badge variant={show.isActive ? 'default' : 'destructive'}>
                    {show.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400">Approval Status</label>
                <div className="mt-1">
                  <Badge variant={show.isApproved ? 'default' : 'secondary'}>
                    {show.isApproved ? 'Approved' : 'Pending Approval'}
                  </Badge>
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400">Created</label>
                <p className="text-white">{format(new Date(show.createdAt), 'PPP')}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Company Information */}
        <Card className="bg-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-amber-500" />
              Company Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            {show.company && (
              <div>
                <p className="text-lg font-semibold text-white">{show.company.name}</p>
                {show.company.description && (
                  <p className="mt-2 text-gray-400">{show.company.description}</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Creator Information */}
        <Card className="bg-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-amber-500" />
              Creator Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            {show.creator && (
              <div className="flex items-center gap-3">
                <div>
                  <p className="font-semibold text-white">{show.creator.name}</p>
                  <p className="text-sm text-gray-400">{show.creator.email}</p>
                </div>
                <Badge>{show.creator.role}</Badge>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Production Statistics */}
        <Card className="bg-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-amber-500" />
              Production Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-lg border border-gray-700 bg-gray-800/50 p-4">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Film className="h-4 w-4" />
                  Total Scenes
                </div>
                <p className="mt-2 text-3xl font-bold text-white">{totalScenes}</p>
              </div>
              <div className="rounded-lg border border-gray-700 bg-gray-800/50 p-4">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Clock className="h-4 w-4" />
                  Completed
                </div>
                <p className="mt-2 text-3xl font-bold text-green-400">{completedScenes}</p>
              </div>
              <div className="rounded-lg border border-gray-700 bg-gray-800/50 p-4">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Users className="h-4 w-4" />
                  In Progress
                </div>
                <p className="mt-2 text-3xl font-bold text-amber-400">{inProgressScenes}</p>
              </div>
              <div className="rounded-lg border border-gray-700 bg-gray-800/50 p-4">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Clock className="h-4 w-4" />
                  Total Time
                </div>
                <p className="mt-2 text-2xl font-bold text-white">
                  {formatTime(totalProductionTime)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Production Admins */}
        <Card className="bg-gray-900/50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-amber-500" />
                Production Admins
              </CardTitle>
              {isDeveloper && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsAssignDialogOpen(true)}
                  className="text-amber-500 hover:text-amber-400"
                >
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Assign
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {show.productionAdmins && show.productionAdmins.length > 0 ? (
              <div className="space-y-3">
                {show.productionAdmins.map((admin) => (
                  <div
                    key={admin.id}
                    className="flex items-center justify-between rounded-lg border border-gray-700 bg-gray-800/50 p-3"
                  >
                    <div>
                      <p className="font-semibold text-white">{admin.name}</p>
                      <p className="text-sm text-gray-400">{admin.email}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge>{admin.role}</Badge>
                      {isDeveloper && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setRemovingAdmin(admin)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-400">No Production Admins assigned to this show.</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Edit Show Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>Edit Show Information</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                value={editFormData.title}
                onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={editFormData.description}
                onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                rows={3}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select
                value={editFormData.status}
                onValueChange={(value) => setEditFormData({ ...editFormData, status: value })}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pre-Production">Pre-Production</SelectItem>
                  <SelectItem value="Shooting">Shooting</SelectItem>
                  <SelectItem value="Wrapped">Wrapped</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleUpdate}
                disabled={updateShowMutation.isPending}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {updateShowMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Assign Production Admin Dialog */}
      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent className="bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>Assign Production Admin</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {loadingAdmins ? (
              <div className="flex items-center justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin text-amber-500" />
              </div>
            ) : availableProductionAdmins && availableProductionAdmins.length > 0 ? (
              <div className="space-y-2">
                <Label>Select Production Admin</Label>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {availableProductionAdmins.map((admin: any) => (
                    <div
                      key={admin.id}
                      className="flex items-center justify-between rounded-lg border border-gray-700 bg-gray-800/50 p-3 hover:bg-gray-800 cursor-pointer"
                      onClick={() => handleAssignAdmin(admin.id)}
                    >
                      <div>
                        <p className="font-semibold text-white">{admin.name}</p>
                        <p className="text-sm text-gray-400">{admin.email}</p>
                      </div>
                      {assignProductionAdminMutation.isPending && (
                        <Loader2 className="h-4 w-4 animate-spin text-amber-500" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-400">
                No available Production Admins. All Production Admins are already assigned to other shows.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Remove Production Admin Confirmation */}
      <AlertDialog open={!!removingAdmin} onOpenChange={() => setRemovingAdmin(null)}>
        <AlertDialogContent className="bg-gray-900 text-white border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Production Admin</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to remove {removingAdmin?.name} from this show?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-gray-800 hover:bg-gray-700">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRemoveAdmin}
              className="bg-red-600 hover:bg-red-700"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
