'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Calendar as CalendarIcon, PlusCircle, Edit, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { toast } from 'sonner';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, subMonths, startOfWeek, endOfWeek } from 'date-fns';

export default function CalendarPage() {
  const params = useParams();
  const { data: session, status } = useSession() || {};
  const showId = params?.id as string;

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [deletingScene, setDeletingScene] = useState<any>(null);
  const [editingScene, setEditingScene] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    sceneNumber: '',
    name: '',
    description: '',
    estimatedDuration: '',
    scheduledDate: '',
    status: 'Not Started',
  });
  const [selectedActorIds, setSelectedActorIds] = useState<string[]>([]);

  const { data: show, refetch } = trpc.shows.getById.useQuery(
    { id: showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
    }
  );

  const { data: actors } = trpc.actors.list.useQuery(
    { showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
    }
  );

  const createSceneMutation = trpc.scenes.create.useMutation({
    onSuccess: () => {
      toast.success('Scene created successfully');
      setIsCreateDialogOpen(false);
      setFormData({ sceneNumber: '', name: '', description: '', estimatedDuration: '', scheduledDate: '', status: 'Not Started' });
      setSelectedActorIds([]);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to create scene');
    },
  });

  const updateSceneMutation = trpc.scenes.update.useMutation({
    onSuccess: () => {
      toast.success('Scene updated successfully');
      setIsEditDialogOpen(false);
      setEditingScene(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update scene');
    },
  });

  const deleteSceneMutation = trpc.scenes.delete.useMutation({
    onSuccess: () => {
      toast.success('Scene deleted successfully');
      setDeletingScene(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete scene');
    },
  });

  const canManageScenes =
    session?.user?.role === 'ADMIN' ||
    session?.user?.role === 'PRODUCTION_ADMIN' ||
    session?.user?.role === 'DEVELOPER';

  const handleCreateScene = () => {
    if (!formData.sceneNumber || !formData.name || !formData.scheduledDate) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (selectedActorIds.length === 0) {
      toast.error('Please select at least one actor for this scene');
      return;
    }

    const estimatedDurationInSeconds = formData.estimatedDuration 
      ? parseInt(formData.estimatedDuration) * 60 
      : null;

    createSceneMutation.mutate({
      showId,
      sceneNumber: formData.sceneNumber,
      name: formData.name,
      description: formData.description || null,
      estimatedDuration: estimatedDurationInSeconds,
      scheduledDate: new Date(formData.scheduledDate).toISOString(),
      status: formData.status,
      actorIds: selectedActorIds,
    });
  };

  const handleEditScene = () => {
    if (!editingScene) return;

    const estimatedDurationInSeconds = formData.estimatedDuration 
      ? parseInt(formData.estimatedDuration) * 60 
      : null;

    updateSceneMutation.mutate({
      id: editingScene.id,
      sceneNumber: formData.sceneNumber,
      name: formData.name,
      description: formData.description || null,
      estimatedDuration: estimatedDurationInSeconds,
      scheduledDate: formData.scheduledDate ? new Date(formData.scheduledDate).toISOString() : null,
      status: formData.status,
    });
  };

  const openCreateDialog = (date?: Date) => {
    setFormData({
      ...formData,
      scheduledDate: date ? format(date, 'yyyy-MM-dd') : '',
    });
    setIsCreateDialogOpen(true);
  };

  const openEditDialog = (scene: any) => {
    setEditingScene(scene);
    setFormData({
      sceneNumber: scene.sceneNumber,
      name: scene.name,
      description: scene.description || '',
      estimatedDuration: scene.estimatedDuration ? String(Math.floor(scene.estimatedDuration / 60)) : '',
      scheduledDate: scene.scheduledDate ? format(new Date(scene.scheduledDate), 'yyyy-MM-dd') : '',
      status: scene.status,
    });
    setIsEditDialogOpen(true);
  };

  // Generate calendar days
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Group scenes by date
  const scenesByDate = (show?.scenes || []).reduce((acc: Record<string, any[]>, scene) => {
    if (scene.scheduledDate) {
      const dateKey = format(new Date(scene.scheduledDate), 'yyyy-MM-dd');
      if (!acc[dateKey]) acc[dateKey] = [];
      acc[dateKey].push(scene);
    }
    return acc;
  }, {});

  // Get scenes for selected date
  const selectedDateScenes = selectedDate 
    ? scenesByDate[format(selectedDate, 'yyyy-MM-dd')] || []
    : [];

  const statusColors: Record<string, string> = {
    'Not Started': 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    'In Progress': 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    'Paused': 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    'Completed': 'bg-green-500/10 text-green-400 border-green-500/30',
  };

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">
          {format(currentMonth, 'MMMM yyyy')}
        </h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentMonth(new Date())}
          >
            Today
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          {canManageScenes && (
            <Button
              onClick={() => openCreateDialog()}
              className="ml-4 bg-amber-600 hover:bg-amber-700"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Scene
            </Button>
          )}
        </div>
      </div>

      {/* Calendar Grid */}
      <Card className="bg-gray-900/50">
        <CardContent className="p-6">
          {/* Day headers */}
          <div className="grid grid-cols-7 gap-2 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-sm font-semibold text-gray-400 p-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar days */}
          <div className="grid grid-cols-7 gap-2">
            {calendarDays.map((day, index) => {
              const dateKey = format(day, 'yyyy-MM-dd');
              const scenesForDay = scenesByDate[dateKey] || [];
              const isCurrentMonth = isSameMonth(day, currentMonth);
              const isToday = isSameDay(day, new Date());
              const isSelected = selectedDate && isSameDay(day, selectedDate);

              return (
                <div
                  key={index}
                  onClick={() => setSelectedDate(day)}
                  className={`min-h-[100px] p-2 border rounded-lg cursor-pointer transition-colors ${
                    isCurrentMonth ? 'bg-gray-800 border-gray-700' : 'bg-gray-900/50 border-gray-800'
                  } ${isToday ? 'border-amber-500' : ''} ${isSelected ? 'ring-2 ring-amber-500' : ''} hover:border-amber-500/50`}
                >
                  <div className={`text-sm font-medium mb-1 ${
                    isToday ? 'text-amber-400' : isCurrentMonth ? 'text-white' : 'text-gray-600'
                  }`}>
                    {format(day, 'd')}
                  </div>
                  {scenesForDay.length > 0 && (
                    <div className="space-y-1">
                      {scenesForDay.slice(0, 2).map((scene) => (
                        <div
                          key={scene.id}
                          className="text-xs truncate p-1 rounded bg-amber-500/20 text-amber-300"
                        >
                          {scene.sceneNumber}: {scene.name}
                        </div>
                      ))}
                      {scenesForDay.length > 2 && (
                        <div className="text-xs text-gray-400">
                          +{scenesForDay.length - 2} more
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Selected Date Details */}
      {selectedDate && (
        <Card className="bg-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5 text-amber-500" />
                {format(selectedDate, 'EEEE, MMMM d, yyyy')}
              </span>
              {canManageScenes && (
                <Button
                  size="sm"
                  onClick={() => openCreateDialog(selectedDate)}
                  className="bg-amber-600 hover:bg-amber-700"
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Scene
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDateScenes.length === 0 ? (
              <p className="text-gray-400 text-center py-8">No scenes scheduled for this date</p>
            ) : (
              <div className="space-y-3">
                {selectedDateScenes.map((scene) => (
                  <div
                    key={scene.id}
                    className="flex items-start justify-between rounded-lg border border-gray-700 bg-gray-800/50 p-4"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-white">
                          Scene {scene.sceneNumber}: {scene.name}
                        </h4>
                        <Badge className={statusColors[scene.status]}>
                          {scene.status}
                        </Badge>
                      </div>
                      {scene.description && (
                        <p className="text-sm text-gray-400 mb-2">{scene.description}</p>
                      )}
                      {scene.sceneActors && scene.sceneActors.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-2">
                          {scene.sceneActors.map((sa: any) => (
                            <Badge
                              key={sa.actor.id}
                              variant="outline"
                              className="text-xs bg-amber-500/10 text-amber-400 border-amber-500/30"
                            >
                              {sa.actor.name}
                            </Badge>
                          ))}
                        </div>
                      )}
                      {scene.estimatedDuration && (
                        <p className="text-xs text-gray-500">
                          Est. Duration: {Math.floor(scene.estimatedDuration / 60)}min
                        </p>
                      )}
                    </div>
                    {canManageScenes && (
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openEditDialog(scene)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeletingScene(scene)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Create Scene Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="bg-gray-900 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Scene</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="sceneNumber">Scene Number *</Label>
              <Input
                id="sceneNumber"
                value={formData.sceneNumber}
                onChange={(e) => setFormData({ ...formData, sceneNumber: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="name">Scene Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="scheduledDate">Scheduled Date *</Label>
              <Input
                id="scheduledDate"
                type="date"
                value={formData.scheduledDate}
                onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="estimatedDuration">Estimated Duration (minutes)</Label>
              <Input
                id="estimatedDuration"
                type="number"
                value={formData.estimatedDuration}
                onChange={(e) => setFormData({ ...formData, estimatedDuration: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label>Cast Members *</Label>
              <div className="rounded-md border border-gray-700 bg-gray-800 p-3 max-h-48 overflow-y-auto">
                {actors && actors.length > 0 ? (
                  <div className="space-y-2">
                    {actors.map((actor: any) => (
                      <div key={actor.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`create-actor-${actor.id}`}
                          checked={selectedActorIds.includes(actor.id)}
                          onCheckedChange={() => {
                            setSelectedActorIds((prev) =>
                              prev.includes(actor.id)
                                ? prev.filter((id) => id !== actor.id)
                                : [...prev, actor.id]
                            );
                          }}
                        />
                        <label
                          htmlFor={`create-actor-${actor.id}`}
                          className="text-sm cursor-pointer flex-1"
                        >
                          {actor.name} <span className="text-gray-500">({actor.role})</span>
                        </label>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-400 text-center py-2">
                    No actors available. Please add actors to this show first.
                  </p>
                )}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Select at least one actor who will be in this scene
              </p>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Not Started">Not Started</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Paused">Paused</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateScene}
                disabled={selectedActorIds.length === 0 || createSceneMutation.isPending}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {createSceneMutation.isPending ? "Creating..." : "Create"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Scene Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-gray-900 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Scene</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-sceneNumber">Scene Number *</Label>
              <Input
                id="edit-sceneNumber"
                value={formData.sceneNumber}
                onChange={(e) => setFormData({ ...formData, sceneNumber: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-name">Scene Name *</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-scheduledDate">Scheduled Date</Label>
              <Input
                id="edit-scheduledDate"
                type="date"
                value={formData.scheduledDate}
                onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-estimatedDuration">Estimated Duration (minutes)</Label>
              <Input
                id="edit-estimatedDuration"
                type="number"
                value={formData.estimatedDuration}
                onChange={(e) => setFormData({ ...formData, estimatedDuration: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Label htmlFor="edit-status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Not Started">Not Started</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Paused">Paused</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleEditScene}
                disabled={updateSceneMutation.isPending}
                className="bg-amber-600 hover:bg-amber-700"
              >
                Update
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deletingScene}
        onOpenChange={() => setDeletingScene(null)}
      >
        <AlertDialogContent className="bg-gray-900 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Scene</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to delete "{deletingScene?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteSceneMutation.mutate({ id: deletingScene.id })}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
