
'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { PlusCircle, Film } from 'lucide-react';
import { CreateSceneModal } from '@/components/create-scene-modal';
import { SceneCard } from '@/components/scene-card';
import { trpc } from '@/lib/trpc-client';

export default function ScenesPage() {
  const params = useParams();
  const { data: session, status } = useSession() || {};
  const [isModalOpen, setIsModalOpen] = useState(false);

  const showId = params?.id as string;

  const { data: show, refetch } = trpc.shows.getById.useQuery(
    { id: showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
    }
  );

  const canManageScenes =
    session?.user?.role === 'ADMIN' ||
    session?.user?.role === 'PRODUCTION_ADMIN' ||
    session?.user?.role === 'DEVELOPER';

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-xl font-semibold text-white">
          Scenes ({show?.scenes?.length || 0})
        </h2>
        {canManageScenes && (
          <Button
            onClick={() => setIsModalOpen(true)}
            className="bg-amber-600 hover:bg-amber-700"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Scene
          </Button>
        )}
      </div>

      {!show?.scenes || show.scenes.length === 0 ? (
        <div className="rounded-lg border border-gray-800 bg-gray-900/50 p-12 text-center">
          <div className="mx-auto max-w-md">
            <Film className="mx-auto mb-4 h-12 w-12 text-gray-500" />
            <h3 className="text-xl font-semibold text-white">No scenes yet</h3>
            <p className="mt-2 text-gray-400">
              {canManageScenes
                ? 'Add your first scene to start tracking production time.'
                : 'Scenes will appear here once added by Admin or Production Admin.'}
            </p>
            {canManageScenes && (
              <Button
                onClick={() => setIsModalOpen(true)}
                className="mt-6 bg-amber-600 hover:bg-amber-700"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Scene
              </Button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid gap-4">
          {show.scenes.map((scene) => (
            <SceneCard key={scene.id} scene={scene} onUpdate={() => refetch()} />
          ))}
        </div>
      )}

      {isModalOpen && showId && (
        <CreateSceneModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          showId={showId}
          onSuccess={() => {
            setIsModalOpen(false);
            refetch();
          }}
        />
      )}
    </div>
  );
}
