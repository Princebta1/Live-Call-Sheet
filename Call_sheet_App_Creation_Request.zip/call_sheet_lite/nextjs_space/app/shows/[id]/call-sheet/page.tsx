
'use client';

import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { useState } from 'react';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { FileText, Download, Loader2, Calendar, Clock } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function CallSheetGeneratorPage() {
  const router = useRouter();
  const params = useParams();
  const showId = params?.id as string;
  const { data: session, status } = useSession() || {};
  
  const [startDate, setStartDate] = useState(() => {
    const today = new Date();
    return format(today, 'yyyy-MM-dd');
  });
  
  const [endDate, setEndDate] = useState(() => {
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    return format(nextWeek, 'yyyy-MM-dd');
  });

  const { data: callSheetData, isLoading: isGenerating, refetch } = trpc.callSheet.generate.useQuery(
    {
      showId,
      startDate,
      endDate,
    },
    {
      enabled: false, // Don't auto-fetch, wait for user to click Generate
    }
  );

  const handleGenerate = () => {
    if (!startDate || !endDate) {
      toast.error('Please select both start and end dates');
      return;
    }

    if (new Date(startDate) > new Date(endDate)) {
      toast.error('Start date must be before end date');
      return;
    }

    refetch();
  };

  const handlePrint = () => {
    window.print();
  };

  const statusColors: Record<string, string> = {
    'Not Started': 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    'In Progress': 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    'Paused': 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    'Completed': 'bg-green-500/10 text-green-400 border-green-500/30',
  };

  return (
    <div className="container mx-auto px-4 py-4 sm:py-8">
      <div className="mb-6 print:hidden">
        <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center gap-3">
          <FileText className="h-6 w-6 sm:h-8 sm:w-8 text-amber-500" />
          Call Sheet Generator
        </h1>
        <p className="mt-2 text-gray-400">
          Generate a call sheet for scheduled scenes within a date range
        </p>
      </div>

      {/* Date Selection */}
      <Card className="mb-6 bg-gray-900/50 border-gray-800 print:hidden">
        <CardHeader>
          <CardTitle className="text-white">Select Date Range</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <Label htmlFor="startDate" className="text-gray-300">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label htmlFor="endDate" className="text-gray-300">End Date</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="bg-amber-600 hover:bg-amber-700"
            >
              {isGenerating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Generate Call Sheet
            </Button>
            {callSheetData && (
              <Button
                onClick={handlePrint}
                variant="outline"
                className="border-gray-700 hover:bg-gray-800"
              >
                <Download className="mr-2 h-4 w-4" />
                Print / Download
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Call Sheet Content */}
      {callSheetData && (
        <div className="space-y-6">
          {/* Header */}
          <Card className="bg-gray-900/50 border-gray-800 print:border-black print:bg-white">
            <CardHeader className="text-center border-b border-gray-800 print:border-black">
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="relative h-32 w-32 sm:h-40 sm:w-40">
                    <Image
                      src="/logo.png"
                      alt="Call Sheet Logo"
                      fill
                      className="object-contain drop-shadow-lg"
                      priority
                    />
                  </div>
                </div>
                <h2 className="text-xl font-semibold text-amber-500 print:text-black">
                  {callSheetData.show.title}
                </h2>
                <div className="text-gray-400 print:text-black">
                  <p className="font-medium">{callSheetData.show.company.name}</p>
                  <p className="text-sm">
                    {format(new Date(startDate), 'MMMM d, yyyy')} - {format(new Date(endDate), 'MMMM d, yyyy')}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-gray-400 print:text-gray-700 text-sm">Total Scenes</p>
                  <p className="text-2xl font-bold text-white print:text-black">{callSheetData.totalScenes}</p>
                </div>
                <div>
                  <p className="text-gray-400 print:text-gray-700 text-sm">Production Status</p>
                  <p className="text-2xl font-bold text-amber-500 print:text-black">{callSheetData.show.status}</p>
                </div>
                <div>
                  <p className="text-gray-400 print:text-gray-700 text-sm">Cast Members</p>
                  <p className="text-2xl font-bold text-white print:text-black">{callSheetData.actors.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Scenes by Date */}
          {Object.keys(callSheetData.scenesByDate).length === 0 ? (
            <Card className="bg-gray-900/50 border-gray-800 print:border-black print:bg-white">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="mb-4 h-12 w-12 text-gray-500" />
                <p className="text-gray-400 print:text-black">No scenes scheduled in this date range</p>
              </CardContent>
            </Card>
          ) : (
            Object.entries(callSheetData.scenesByDate).map(([date, scenes]) => (
              <Card key={date} className="bg-gray-900/50 border-gray-800 print:border-black print:bg-white print:break-inside-avoid">
                <CardHeader className="bg-amber-600/10 print:bg-gray-100">
                  <CardTitle className="text-white print:text-black flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    {format(new Date(date), 'EEEE, MMMM d, yyyy')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {scenes.map((scene: any) => (
                      <div key={scene.id} className="border-b border-gray-800 print:border-gray-300 last:border-0 pb-6 last:pb-0">
                        <div className="flex flex-wrap items-start justify-between gap-2 mb-3">
                          <div>
                            <h3 className="text-lg font-semibold text-white print:text-black">
                              Scene {scene.sceneNumber}: {scene.name}
                            </h3>
                            {scene.description && (
                              <p className="text-gray-400 print:text-gray-700 mt-1">
                                {scene.description}
                              </p>
                            )}
                          </div>
                          <Badge className={`${statusColors[scene.status]} print:border-black print:bg-white print:text-black flex-shrink-0`}>
                            {scene.status}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                          {scene.estimatedDuration && (
                            <div className="flex items-center gap-2 text-gray-400 print:text-black">
                              <Clock className="h-4 w-4 flex-shrink-0" />
                              <span className="text-sm">
                                Est. Duration: {Math.floor(scene.estimatedDuration / 60)} minutes
                              </span>
                            </div>
                          )}
                        </div>

                        {scene.sceneActors && scene.sceneActors.length > 0 && (
                          <div>
                            <h4 className="text-sm font-semibold text-gray-300 print:text-black mb-2">
                              Cast ({scene.sceneActors.length}):
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {scene.sceneActors.map((sa: any) => (
                                <Badge key={sa.id} variant="outline" className="border-gray-700 text-gray-300 print:border-black print:text-black">
                                  {sa.actor.name} ({sa.actor.role})
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}

          {/* Cast List */}
          {callSheetData.actors.length > 0 && (
            <Card className="bg-gray-900/50 border-gray-800 print:border-black print:bg-white print:break-inside-avoid">
              <CardHeader>
                <CardTitle className="text-white print:text-black">Complete Cast List</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {callSheetData.actors.map((actor: any) => (
                    <div key={actor.id} className="p-3 bg-gray-800 print:bg-gray-100 rounded-lg print:border print:border-gray-300">
                      <p className="font-semibold text-white print:text-black">{actor.name}</p>
                      <p className="text-sm text-gray-400 print:text-gray-700">{actor.role}</p>
                      {actor.email && (
                        <p className="text-xs text-gray-500 print:text-gray-600 mt-1">{actor.email}</p>
                      )}
                      {actor.phone && (
                        <p className="text-xs text-gray-500 print:text-gray-600">{actor.phone}</p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            background: white;
          }
          .print\\:hidden {
            display: none !important;
          }
          .print\\:text-black {
            color: black !important;
          }
          .print\\:bg-white {
            background-color: white !important;
          }
          .print\\:border-black {
            border-color: black !important;
          }
          .print\\:break-inside-avoid {
            break-inside: avoid;
          }
        }
      `}</style>
    </div>
  );
}
