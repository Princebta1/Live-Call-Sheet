
'use client';

import { useSession } from 'next-auth/react';
import { useRouter, useParams, usePathname } from 'next/navigation';
import { useEffect } from 'react';
import { trpc } from '@/lib/trpc-client';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Film, ArrowLeft, Calendar, Megaphone, Users, MessageSquare, User, FileText } from 'lucide-react';
import Link from 'next/link';

export default function ShowLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const params = useParams();
  const pathname = usePathname();
  const showId = params.id as string;
  const { data: session, status } = useSession() || {};

  const { data: show, isLoading } = trpc.shows.getById.useQuery(
    { id: showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
    }
  );

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    }
  }, [status, router]);

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!show) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <Film className="h-16 w-16 text-gray-500" />
        <h2 className="text-2xl font-bold text-white">Show Not Found</h2>
        <Button onClick={() => router.push('/shows')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Shows
        </Button>
      </div>
    );
  }

  // Determine current tab from pathname
  const getCurrentTab = () => {
    if (pathname?.includes('/calendar')) return 'calendar';
    if (pathname?.includes('/call-sheet')) return 'call-sheet';
    if (pathname?.includes('/announcements')) return 'announcements';
    if (pathname?.includes('/actors')) return 'actors';
    if (pathname?.includes('/messages')) return 'messages';
    if (pathname?.includes('/profile')) return 'profile';
    return 'scenes';
  };

  const currentTab = getCurrentTab();

  // Role-based permissions
  const userRole = session?.user?.role;
  const canManage = userRole === 'DEVELOPER' || userRole === 'ADMIN' || userRole === 'PRODUCTION_ADMIN';

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Show Header */}
      <div className="mb-6">
        <Button
          variant="ghost"
          onClick={() => router.push('/shows')}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Shows
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="mb-2 flex items-center gap-2 text-2xl">
                  <Film className="h-6 w-6 text-amber-500" />
                  {show.title}
                </CardTitle>
                {show.description && (
                  <p className="text-gray-400">{show.description}</p>
                )}
              </div>
              <div className="flex flex-col gap-2">
                <Badge variant={show.isActive ? 'default' : 'destructive'}>
                  {show.isActive ? 'Active' : 'Inactive'}
                </Badge>
                <Badge variant={show.isApproved ? 'default' : 'secondary'}>
                  {show.isApproved ? 'Approved' : 'Pending'}
                </Badge>
                <Badge variant="outline">{show.status}</Badge>
              </div>
            </div>
          </CardHeader>
        </Card>
      </div>

      {/* Navigation Tabs */}
      <Tabs value={currentTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 bg-gray-900">
          <TabsTrigger 
            value="scenes" 
            onClick={() => router.push(`/shows/${showId}/scenes`)}
            className="data-[state=active]:bg-amber-600"
          >
            <Film className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Scenes</span>
          </TabsTrigger>
          <TabsTrigger 
            value="calendar" 
            onClick={() => router.push(`/shows/${showId}/calendar`)}
            className="data-[state=active]:bg-amber-600"
          >
            <Calendar className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Calendar</span>
          </TabsTrigger>
          <TabsTrigger 
            value="call-sheet" 
            onClick={() => router.push(`/shows/${showId}/call-sheet`)}
            className="data-[state=active]:bg-amber-600"
          >
            <FileText className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Call Sheet</span>
          </TabsTrigger>
          <TabsTrigger 
            value="announcements" 
            onClick={() => router.push(`/shows/${showId}/announcements`)}
            className="data-[state=active]:bg-amber-600"
          >
            <Megaphone className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Announcements</span>
          </TabsTrigger>
          <TabsTrigger 
            value="actors" 
            onClick={() => router.push(`/shows/${showId}/actors`)}
            className="data-[state=active]:bg-amber-600"
          >
            <Users className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Actors</span>
          </TabsTrigger>
          <TabsTrigger 
            value="messages" 
            onClick={() => router.push(`/shows/${showId}/messages`)}
            className="data-[state=active]:bg-amber-600"
          >
            <MessageSquare className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Messages</span>
          </TabsTrigger>
          <TabsTrigger 
            value="profile" 
            onClick={() => router.push(`/shows/${showId}/profile`)}
            className="data-[state=active]:bg-amber-600"
          >
            <User className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Profile</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Page Content */}
      <div>{children}</div>
    </div>
  );
}
