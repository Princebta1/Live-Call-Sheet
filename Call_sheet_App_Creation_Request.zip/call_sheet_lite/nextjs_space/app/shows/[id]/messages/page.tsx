'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Send, Trash2 } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function MessagesPage() {
  const params = useParams();
  const { data: session, status } = useSession() || {};
  const showId = params?.id as string;
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [message, setMessage] = useState('');

  const { data: messages, refetch } = trpc.messages.list.useQuery(
    { showId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!showId,
      refetchInterval: 5000, // Auto-refresh every 5 seconds
    }
  );

  const createMutation = trpc.messages.create.useMutation({
    onSuccess: () => {
      setMessage('');
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to send message');
    },
  });

  const deleteMutation = trpc.messages.delete.useMutation({
    onSuccess: () => {
      toast.success('Message deleted');
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete message');
    },
  });

  const handleSend = () => {
    if (!message.trim()) return;
    createMutation.mutate({ showId, content: message.trim() });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const canDeleteMessage = (msg: any) => {
    const isOwner = msg.sender.id === session?.user?.id;
    const isAdmin = ['DEVELOPER', 'ADMIN', 'PRODUCTION_ADMIN'].includes(session?.user?.role || '');
    return isOwner || isAdmin;
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const roleColors: Record<string, string> = {
    DEVELOPER: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    ADMIN: 'bg-red-500/10 text-red-400 border-red-500/30',
    PRODUCTION_ADMIN: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    CREW: 'bg-green-500/10 text-green-400 border-green-500/30',
    ACTOR: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  };

  return (
    <div className="flex h-[calc(100vh-350px)] flex-col">
      {/* Messages List */}
      <Card className="flex-1 overflow-hidden bg-gray-900/50">
        <CardContent className="h-full overflow-y-auto p-6">
          {!messages || messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center">
              <MessageSquare className="mb-4 h-12 w-12 text-gray-500" />
              <p className="text-gray-400">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${
                    msg.sender.id === session?.user?.id ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg p-4 ${
                      msg.sender.id === session?.user?.id
                        ? 'bg-amber-600/20 border border-amber-500/30'
                        : 'bg-gray-800 border border-gray-700'
                    }`}
                  >
                    <div className="mb-2 flex items-center gap-2">
                      <span className="font-semibold text-white">{msg.sender.name}</span>
                      <Badge className={roleColors[msg.sender.role]}>
                        {msg.sender.role.replace('_', ' ')}
                      </Badge>
                      {canDeleteMessage(msg) && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="ml-auto h-6 w-6 p-0 text-red-400 hover:text-red-300"
                          onClick={() => deleteMutation.mutate({ id: msg.id })}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                    <p className="text-gray-200 whitespace-pre-wrap">{msg.content}</p>
                    <p className="mt-2 text-xs text-gray-500">
                      {format(new Date(msg.createdAt), 'PPp')}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Message Input */}
      <div className="mt-4 flex gap-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type a message..."
          className="flex-1 bg-gray-800 border-gray-700"
        />
        <Button
          onClick={handleSend}
          disabled={!message.trim() || createMutation.isPending}
          className="bg-amber-600 hover:bg-amber-700"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
