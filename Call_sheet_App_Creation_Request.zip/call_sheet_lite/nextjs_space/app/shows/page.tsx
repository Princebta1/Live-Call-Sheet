
"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Loader2 } from "lucide-react";
import { CreateShowModal } from "@/components/create-show-modal";
import { ShowCard } from "@/components/show-card";
import { trpc } from "@/lib/trpc-client";
import { toast } from "sonner";

export default function ShowsPage() {
  const router = useRouter();
  const { data: session } = useSession() || {};
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedShow, setSelectedShow] = useState<any>(null);
  const [editFormData, setEditFormData] = useState({
    title: "",
    description: "",
    status: "Pre-Production" as "Pre-Production" | "Shooting" | "Wrapped",
  });

  const { data: shows, isLoading, refetch } = trpc.shows.list.useQuery();

  const updateShowMutation = trpc.shows.update.useMutation({
    onSuccess: () => {
      toast.success("Show updated successfully");
      setIsEditModalOpen(false);
      setSelectedShow(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update show");
    },
  });

  const deleteShowMutation = trpc.shows.delete.useMutation({
    onSuccess: () => {
      toast.success("Show deleted successfully");
      setIsDeleteDialogOpen(false);
      setSelectedShow(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete show");
    },
  });

  const canCreateShow = session?.user?.role === "ADMIN" || session?.user?.role === "PRODUCTION_ADMIN" || session?.user?.role === "DEVELOPER";

  const handleEdit = (show: any) => {
    setSelectedShow(show);
    setEditFormData({
      title: show.title,
      description: show.description || "",
      status: show.status,
    });
    setIsEditModalOpen(true);
  };

  const handleDelete = (showId: string) => {
    const show = shows?.find(s => s.id === showId);
    setSelectedShow(show);
    setIsDeleteDialogOpen(true);
  };

  const handleEditSubmit = () => {
    if (!selectedShow) return;

    updateShowMutation.mutate({
      id: selectedShow.id,
      ...editFormData,
    });
  };

  const handleDeleteConfirm = () => {
    if (!selectedShow) return;

    deleteShowMutation.mutate({
      id: selectedShow.id,
    });
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <div className="container mx-auto px-4 py-4 sm:py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">Productions</h1>
            <p className="mt-2 text-gray-400">
              Manage your film and TV production shows
            </p>
          </div>
          {canCreateShow && (
            <Button
              onClick={() => setIsCreateModalOpen(true)}
              className="bg-amber-600 hover:bg-amber-700"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              New Show
            </Button>
          )}
        </div>

        {!shows || shows.length === 0 ? (
          <div className="rounded-lg border border-gray-800 bg-gray-900/50 p-12 text-center">
            <div className="mx-auto max-w-md">
              <h3 className="text-xl font-semibold text-white">
                No shows yet
              </h3>
              <p className="mt-2 text-gray-400">
                {canCreateShow 
                  ? "Create your first production show to get started."
                  : "Contact an Admin or AD to create production shows."}
              </p>
              {canCreateShow && (
                <Button
                  onClick={() => setIsCreateModalOpen(true)}
                  className="mt-6 bg-amber-600 hover:bg-amber-700"
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Create Show
                </Button>
              )}
            </div>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {shows.map((show) => (
              <ShowCard
                key={show.id}
                show={show}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}

        {isCreateModalOpen && (
          <CreateShowModal
            isOpen={isCreateModalOpen}
            onClose={() => setIsCreateModalOpen(false)}
            onSuccess={() => {
              setIsCreateModalOpen(false);
              refetch();
            }}
          />
        )}

        {/* Edit Show Dialog */}
        <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
          <DialogContent className="bg-gray-900 border-gray-800">
            <DialogHeader>
              <DialogTitle className="text-white">Edit Show</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update the show details below.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-title" className="text-white">Title</Label>
                <Input
                  id="edit-title"
                  value={editFormData.title}
                  onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Show title"
                />
              </div>

              <div>
                <Label htmlFor="edit-description" className="text-white">Description</Label>
                <Textarea
                  id="edit-description"
                  value={editFormData.description}
                  onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Show description"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="edit-status" className="text-white">Status</Label>
                <Select
                  value={editFormData.status}
                  onValueChange={(value: any) => setEditFormData({ ...editFormData, status: value })}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="Pre-Production">Pre-Production</SelectItem>
                    <SelectItem value="Shooting">Shooting</SelectItem>
                    <SelectItem value="Wrapped">Wrapped</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="ghost"
                onClick={() => setIsEditModalOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                Cancel
              </Button>
              <Button
                onClick={handleEditSubmit}
                disabled={updateShowMutation.isPending || !editFormData.title}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {updateShowMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Show Alert Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent className="bg-gray-900 border-gray-800">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-white">Delete Show</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">
                Are you sure you want to delete "{selectedShow?.title}"? This action cannot be undone and will delete all associated scenes.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-gray-800 text-white hover:bg-gray-700 border-gray-700">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteConfirm}
                disabled={deleteShowMutation.isPending}
                className="bg-red-600 hover:bg-red-700"
              >
                {deleteShowMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
