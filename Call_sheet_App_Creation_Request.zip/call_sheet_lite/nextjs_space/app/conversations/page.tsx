'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, PlusCircle, Search, Loader2, User } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function ConversationsPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const { data: conversations, isLoading, refetch } = trpc.conversations.list.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user,
      refetchInterval: 3000, // Refresh every 3 seconds
    }
  );

  const { data: availableContacts } = trpc.conversations.getAvailableContacts.useQuery(
    undefined,
    {
      enabled: status === 'authenticated' && !!session?.user && isNewChatOpen,
    }
  );

  const createConversationMutation = trpc.conversations.getOrCreate.useMutation({
    onSuccess: (conversation: any) => {
      toast.success('Conversation started');
      setIsNewChatOpen(false);
      refetch();
      router.push(`/conversations/${conversation.id}`);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to start conversation');
    },
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    }
  }, [status, router]);

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  const filteredContacts = availableContacts?.filter((contact) =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const roleColors: Record<string, string> = {
    DEVELOPER: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    ADMIN: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    PRODUCTION_ADMIN: 'bg-green-500/10 text-green-400 border-green-500/30',
    CREW: 'bg-gray-500/10 text-gray-400 border-gray-500/30',
    ACTOR: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  };

  return (
    <div className="container mx-auto px-4 py-4 sm:py-8 max-w-6xl">
      <div className="mb-4 sm:mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center gap-2 sm:gap-3">
            <MessageSquare className="h-6 w-6 sm:h-8 sm:w-8 text-amber-500" />
            Messages
          </h1>
          <p className="mt-1 sm:mt-2 text-sm sm:text-base text-gray-400">Direct conversations with your team</p>
        </div>
        <Button
          onClick={() => setIsNewChatOpen(true)}
          className="bg-amber-600 hover:bg-amber-700 w-full sm:w-auto"
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          New Chat
        </Button>
      </div>

      {!conversations || conversations.length === 0 ? (
        <Card className="bg-gray-900/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="mb-4 h-12 w-12 text-gray-500" />
            <p className="text-gray-400 mb-4">No conversations yet</p>
            <Button
              onClick={() => setIsNewChatOpen(true)}
              variant="outline"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Start a Conversation
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {conversations.map((conversation: any) => {
            const otherUser = conversation.otherParticipants[0]?.user;
            if (!otherUser) return null;

            return (
              <Card
                key={conversation.id}
                className="bg-gray-900/50 hover:bg-gray-800/50 cursor-pointer transition-colors"
                onClick={() => router.push(`/conversations/${conversation.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="flex items-center justify-center w-12 h-12 rounded-full bg-amber-500/10 text-amber-400">
                        <User className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-white">{otherUser.name}</h3>
                          <Badge className={roleColors[otherUser.role]}>
                            {otherUser.role}
                          </Badge>
                        </div>
                        {conversation.lastMessage && (
                          <p className="text-sm text-gray-400 truncate">
                            {conversation.lastMessage.sender.name === session?.user?.name ? 'You: ' : ''}
                            {conversation.lastMessage.content}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      {conversation.lastMessage && (
                        <p className="text-xs text-gray-500">
                          {format(new Date(conversation.lastMessage.createdAt), 'PPp')}
                        </p>
                      )}
                      {conversation.unreadCount > 0 && (
                        <Badge className="bg-amber-500 text-white">
                          {conversation.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* New Chat Dialog */}
      <Dialog open={isNewChatOpen} onOpenChange={setIsNewChatOpen}>
        <DialogContent className="bg-gray-900 text-white max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Start New Conversation</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-gray-800 border-gray-700 pl-10"
              />
            </div>

            {!availableContacts ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-amber-500" />
              </div>
            ) : filteredContacts && filteredContacts.length === 0 ? (
              <p className="text-center text-gray-400 py-8">
                {searchQuery ? 'No contacts found' : 'No contacts available'}
              </p>
            ) : (
              <div className="space-y-2">
                {filteredContacts?.map((contact) => (
                  <div
                    key={contact.id}
                    onClick={() => createConversationMutation.mutate({ otherUserId: contact.id })}
                    className="flex items-center gap-3 p-3 rounded-lg border border-gray-700 bg-gray-800/50 hover:bg-gray-700/50 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-amber-500/10 text-amber-400">
                      <User className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-white">{contact.name}</p>
                      <p className="text-sm text-gray-400">{contact.email}</p>
                    </div>
                    <Badge className={roleColors[contact.role]}>
                      {contact.role}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
