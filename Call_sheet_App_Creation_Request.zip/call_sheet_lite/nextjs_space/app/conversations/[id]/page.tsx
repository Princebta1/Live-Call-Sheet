'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Send, Loader2, User } from 'lucide-react';
import { trpc } from '@/lib/trpc-client';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function ConversationDetailPage() {
  const router = useRouter();
  const params = useParams();
  const { data: session, status } = useSession() || {};
  const conversationId = params?.id as string;

  const [messageContent, setMessageContent] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversation, isLoading, refetch } = trpc.conversations.getById.useQuery(
    { id: conversationId },
    {
      enabled: status === 'authenticated' && !!session?.user && !!conversationId,
      refetchInterval: 2000, // Refresh every 2 seconds
    }
  );

  const sendMessageMutation = trpc.conversations.sendMessage.useMutation({
    onSuccess: () => {
      setMessageContent('');
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to send message');
    },
  });

  const markAsReadMutation = trpc.conversations.markAsRead.useMutation();

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    }
  }, [status, router]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation?.messages]);

  useEffect(() => {
    if (conversationId && status === 'authenticated' && conversation?.messages) {
      markAsReadMutation.mutate({ conversationId });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversationId, conversation?.messages?.length, status]);

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="bg-gray-900/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <p className="text-gray-400">Conversation not found</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => router.push('/conversations')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Conversations
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const otherUser = conversation.participants.find(p => p.userId !== session?.user?.id)?.user;

  const handleSendMessage = () => {
    if (!messageContent.trim()) return;

    sendMessageMutation.mutate({
      conversationId,
      content: messageContent.trim(),
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const roleColors: Record<string, string> = {
    DEVELOPER: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    ADMIN: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    PRODUCTION_ADMIN: 'bg-green-500/10 text-green-400 border-green-500/30',
    CREW: 'bg-gray-500/10 text-gray-400 border-gray-500/30',
    ACTOR: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  };

  return (
    <div className="container mx-auto px-4 py-4 sm:py-8 max-w-4xl">
      {/* Header */}
      <Card className="bg-gray-900/50 mb-4">
        <CardContent className="p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.push('/conversations')}
              className="px-2"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-amber-500/10 text-amber-400 flex-shrink-0">
              <User className="h-5 w-5 sm:h-6 sm:w-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-lg sm:text-xl font-bold text-white truncate">{otherUser?.name}</h2>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <Badge className={roleColors[otherUser?.role || 'CREW']}>
                  {otherUser?.role}
                </Badge>
                <span className="text-xs sm:text-sm text-gray-400 truncate">{otherUser?.email}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Messages */}
      <Card className="bg-gray-900/50 mb-4">
        <CardContent className="p-3 sm:p-4 h-[calc(100vh-280px)] sm:h-[500px] overflow-y-auto">
          {conversation.messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-gray-400">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {conversation.messages.map((message: any) => {
                const isOwnMessage = message.senderId === session?.user?.id;
                return (
                  <div
                    key={message.id}
                    className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${
                        isOwnMessage
                          ? 'bg-amber-600 text-white'
                          : 'bg-gray-800 text-gray-100'
                      }`}
                    >
                      {!isOwnMessage && (
                        <p className="text-xs font-semibold mb-1">
                          {message.sender.name}
                        </p>
                      )}
                      <p className="whitespace-pre-wrap break-words">{message.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          isOwnMessage ? 'text-amber-200' : 'text-gray-500'
                        }`}
                      >
                        {format(new Date(message.createdAt), 'p')}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Message Input */}
      <Card className="bg-gray-900/50">
        <CardContent className="p-3 sm:p-4">
          <div className="flex gap-2">
            <Input
              value={messageContent}
              onChange={(e) => setMessageContent(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="bg-gray-800 border-gray-700 flex-1 text-sm sm:text-base"
              disabled={sendMessageMutation.isPending}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!messageContent.trim() || sendMessageMutation.isPending}
              className="bg-amber-600 hover:bg-amber-700 px-3 sm:px-4"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
