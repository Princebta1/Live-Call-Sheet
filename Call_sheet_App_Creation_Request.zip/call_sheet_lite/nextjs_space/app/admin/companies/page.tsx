"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Edit, Trash2, Building2, Users, Film, Upload, X } from "lucide-react";
import { trpc } from "@/lib/trpc-client";
import { useEffect, useState, useRef } from "react";
import { toast } from "sonner";
import Image from "next/image";

// Helper function to get signed URL from API
async function getSignedUrl(key: string): Promise<string> {
  const response = await fetch("/api/get-signed-url", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ key }),
  });

  if (!response.ok) {
    throw new Error("Failed to get signed URL");
  }

  const data = await response.json();
  return data.signedUrl;
}

type CompanyFormData = {
  name: string;
  description: string;
  adminId: string;
  logoUrl?: string;
};

export default function CompaniesManagementPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<any>(null);
  const [deletingCompany, setDeletingCompany] = useState<any>(null);
  const [detailsCompany, setDetailsCompany] = useState<any>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [editLogoPreview, setEditLogoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<CompanyFormData>({
    name: "",
    description: "",
    adminId: "",
    logoUrl: "",
  });

  const { data: companies, isLoading: companiesLoading, refetch } = trpc.companies.list.useQuery(undefined, {
    enabled: status === "authenticated" && (session?.user?.role === "DEVELOPER" || session?.user?.role === "ADMIN"),
  });

  const { data: users } = trpc.users.list.useQuery(undefined, {
    enabled: status === "authenticated" && session?.user?.role === "DEVELOPER",
  });

  const { data: companyDetails, isLoading: detailsLoading } = trpc.companies.getById.useQuery(
    { id: detailsCompany?.id || "" },
    { enabled: !!detailsCompany?.id }
  );

  const createMutation = trpc.companies.create.useMutation({
    onSuccess: () => {
      toast.success("Company created successfully!");
      setIsCreateOpen(false);
      setFormData({ name: "", description: "", adminId: "", logoUrl: "" });
      setLogoPreview(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create company");
    },
  });

  const updateMutation = trpc.companies.update.useMutation({
    onSuccess: () => {
      toast.success("Company updated successfully!");
      setEditingCompany(null);
      setEditLogoPreview(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update company");
    },
  });

  const deleteMutation = trpc.companies.delete.useMutation({
    onSuccess: () => {
      toast.success("Company deleted successfully!");
      setDeletingCompany(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete company");
    },
  });

  useEffect(() => {
    if (status === "authenticated" && session?.user?.role !== "DEVELOPER" && session?.user?.role !== "ADMIN") {
      router.push("/dashboard");
    }
  }, [status, session, router]);

  const handleLogoUpload = async (file: File, isEdit: boolean = false) => {
    if (!file) return;

    // Validate file type
    if (!["image/jpeg", "image/jpg", "image/png"].includes(file.type)) {
      toast.error("Only JPG and PNG files are allowed");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size too large. Maximum size is 5MB");
      return;
    }

    setUploadingLogo(true);
    try {
      const uploadData = new FormData();
      uploadData.append("file", file);

      const response = await fetch("/api/upload-logo", {
        method: "POST",
        body: uploadData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Upload failed");
      }

      const { cloud_storage_path } = await response.json();
      
      if (isEdit) {
        setEditingCompany({ ...editingCompany, logoUrl: cloud_storage_path });
        const signedUrl = await getSignedUrl(cloud_storage_path);
        setEditLogoPreview(signedUrl);
      } else {
        setFormData((prev) => ({ ...prev, logoUrl: cloud_storage_path }));
        const signedUrl = await getSignedUrl(cloud_storage_path);
        setLogoPreview(signedUrl);
      }

      toast.success("Logo uploaded successfully!");
    } catch (error: any) {
      toast.error(error.message || "Failed to upload logo");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleCreate = () => {
    if (!formData.name || !formData.adminId) {
      toast.error("Please fill in all required fields");
      return;
    }
    createMutation.mutate(formData as any);
  };

  const handleUpdate = () => {
    if (!editingCompany || !editingCompany.name) {
      toast.error("Please fill in all required fields");
      return;
    }
    updateMutation.mutate({
      id: editingCompany.id,
      name: editingCompany.name,
      description: editingCompany.description,
      logoUrl: editingCompany.logoUrl,
    });
  };

  const handleDelete = () => {
    if (deletingCompany) {
      deleteMutation.mutate({ id: deletingCompany.id });
    }
  };

  // Get available admin users (those without a company)
  const availableAdmins = users?.filter(
    (user) => user.role === "ADMIN" && !user.companyId
  ) || [];

  if (status === "loading" || companiesLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Company Management</h1>
            <p className="text-gray-400">Manage production companies and their admins</p>
          </div>
          {session?.user?.role === "DEVELOPER" && (
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="bg-amber-500 hover:bg-amber-600 text-black">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Company
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-amber-500/20 max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-white">Create New Company</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Add a new production company with an assigned admin
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-gray-300">Company Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Production Company Name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description" className="text-gray-300">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Brief description of the company"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="admin" className="text-gray-300">Assign Admin *</Label>
                    <Select
                      value={formData.adminId}
                      onValueChange={(value) => setFormData({ ...formData, adminId: value })}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue placeholder="Select an admin" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        {availableAdmins.length === 0 ? (
                          <div className="p-2 text-gray-400 text-sm">No available admins</div>
                        ) : (
                          availableAdmins.map((user) => (
                            <SelectItem key={user.id} value={user.id}>
                              {user.name} ({user.email})
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    {availableAdmins.length === 0 && (
                      <p className="text-sm text-gray-500 mt-1">
                        Create an admin user first or unassign existing admins
                      </p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="logo" className="text-gray-300">Company Logo (JPG/PNG)</Label>
                    <div className="mt-2">
                      {logoPreview ? (
                        <div className="relative inline-block">
                          <div className="relative w-32 h-32 border-2 border-amber-500/30 rounded-lg overflow-hidden">
                            <Image
                              src={logoPreview}
                              alt="Logo preview"
                              fill
                              className="object-contain"
                            />
                          </div>
                          <button
                            onClick={() => {
                              setLogoPreview(null);
                              setFormData({ ...formData, logoUrl: "" });
                            }}
                            className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full hover:bg-red-600"
                          >
                            <X className="h-3 w-3 text-white" />
                          </button>
                        </div>
                      ) : (
                        <div>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept=".jpg,.jpeg,.png"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleLogoUpload(file);
                            }}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={uploadingLogo}
                            className="border-gray-700 hover:bg-gray-800"
                          >
                            {uploadingLogo ? (
                              <>
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                Uploading...
                              </>
                            ) : (
                              <>
                                <Upload className="h-4 w-4 mr-2" />
                                Upload Logo
                              </>
                            )}
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  <Button
                    onClick={handleCreate}
                    disabled={createMutation.isPending || uploadingLogo}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-black"
                  >
                    {createMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Create Company"
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {companies && companies.length === 0 ? (
          <Card className="bg-gray-900/50 border-amber-500/20 p-12 text-center">
            <Building2 className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No companies found</p>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {companies?.map((company) => (
              <Card 
                key={company.id} 
                className="bg-gray-900/50 border-amber-500/20 p-6"
              >
                <div className="flex items-start gap-4">
                  {company.logoUrl && (
                    <div className="relative w-16 h-16 flex-shrink-0 border border-amber-500/30 rounded-lg overflow-hidden">
                      <LogoImage logoUrl={company.logoUrl} companyName={company.name} />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xl font-semibold text-white mb-1">{company.name}</h3>
                    {company.description && (
                      <p className="text-gray-400 text-sm mb-3 line-clamp-2">{company.description}</p>
                    )}
                    <div className="flex gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {company._count?.admins || 0} Admin{company._count?.admins !== 1 ? "s" : ""}
                      </span>
                      <span className="flex items-center gap-1">
                        <Film className="h-3 w-3" />
                        {company._count?.shows || 0} Show{company._count?.shows !== 1 ? "s" : ""}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => router.push(`/companies/${company.id}`)}
                    className="bg-amber-600 hover:bg-amber-700"
                  >
                    <Building2 className="h-3 w-3 mr-1" />
                    View Profile
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDetailsCompany(company)}
                    className="border-gray-700 hover:bg-gray-800"
                  >
                    View Details
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingCompany(company);
                    }}
                    className="border-gray-700 hover:bg-gray-800"
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    Edit
                  </Button>
                  {session?.user?.role === "DEVELOPER" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeletingCompany(company);
                      }}
                      className="border-red-500/30 hover:bg-red-500/10 text-red-400"
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Delete
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Company Details Dialog */}
        <Dialog open={!!detailsCompany} onOpenChange={() => setDetailsCompany(null)}>
          <DialogContent className="bg-gray-900 border-amber-500/20 max-w-3xl">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-3">
                {detailsCompany?.logoUrl && (
                  <div className="relative w-12 h-12 border border-amber-500/30 rounded-lg overflow-hidden">
                    <LogoImage logoUrl={detailsCompany.logoUrl} companyName={detailsCompany.name} />
                  </div>
                )}
                {detailsCompany?.name}
              </DialogTitle>
              {detailsCompany?.description && (
                <DialogDescription className="text-gray-400">
                  {detailsCompany.description}
                </DialogDescription>
              )}
            </DialogHeader>
            {detailsLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
              </div>
            ) : companyDetails && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-semibold text-gray-400 mb-3">Admins</h4>
                  <div className="space-y-2">
                    {companyDetails.admins?.length === 0 ? (
                      <p className="text-gray-500 text-sm">No admins assigned</p>
                    ) : (
                      companyDetails.admins?.map((admin: any) => (
                        <div key={admin.id} className="p-3 bg-gray-800/50 rounded-lg">
                          <p className="text-white font-medium">{admin.name}</p>
                          <p className="text-gray-400 text-sm">{admin.email}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-gray-400 mb-3">Shows</h4>
                  <div className="space-y-2">
                    {companyDetails.shows?.length === 0 ? (
                      <p className="text-gray-500 text-sm">No shows yet</p>
                    ) : (
                      companyDetails.shows?.map((show: any) => (
                        <div key={show.id} className="p-3 bg-gray-800/50 rounded-lg flex justify-between items-center">
                          <div>
                            <p className="text-white font-medium">{show.title}</p>
                            <p className="text-gray-400 text-sm">{show.status}</p>
                          </div>
                          <p className="text-amber-500 text-sm">
                            {show._count?.scenes || 0} scenes
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={!!editingCompany} onOpenChange={() => {
          setEditingCompany(null);
          setEditLogoPreview(null);
        }}>
          <DialogContent className="bg-gray-900 border-amber-500/20 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">Edit Company</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update company information
              </DialogDescription>
            </DialogHeader>
            {editingCompany && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-name" className="text-gray-300">Company Name</Label>
                  <Input
                    id="edit-name"
                    value={editingCompany.name}
                    onChange={(e) => setEditingCompany({ ...editingCompany, name: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-description" className="text-gray-300">Description</Label>
                  <Textarea
                    id="edit-description"
                    value={editingCompany.description || ""}
                    onChange={(e) => setEditingCompany({ ...editingCompany, description: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-logo" className="text-gray-300">Company Logo (JPG/PNG)</Label>
                  <div className="mt-2">
                    {(editLogoPreview || editingCompany.logoUrl) ? (
                      <div className="relative inline-block">
                        <div className="relative w-32 h-32 border-2 border-amber-500/30 rounded-lg overflow-hidden">
                          {editLogoPreview ? (
                            <Image
                              src={editLogoPreview}
                              alt="Logo preview"
                              fill
                              className="object-contain"
                            />
                          ) : (
                            <LogoImage logoUrl={editingCompany.logoUrl} companyName={editingCompany.name} />
                          )}
                        </div>
                        <button
                          onClick={() => {
                            setEditLogoPreview(null);
                            setEditingCompany({ ...editingCompany, logoUrl: null });
                          }}
                          className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full hover:bg-red-600"
                        >
                          <X className="h-3 w-3 text-white" />
                        </button>
                      </div>
                    ) : (
                      <div>
                        <input
                          ref={editFileInputRef}
                          type="file"
                          accept=".jpg,.jpeg,.png"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleLogoUpload(file, true);
                          }}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => editFileInputRef.current?.click()}
                          disabled={uploadingLogo}
                          className="border-gray-700 hover:bg-gray-800"
                        >
                          {uploadingLogo ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Uploading...
                            </>
                          ) : (
                            <>
                              <Upload className="h-4 w-4 mr-2" />
                              Upload Logo
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
                <Button
                  onClick={handleUpdate}
                  disabled={updateMutation.isPending || uploadingLogo}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-black"
                >
                  {updateMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Company"
                  )}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={!!deletingCompany} onOpenChange={() => setDeletingCompany(null)}>
          <AlertDialogContent className="bg-gray-900 border-red-500/20">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-white">Are you sure?</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">
                This will permanently delete {deletingCompany?.name} and all associated shows and scenes. 
                This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                disabled={deleteMutation.isPending}
                className="bg-red-500 hover:bg-red-600 text-white"
              >
                {deleteMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  "Delete"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

// Helper component to handle logo image loading
function LogoImage({ logoUrl, companyName }: { logoUrl: string; companyName: string }) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadImage() {
      try {
        const url = await getSignedUrl(logoUrl);
        setSignedUrl(url);
      } catch (error) {
        console.error("Failed to load logo:", error);
      } finally {
        setLoading(false);
      }
    }
    if (logoUrl) {
      loadImage();
    }
  }, [logoUrl]);

  if (loading) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-800">
        <Loader2 className="h-4 w-4 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!signedUrl) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-800">
        <Building2 className="h-4 w-4 text-gray-600" />
      </div>
    );
  }

  return <Image src={signedUrl} alt={companyName} fill className="object-contain" />;
}
