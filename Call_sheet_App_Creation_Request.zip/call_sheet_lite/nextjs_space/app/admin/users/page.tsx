
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Edit, Trash2, Users as UsersIcon, Power, Mail, Key } from "lucide-react";
import { trpc } from "@/lib/trpc-client";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const roleColors = {
  DEVELOPER: "bg-red-500/10 text-red-400 border-red-500/30",
  PRODUCTION_ADMIN: "bg-blue-500/10 text-blue-400 border-blue-500/30",
  ADMIN: "bg-purple-500/10 text-purple-400 border-purple-500/30",
  CREW: "bg-gray-500/10 text-gray-400 border-gray-500/30",
  ACTOR: "bg-amber-500/10 text-amber-400 border-amber-500/30",
};

const roleLabels = {
  DEVELOPER: "Developer",
  PRODUCTION_ADMIN: "Production Admin",
  ADMIN: "Admin",
  CREW: "Crew",
  ACTOR: "Actor",
};

type UserFormData = {
  name: string;
  email: string;
  password: string;
  role: string;
  customRoleId?: string;
};

export default function UsersManagementPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [deletingUser, setDeletingUser] = useState<any>(null);
  const [formData, setFormData] = useState<UserFormData>({
    name: "",
    email: "",
    password: "",
    role: "CREW",
  });

  const { data: users, isLoading, refetch } = trpc.users.list.useQuery(undefined, {
    enabled: status === "authenticated" && session?.user?.role === "DEVELOPER",
  });

  const { data: customRoles, isLoading: rolesLoading } = trpc.roles.list.useQuery(undefined, {
    enabled: status === "authenticated",
  });

  const createMutation = trpc.users.create.useMutation({
    onSuccess: () => {
      toast.success("User created successfully!");
      setIsCreateOpen(false);
      setFormData({ name: "", email: "", password: "", role: "CREW" });
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create user");
    },
  });

  const updateMutation = trpc.users.update.useMutation({
    onSuccess: () => {
      toast.success("User updated successfully!");
      setEditingUser(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update user");
    },
  });

  const deleteMutation = trpc.users.delete.useMutation({
    onSuccess: () => {
      toast.success("User deleted successfully!");
      setDeletingUser(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete user");
    },
  });

  const toggleActiveMutation = trpc.users.toggleActive.useMutation({
    onSuccess: (data) => {
      toast.success(`User ${data.isActive ? "activated" : "deactivated"} successfully!`);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update user status");
    },
  });

  const testEmailMutation = trpc.users.sendTestEmail.useMutation({
    onSuccess: (data) => {
      toast.success(data.message || "Test email sent successfully!");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to send test email");
    },
  });

  const [resetPasswordUser, setResetPasswordUser] = useState<{ id: string; name: string; email: string; tempPassword?: string; expiresAt?: Date } | null>(null);

  const resetPasswordMutation = trpc.users.resetPassword.useMutation({
    onSuccess: (data) => {
      setResetPasswordUser((prev) => prev ? { ...prev, tempPassword: data.tempPassword, expiresAt: data.expiresAt } : null);
      toast.success("Temporary password generated successfully!");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to reset password");
      setResetPasswordUser(null);
    },
  });

  useEffect(() => {
    if (status === "authenticated" && session?.user?.role && !['DEVELOPER', 'ADMIN', 'PRODUCTION_ADMIN'].includes(session.user.role)) {
      router.push("/dashboard");
    }
  }, [status, session, router]);

  if (status === "loading" || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
          </div>
        </div>
      </div>
    );
  }

  const handleCreate = () => {
    if (!formData.name || !formData.email || !formData.password) {
      toast.error("Please fill in all required fields");
      return;
    }
    createMutation.mutate(formData as any);
  };

  const handleUpdate = () => {
    if (!editingUser || !editingUser.name || !editingUser.email) {
      toast.error("Please fill in all required fields");
      return;
    }
    updateMutation.mutate({
      id: editingUser.id,
      name: editingUser.name,
      email: editingUser.email,
      role: editingUser.role,
    });
  };

  const handleDelete = () => {
    if (deletingUser) {
      deleteMutation.mutate({ id: deletingUser.id });
    }
  };

  const handleToggleActive = (userId: string, currentStatus: boolean) => {
    toggleActiveMutation.mutate({ id: userId, isActive: !currentStatus });
  };

  const handleTestEmail = (userId: string) => {
    testEmailMutation.mutate({ id: userId });
  };

  const handleResetPassword = (user: { id: string; name: string; email: string }) => {
    setResetPasswordUser(user);
    resetPasswordMutation.mutate({ id: user.id });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">User Management</h1>
            <p className="text-gray-400">Manage system users and their roles</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-amber-500 hover:bg-amber-600 text-black">
                <Plus className="h-4 w-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-amber-500/20">
              <DialogHeader>
                <DialogTitle className="text-white">Create New User</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Add a new user to the system
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-gray-300">Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-gray-300">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="password" className="text-gray-300">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <Label htmlFor="role" className="text-gray-300">System Role</Label>
                  <Select
                    value={formData.role}
                    onValueChange={(value) => setFormData({ ...formData, role: value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="CREW">Crew</SelectItem>
                      <SelectItem value="ACTOR">Actor</SelectItem>
                      <SelectItem value="PRODUCTION_ADMIN">Production Admin</SelectItem>
                      <SelectItem value="ADMIN">Admin</SelectItem>
                      <SelectItem value="DEVELOPER">Developer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="customRole" className="text-gray-300">Custom Role (Optional)</Label>
                  <Select
                    value={formData.customRoleId || "none"}
                    onValueChange={(value) => setFormData({ ...formData, customRoleId: value === "none" ? undefined : value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select custom role (optional)" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="none">No Custom Role</SelectItem>
                      {rolesLoading ? (
                        <SelectItem value="loading" disabled>Loading roles...</SelectItem>
                      ) : customRoles && customRoles.length > 0 ? (
                        customRoles.map((role) => (
                          <SelectItem key={role.id} value={role.id}>
                            {role.name}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-roles" disabled>No custom roles available</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={handleCreate}
                  disabled={createMutation.isPending}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-black"
                >
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create User"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {users && users.length === 0 ? (
          <Card className="bg-gray-900/50 border-amber-500/20 p-12 text-center">
            <UsersIcon className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No users found</p>
          </Card>
        ) : (
          <div className="grid gap-4">
            {users?.map((user) => (
              <Card key={user.id} className="bg-gray-900/50 border-amber-500/20 p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <h3 className="text-lg font-semibold text-white">{user.name}</h3>
                      <Badge className={roleColors[user.role as keyof typeof roleColors]}>
                        {roleLabels[user.role as keyof typeof roleLabels]}
                      </Badge>
                      {user.customRole && (
                        <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/30">
                          {user.customRole.name}
                        </Badge>
                      )}
                      {!user.isActive && (
                        <Badge className="bg-red-500/10 text-red-400 border-red-500/30">
                          Inactive
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-400 mb-1">{user.email}</p>
                    <div className="flex gap-4 text-sm text-gray-500">
                      {user.company && (
                        <span>Company: {user.company.name}</span>
                      )}
                      {user.assignedShow && (
                        <span>Show: {user.assignedShow.title}</span>
                      )}
                      <span>Joined: {new Date(user.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {session?.user?.role === 'DEVELOPER' && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleTestEmail(user.id)}
                          disabled={testEmailMutation.isPending}
                          className="border-amber-500/30 hover:bg-amber-500/10 text-amber-400"
                        >
                          {testEmailMutation.isPending ? (
                            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                          ) : (
                            <Mail className="h-4 w-4 mr-1" />
                          )}
                          Test Email
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleResetPassword({ id: user.id, name: user.name, email: user.email })}
                          disabled={resetPasswordMutation.isPending}
                          className="border-blue-500/30 hover:bg-blue-500/10 text-blue-400"
                        >
                          {resetPasswordMutation.isPending ? (
                            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                          ) : (
                            <Key className="h-4 w-4 mr-1" />
                          )}
                          Reset Password
                        </Button>
                      </>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleActive(user.id, user.isActive)}
                      disabled={toggleActiveMutation.isPending}
                      className="border-gray-700 hover:bg-gray-800"
                    >
                      <Power className="h-4 w-4 mr-1" />
                      {user.isActive ? "Deactivate" : "Activate"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingUser(user)}
                      className="border-gray-700 hover:bg-gray-800"
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDeletingUser(user)}
                      className="border-red-500/30 hover:bg-red-500/10 text-red-400"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
          <DialogContent className="bg-gray-900 border-amber-500/20">
            <DialogHeader>
              <DialogTitle className="text-white">Edit User</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update user information and role
              </DialogDescription>
            </DialogHeader>
            {editingUser && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-name" className="text-gray-300">Name</Label>
                  <Input
                    id="edit-name"
                    value={editingUser.name}
                    onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-email" className="text-gray-300">Email</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editingUser.email}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-role" className="text-gray-300">System Role</Label>
                  <Select
                    value={editingUser.role}
                    onValueChange={(value) => setEditingUser({ ...editingUser, role: value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="CREW">Crew</SelectItem>
                      <SelectItem value="ACTOR">Actor</SelectItem>
                      <SelectItem value="PRODUCTION_ADMIN">Production Admin</SelectItem>
                      <SelectItem value="ADMIN">Admin</SelectItem>
                      <SelectItem value="DEVELOPER">Developer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-customRole" className="text-gray-300">Custom Role (Optional)</Label>
                  <Select
                    value={editingUser.customRoleId || "none"}
                    onValueChange={(value) => setEditingUser({ ...editingUser, customRoleId: value === "none" ? null : value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select custom role (optional)" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="none">No Custom Role</SelectItem>
                      {rolesLoading ? (
                        <SelectItem value="loading" disabled>Loading roles...</SelectItem>
                      ) : customRoles && customRoles.length > 0 ? (
                        customRoles.map((role) => (
                          <SelectItem key={role.id} value={role.id}>
                            {role.name}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-roles" disabled>No custom roles available</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={handleUpdate}
                  disabled={updateMutation.isPending}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-black"
                >
                  {updateMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update User"
                  )}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={!!deletingUser} onOpenChange={() => setDeletingUser(null)}>
          <AlertDialogContent className="bg-gray-900 border-red-500/20">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-white">Are you sure?</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">
                This will permanently delete {deletingUser?.name} and all associated data. 
                This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                disabled={deleteMutation.isPending}
                className="bg-red-500 hover:bg-red-600 text-white"
              >
                {deleteMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  "Delete"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Reset Password Dialog */}
        <Dialog open={!!resetPasswordUser} onOpenChange={() => setResetPasswordUser(null)}>
          <DialogContent className="bg-gray-900 border-blue-500/20">
            <DialogHeader>
              <DialogTitle className="text-white">Temporary Password Generated</DialogTitle>
              <DialogDescription className="text-gray-400">
                A temporary password has been generated for {resetPasswordUser?.name}. 
                Share this password securely with the user.
              </DialogDescription>
            </DialogHeader>
            {resetPasswordUser?.tempPassword && (
              <div className="space-y-4">
                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-md">
                  <Label className="text-gray-300 text-sm">Temporary Password</Label>
                  <div className="flex items-center justify-between mt-2">
                    <code className="text-2xl font-mono font-bold text-blue-400">
                      {resetPasswordUser.tempPassword}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(resetPasswordUser.tempPassword || "");
                        toast.success("Password copied to clipboard!");
                      }}
                      className="text-blue-400 hover:text-blue-300"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <p className="text-gray-400">
                    <strong className="text-white">User:</strong> {resetPasswordUser.email}
                  </p>
                  <p className="text-gray-400">
                    <strong className="text-white">Expires:</strong>{" "}
                    {resetPasswordUser.expiresAt
                      ? new Date(resetPasswordUser.expiresAt).toLocaleString()
                      : "7 days from now"}
                  </p>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-md mt-4">
                    <p className="text-amber-400 text-sm">
                      <strong>Important:</strong> The user will be required to change this password upon their first login.
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => setResetPasswordUser(null)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                >
                  Close
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
