
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { trpc } from "@/lib/trpc-client";
import { Loader2, Check, X, Building2, User } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function ApprovalsPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [rejectingShow, setRejectingShow] = useState<any>(null);

  const { data: pendingShows, isLoading, refetch } = trpc.shows.pendingApproval.useQuery(undefined, {
    enabled: status === "authenticated" && session?.user?.role === "DEVELOPER",
  });

  const approveMutation = trpc.shows.approve.useMutation({
    onSuccess: () => {
      toast.success("Show approved successfully!");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to approve show");
    },
  });

  const rejectMutation = trpc.shows.reject.useMutation({
    onSuccess: () => {
      toast.success("Show rejected and deleted successfully!");
      setRejectingShow(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to reject show");
    },
  });

  useEffect(() => {
    if (status === "authenticated" && session?.user?.role !== "DEVELOPER") {
      router.push("/dashboard");
    }
  }, [status, session, router]);

  if (status === "loading" || isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gradient-to-br from-black via-gray-900 to-black">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (session?.user?.role !== "DEVELOPER") {
    return null;
  }

  const handleApprove = (showId: string) => {
    approveMutation.mutate({ id: showId });
  };

  const handleReject = () => {
    if (rejectingShow) {
      rejectMutation.mutate({ id: rejectingShow.id });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold text-white">Show Approvals</h1>
          <p className="text-gray-400">Review and approve or reject new shows created by admins</p>
        </div>

        {(!pendingShows || pendingShows.length === 0) ? (
          <Card className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-12 text-center">
            <Check className="mx-auto h-12 w-12 text-green-500 mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">All caught up!</h3>
            <p className="text-gray-400">No shows pending approval</p>
          </Card>
        ) : (
          <div className="grid gap-6">
            {pendingShows.map((show) => (
              <Card key={show.id} className="border-gray-800 bg-gradient-to-br from-gray-900 to-gray-950 p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-semibold text-white">{show.title}</h3>
                      <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/30">
                        Pending Approval
                      </Badge>
                      <Badge className={`${
                        show.status === "Pre-Production" ? "bg-blue-500/10 text-blue-400 border-blue-500/30" :
                        show.status === "Shooting" ? "bg-amber-500/10 text-amber-400 border-amber-500/30" :
                        "bg-green-500/10 text-green-400 border-green-500/30"
                      }`}>
                        {show.status}
                      </Badge>
                    </div>
                    
                    {show.description && (
                      <p className="text-gray-400 mb-4">{show.description}</p>
                    )}

                    <div className="flex items-center gap-6 text-sm text-gray-500">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span>Created by: <span className="text-gray-300">{show.creator.name}</span></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4" />
                        <span>Company: <span className="text-gray-300">{show.company.name}</span></span>
                      </div>
                      <div>
                        Scenes: <span className="text-gray-300">{show._count.scenes}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      onClick={() => handleApprove(show.id)}
                      disabled={approveMutation.isPending}
                      className="bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/30"
                    >
                      {approveMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Check className="h-4 w-4 mr-2" />
                      )}
                      Approve
                    </Button>
                    <Button
                      onClick={() => setRejectingShow(show)}
                      disabled={rejectMutation.isPending}
                      className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Reject Confirmation Dialog */}
        <AlertDialog open={!!rejectingShow} onOpenChange={() => setRejectingShow(null)}>
          <AlertDialogContent className="bg-gray-900 border-red-500/20">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-white">Reject and Delete Show?</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">
                Are you sure you want to reject "{rejectingShow?.title}"? This will permanently delete 
                the show and all its scenes. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleReject}
                disabled={rejectMutation.isPending}
                className="bg-red-500 hover:bg-red-600 text-white"
              >
                {rejectMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Rejecting...
                  </>
                ) : (
                  "Reject & Delete"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
