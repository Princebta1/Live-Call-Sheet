
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { trpc } from "@/lib/trpc-client";
import { Loader2, Check, X, UserPlus, Mail, Calendar, Building2, PlusCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function UserApprovalsPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [rejectingUser, setRejectingUser] = useState<any>(null);
  const [approvingUser, setApprovingUser] = useState<any>(null);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>("");
  const [showCreateCompany, setShowCreateCompany] = useState(false);
  const [newCompanyName, setNewCompanyName] = useState("");
  const [newCompanyDescription, setNewCompanyDescription] = useState("");

  const { data: pendingUsers, isLoading, refetch } = trpc.users.pendingApproval.useQuery(undefined, {
    enabled: status === "authenticated" && session?.user?.role === "DEVELOPER",
  });

  const { data: companies, isLoading: companiesLoading } = trpc.companies.list.useQuery(undefined, {
    enabled: status === "authenticated" && session?.user?.role === "DEVELOPER",
  });

  const approveMutation = trpc.users.approveUser.useMutation({
    onSuccess: () => {
      toast.success("User approved successfully! Notification email sent.");
      setApprovingUser(null);
      setSelectedCompanyId("");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to approve user");
    },
  });

  const createCompanyMutation = trpc.companies.createForApproval.useMutation({
    onSuccess: (company) => {
      toast.success("Company created successfully!");
      setSelectedCompanyId(company.id);
      setShowCreateCompany(false);
      setNewCompanyName("");
      setNewCompanyDescription("");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create company");
    },
  });

  const rejectMutation = trpc.users.rejectUser.useMutation({
    onSuccess: () => {
      toast.success("User registration rejected and deleted successfully!");
      setRejectingUser(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to reject user");
    },
  });

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/login");
    } else if (status === "authenticated" && session?.user?.role !== "DEVELOPER") {
      router.push("/dashboard");
    }
  }, [status, session, router]);

  const openApprovalDialog = (user: any) => {
    setApprovingUser(user);
    setSelectedCompanyId("");
    setShowCreateCompany(false);
  };

  const handleApprove = () => {
    if (!approvingUser) return;
    
    // Check if company is required for ADMIN or PRODUCTION_ADMIN
    if ((approvingUser.role === "ADMIN" || approvingUser.role === "PRODUCTION_ADMIN") && !selectedCompanyId) {
      toast.error("Please select or create a company for this user");
      return;
    }

    approveMutation.mutate({ 
      id: approvingUser.id,
      companyId: selectedCompanyId || undefined,
    });
  };

  const handleCreateCompany = () => {
    if (!newCompanyName.trim()) {
      toast.error("Please enter a company name");
      return;
    }

    createCompanyMutation.mutate({
      name: newCompanyName,
      description: newCompanyDescription,
    });
  };

  const handleReject = () => {
    if (!rejectingUser) return;
    rejectMutation.mutate({ id: rejectingUser.id });
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "DEVELOPER":
        return "bg-purple-500/10 text-purple-400 border-purple-500/50";
      case "PRODUCTION_ADMIN":
        return "bg-blue-500/10 text-blue-400 border-blue-500/50";
      case "ADMIN":
        return "bg-green-500/10 text-green-400 border-green-500/50";
      case "CREW":
        return "bg-yellow-500/10 text-yellow-400 border-yellow-500/50";
      case "ACTOR":
        return "bg-amber-500/10 text-amber-400 border-amber-500/50";
      default:
        return "bg-gray-500/10 text-gray-400 border-gray-500/50";
    }
  };

  if (status === "loading" || isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">User Approvals</h1>
          <p className="mt-2 text-gray-400">
            Review and approve new user registrations
          </p>
        </div>
        <Badge variant="outline" className="border-amber-500 text-amber-400">
          {pendingUsers?.length || 0} Pending
        </Badge>
      </div>

      {pendingUsers && pendingUsers.length === 0 ? (
        <Card className="bg-gray-900/50 border-gray-800">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <UserPlus className="h-12 w-12 text-gray-600 mb-4" />
            <p className="text-gray-400 text-center">
              No pending user registrations at the moment.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {pendingUsers?.map((user: any) => (
            <Card key={user.id} className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      {user.name}
                      <Badge className={getRoleBadgeColor(user.role)}>
                        {user.role.replace("_", " ")}
                      </Badge>
                    </CardTitle>
                    <div className="mt-3 space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400">
                        <Mail className="h-4 w-4" />
                        <span>{user.email}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400">
                        <Calendar className="h-4 w-4" />
                        <span>
                          Registered: {format(new Date(user.createdAt), "PPP 'at' p")}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => openApprovalDialog(user)}
                      disabled={approveMutation.isPending}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => setRejectingUser(user)}
                      disabled={rejectMutation.isPending}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Reject
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>
      )}

      {/* Approval Dialog with Company Assignment */}
      <Dialog open={!!approvingUser} onOpenChange={() => setApprovingUser(null)}>
        <DialogContent className="bg-gray-900 text-white border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle>Approve User Registration</DialogTitle>
            <DialogDescription className="text-gray-400">
              Review and approve {approvingUser?.name}&apos;s registration
              {(approvingUser?.role === "ADMIN" || approvingUser?.role === "PRODUCTION_ADMIN") && 
                " and assign them to a company"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* User Info */}
            <div className="bg-gray-800/50 rounded-lg p-4 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-gray-400">Name:</span>
                <span className="text-white font-medium">{approvingUser?.name}</span>
                <Badge className={getRoleBadgeColor(approvingUser?.role || "")}>
                  {approvingUser?.role?.replace("_", " ")}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">Email:</span>
                <span className="text-white">{approvingUser?.email}</span>
              </div>
            </div>

            {/* Company Assignment (for ADMIN and PRODUCTION_ADMIN only) */}
            {(approvingUser?.role === "ADMIN" || approvingUser?.role === "PRODUCTION_ADMIN") && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-gray-200">
                    Company Assignment <span className="text-red-400">*</span>
                  </Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCreateCompany(!showCreateCompany)}
                    className="border-amber-500 text-amber-400 hover:bg-amber-500/10"
                  >
                    <PlusCircle className="h-4 w-4 mr-1" />
                    {showCreateCompany ? "Cancel" : "Create New Company"}
                  </Button>
                </div>

                {showCreateCompany ? (
                  <div className="space-y-3 bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                    <div>
                      <Label className="text-gray-200">Company Name *</Label>
                      <Input
                        value={newCompanyName}
                        onChange={(e) => setNewCompanyName(e.target.value)}
                        placeholder="Enter company name"
                        className="bg-gray-800 border-gray-700 text-white mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-200">Description (Optional)</Label>
                      <Textarea
                        value={newCompanyDescription}
                        onChange={(e) => setNewCompanyDescription(e.target.value)}
                        placeholder="Enter company description"
                        className="bg-gray-800 border-gray-700 text-white mt-1"
                        rows={3}
                      />
                    </div>
                    <Button
                      onClick={handleCreateCompany}
                      disabled={createCompanyMutation.isPending}
                      className="w-full bg-amber-600 hover:bg-amber-700"
                    >
                      {createCompanyMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Building2 className="h-4 w-4 mr-2" />
                      )}
                      Create Company
                    </Button>
                  </div>
                ) : (
                  <Select value={selectedCompanyId} onValueChange={setSelectedCompanyId}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select a company..." />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {companiesLoading ? (
                        <div className="flex items-center justify-center p-4">
                          <Loader2 className="h-4 w-4 animate-spin text-amber-500" />
                        </div>
                      ) : companies && companies.length > 0 ? (
                        companies.map((company: any) => (
                          <SelectItem key={company.id} value={company.id}>
                            {company.name}
                          </SelectItem>
                        ))
                      ) : (
                        <div className="p-4 text-center text-gray-400">
                          No companies available. Create a new one above.
                        </div>
                      )}
                    </SelectContent>
                  </Select>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setApprovingUser(null)}
                className="flex-1 border-gray-700 hover:bg-gray-800"
              >
                Cancel
              </Button>
              <Button
                onClick={handleApprove}
                disabled={approveMutation.isPending}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {approveMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Check className="h-4 w-4 mr-2" />
                )}
                Approve & Notify User
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Reject Confirmation Dialog */}
      <AlertDialog open={!!rejectingUser} onOpenChange={() => setRejectingUser(null)}>
        <AlertDialogContent className="bg-gray-900 text-white border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle>Reject User Registration</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to reject this user registration? This will permanently 
              delete their account and they will need to register again.
              <br />
              <br />
              <strong className="text-white">User: {rejectingUser?.name} ({rejectingUser?.email})</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-gray-800 hover:bg-gray-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleReject}
              className="bg-red-600 hover:bg-red-700"
            >
              Reject & Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
