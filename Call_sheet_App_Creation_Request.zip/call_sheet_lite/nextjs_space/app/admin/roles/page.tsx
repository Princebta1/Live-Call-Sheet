
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Plus, Edit, Trash2, Shield, Power, Users as UsersIcon } from "lucide-react";
import { trpc } from "@/lib/trpc-client";
import { useEffect, useState } from "react";
import { toast } from "sonner";

type RoleFormData = {
  name: string;
  description: string;
  permissionIds: string[];
};

export default function RolesManagementPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<any>(null);
  const [deletingRole, setDeletingRole] = useState<any>(null);
  const [viewingRole, setViewingRole] = useState<any>(null);
  const [formData, setFormData] = useState<RoleFormData>({
    name: "",
    description: "",
    permissionIds: [],
  });
  const [searchQuery, setSearchQuery] = useState("");

  const { data: roles, isLoading, refetch } = trpc.roles.list.useQuery(undefined, {
    enabled: status === "authenticated",
  });

  const { data: permissions, isLoading: permissionsLoading } = trpc.permissions.list.useQuery(undefined, {
    enabled: status === "authenticated",
  });

  const createMutation = trpc.roles.create.useMutation({
    onSuccess: () => {
      toast.success("Role created successfully!");
      setIsCreateOpen(false);
      setFormData({ name: "", description: "", permissionIds: [] });
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create role");
    },
  });

  const updateMutation = trpc.roles.update.useMutation({
    onSuccess: () => {
      toast.success("Role updated successfully!");
      setEditingRole(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update role");
    },
  });

  const deleteMutation = trpc.roles.delete.useMutation({
    onSuccess: () => {
      toast.success("Role deleted successfully!");
      setDeletingRole(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete role");
    },
  });

  const toggleActiveMutation = trpc.roles.toggleActive.useMutation({
    onSuccess: (data) => {
      toast.success(`Role ${data.isActive ? "activated" : "deactivated"} successfully!`);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update role status");
    },
  });

  const { data: viewingRoleDetails } = trpc.roles.getById.useQuery(
    { id: viewingRole?.id || "" },
    { enabled: !!viewingRole }
  );

  useEffect(() => {
    if (status === "authenticated" && session?.user?.role && !['DEVELOPER', 'ADMIN', 'PRODUCTION_ADMIN'].includes(session.user.role)) {
      router.push("/dashboard");
    }
  }, [status, session, router]);

  if (status === "loading" || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
          </div>
        </div>
      </div>
    );
  }

  const handleCreate = () => {
    if (!formData.name) {
      toast.error("Please enter a role name");
      return;
    }
    if (formData.permissionIds.length === 0) {
      toast.error("Please select at least one permission");
      return;
    }
    createMutation.mutate(formData as any);
  };

  const handleUpdate = () => {
    if (!editingRole || !editingRole.name) {
      toast.error("Please enter a role name");
      return;
    }
    if (editingRole.permissionIds && editingRole.permissionIds.length === 0) {
      toast.error("Please select at least one permission");
      return;
    }
    updateMutation.mutate({
      id: editingRole.id,
      name: editingRole.name,
      description: editingRole.description,
      permissionIds: editingRole.permissionIds,
    });
  };

  const handleDelete = () => {
    if (deletingRole) {
      deleteMutation.mutate({ id: deletingRole.id });
    }
  };

  const handleToggleActive = (roleId: string, currentStatus: boolean) => {
    toggleActiveMutation.mutate({ id: roleId, isActive: !currentStatus });
  };

  const openEditDialog = (role: any) => {
    setEditingRole({
      ...role,
      permissionIds: role.rolePermissions.map((rp: any) => rp.permission.id),
    });
  };

  const togglePermission = (permissionId: string, isEditing: boolean = false) => {
    if (isEditing) {
      const currentIds = editingRole.permissionIds || [];
      const newIds = currentIds.includes(permissionId)
        ? currentIds.filter((id: string) => id !== permissionId)
        : [...currentIds, permissionId];
      setEditingRole({ ...editingRole, permissionIds: newIds });
    } else {
      const currentIds = formData.permissionIds;
      const newIds = currentIds.includes(permissionId)
        ? currentIds.filter(id => id !== permissionId)
        : [...currentIds, permissionId];
      setFormData({ ...formData, permissionIds: newIds });
    }
  };

  // Group permissions by category
  const permissionsByCategory = permissions?.reduce((acc: any, perm: any) => {
    if (!acc[perm.category]) {
      acc[perm.category] = [];
    }
    acc[perm.category].push(perm);
    return acc;
  }, {}) || {};

  const filteredRoles = roles?.filter(role =>
    role.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    role.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isDeveloper = session?.user?.role === 'DEVELOPER';

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Roles Management</h1>
            <p className="text-gray-400">Create and manage custom roles with specific permissions</p>
          </div>
          <Button
            onClick={() => setIsCreateOpen(true)}
            className="bg-amber-500 hover:bg-amber-600 text-black"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Role
          </Button>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <Input
            type="text"
            placeholder="Search roles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white max-w-md"
          />
        </div>

        {/* Roles Grid */}
        {filteredRoles && filteredRoles.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredRoles.map((role) => (
              <Card key={role.id} className="bg-gray-800 border-gray-700 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-amber-500" />
                    <h3 className="text-lg font-semibold text-white">{role.name}</h3>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      role.isActive
                        ? "border-green-500/30 text-green-400 bg-green-500/10"
                        : "border-gray-500/30 text-gray-400 bg-gray-500/10"
                    }
                  >
                    {role.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>

                {role.description && (
                  <p className="text-gray-400 text-sm mb-4">{role.description}</p>
                )}

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Permissions:</span>
                    <Badge variant="outline" className="border-amber-500/30 text-amber-400 bg-amber-500/10">
                      {role.rolePermissions.length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Assigned Users:</span>
                    <Badge variant="outline" className="border-blue-500/30 text-blue-400 bg-blue-500/10">
                      {role._count.users}
                    </Badge>
                  </div>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setViewingRole(role)}
                    className="border-gray-700 hover:bg-gray-700"
                  >
                    <UsersIcon className="h-4 w-4 mr-1" />
                    View Users
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(role)}
                    className="border-gray-700 hover:bg-gray-700"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  {isDeveloper && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleActive(role.id, role.isActive)}
                        disabled={toggleActiveMutation.isPending}
                        className="border-gray-700 hover:bg-gray-800"
                      >
                        <Power className="h-4 w-4 mr-1" />
                        {role.isActive ? "Deactivate" : "Activate"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeletingRole(role)}
                        className="border-red-500/30 hover:bg-red-500/10 text-red-400"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="bg-gray-800 border-gray-700 p-12 text-center">
            <Shield className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">
              {searchQuery ? "No roles match your search" : "No custom roles created yet"}
            </p>
            {!searchQuery && (
              <Button
                onClick={() => setIsCreateOpen(true)}
                className="bg-amber-500 hover:bg-amber-600 text-black"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Role
              </Button>
            )}
          </Card>
        )}

        {/* Create Dialog */}
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Create New Role</DialogTitle>
              <DialogDescription className="text-gray-400">
                Define a custom role with specific permissions
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="name" className="text-gray-300">
                  Role Name *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="e.g., Location Manager"
                />
              </div>
              <div>
                <Label htmlFor="description" className="text-gray-300">
                  Description
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Brief description of this role"
                  rows={3}
                />
              </div>

              <div>
                <Label className="text-gray-300 mb-3 block">
                  Permissions * ({formData.permissionIds.length} selected)
                </Label>
                {permissionsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-amber-500" />
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                    {Object.entries(permissionsByCategory).map(([category, perms]: [string, any]) => (
                      <div key={category} className="border border-gray-700 rounded-lg p-4">
                        <h4 className="font-semibold text-amber-400 mb-3">{category}</h4>
                        <div className="space-y-2">
                          {perms.map((permission: any) => (
                            <div key={permission.id} className="flex items-start space-x-2">
                              <Checkbox
                                id={`perm-${permission.id}`}
                                checked={formData.permissionIds.includes(permission.id)}
                                onCheckedChange={() => togglePermission(permission.id)}
                                className="mt-1"
                              />
                              <div className="flex-1">
                                <label
                                  htmlFor={`perm-${permission.id}`}
                                  className="text-sm font-medium text-white cursor-pointer"
                                >
                                  {permission.name}
                                </label>
                                {permission.description && (
                                  <p className="text-xs text-gray-400">{permission.description}</p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setIsCreateOpen(false)}
                className="border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreate}
                disabled={createMutation.isPending}
                className="bg-amber-500 hover:bg-amber-600 text-black"
              >
                {createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Create Role
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={!!editingRole} onOpenChange={() => setEditingRole(null)}>
          <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Edit Role</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update role details and permissions
              </DialogDescription>
            </DialogHeader>
            {editingRole && (
              <div className="space-y-4 py-4">
                <div>
                  <Label htmlFor="edit-name" className="text-gray-300">
                    Role Name *
                  </Label>
                  <Input
                    id="edit-name"
                    value={editingRole.name}
                    onChange={(e) => setEditingRole({ ...editingRole, name: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-description" className="text-gray-300">
                    Description
                  </Label>
                  <Textarea
                    id="edit-description"
                    value={editingRole.description || ""}
                    onChange={(e) => setEditingRole({ ...editingRole, description: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                    rows={3}
                  />
                </div>

                <div>
                  <Label className="text-gray-300 mb-3 block">
                    Permissions * ({editingRole.permissionIds?.length || 0} selected)
                  </Label>
                  {permissionsLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-6 w-6 animate-spin text-amber-500" />
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                      {Object.entries(permissionsByCategory).map(([category, perms]: [string, any]) => (
                        <div key={category} className="border border-gray-700 rounded-lg p-4">
                          <h4 className="font-semibold text-amber-400 mb-3">{category}</h4>
                          <div className="space-y-2">
                            {perms.map((permission: any) => (
                              <div key={permission.id} className="flex items-start space-x-2">
                                <Checkbox
                                  id={`edit-perm-${permission.id}`}
                                  checked={editingRole.permissionIds?.includes(permission.id)}
                                  onCheckedChange={() => togglePermission(permission.id, true)}
                                  className="mt-1"
                                />
                                <div className="flex-1">
                                  <label
                                    htmlFor={`edit-perm-${permission.id}`}
                                    className="text-sm font-medium text-white cursor-pointer"
                                  >
                                    {permission.name}
                                  </label>
                                  {permission.description && (
                                    <p className="text-xs text-gray-400">{permission.description}</p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setEditingRole(null)}
                className="border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdate}
                disabled={updateMutation.isPending}
                className="bg-amber-500 hover:bg-amber-600 text-black"
              >
                {updateMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Update Role
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* View Users Dialog */}
        <Dialog open={!!viewingRole} onOpenChange={() => setViewingRole(null)}>
          <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">
                Users with "{viewingRole?.name}" Role
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                List of users assigned to this role
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              {viewingRoleDetails ? (
                viewingRoleDetails.users.length > 0 ? (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {viewingRoleDetails.users.map((user: any) => (
                      <Card key={user.id} className="bg-gray-700 border-gray-600 p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-white">{user.name}</p>
                            <p className="text-sm text-gray-400">{user.email}</p>
                          </div>
                          <Badge
                            variant="outline"
                            className="border-amber-500/30 text-amber-400 bg-amber-500/10"
                          >
                            {user.role}
                          </Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <UsersIcon className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No users assigned to this role yet</p>
                  </div>
                )
              ) : (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-amber-500" />
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={!!deletingRole} onOpenChange={() => setDeletingRole(null)}>
          <AlertDialogContent className="bg-gray-800 border-gray-700">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-white">Delete Role</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">
                Are you sure you want to delete the role "{deletingRole?.name}"?
                {deletingRole?._count?.users > 0 && (
                  <span className="block mt-2 text-red-400">
                    Warning: This role has {deletingRole._count.users} assigned user(s). Please
                    reassign users before deleting.
                  </span>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="border-gray-600 hover:bg-gray-700">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                disabled={deleteMutation.isPending || (deletingRole?._count?.users > 0)}
                className="bg-red-500 hover:bg-red-600"
              >
                {deleteMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
