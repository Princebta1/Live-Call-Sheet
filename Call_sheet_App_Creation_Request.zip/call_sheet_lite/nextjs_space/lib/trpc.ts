
import { initTRPC, TRPCError } from '@trpc/server';
import { getServerSession } from 'next-auth';
import { authOptions } from './auth';
import { prisma } from './db';
import superjson from 'superjson';
import { Role } from '@prisma/client';
import { hasPermission, hasAnyPermission } from './permissions';

export async function createContext() {
  const session = await getServerSession(authOptions);
  
  return {
    session,
    prisma,
  };
}

export type Context = Awaited<ReturnType<typeof createContext>>;

const t = initTRPC.context<Context>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

// Middleware to check if user is authenticated
const isAuthed = t.middleware(({ ctx, next }) => {
  if (!ctx.session || !ctx.session.user?.id) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }
  return next({
    ctx: {
      ...ctx,
      session: { ...ctx.session, user: ctx.session.user },
    },
  });
});

// Middleware to check if user is Developer (full access)
const isDeveloper = t.middleware(async ({ ctx, next }) => {
  if (!ctx.session || !ctx.session.user?.id) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  const user = await ctx.prisma.user.findUnique({
    where: { id: ctx.session.user.id },
    select: { role: true },
  });

  if (user?.role !== Role.DEVELOPER) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Developer access required' });
  }

  return next({
    ctx: {
      ...ctx,
      session: { ...ctx.session, user: ctx.session.user },
    },
  });
});

// Middleware to check if user is Admin
const isAdmin = t.middleware(async ({ ctx, next }) => {
  if (!ctx.session || !ctx.session.user?.id) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  const user = await ctx.prisma.user.findUnique({
    where: { id: ctx.session.user.id },
    select: { role: true },
  });

  if (user?.role !== Role.ADMIN && user?.role !== Role.DEVELOPER) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }

  return next({
    ctx: {
      ...ctx,
      session: { ...ctx.session, user: ctx.session.user },
    },
  });
});

// Middleware to check if user is Admin or Production Admin
const isAdminOrProductionAdmin = t.middleware(async ({ ctx, next }) => {
  if (!ctx.session || !ctx.session.user?.id) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  const user = await ctx.prisma.user.findUnique({
    where: { id: ctx.session.user.id },
    select: { role: true },
  });

  if (user?.role !== Role.ADMIN && user?.role !== Role.PRODUCTION_ADMIN && user?.role !== Role.DEVELOPER) {
    throw new TRPCError({ 
      code: 'FORBIDDEN', 
      message: 'Admin or Production Admin access required' 
    });
  }

  return next({
    ctx: {
      ...ctx,
      session: { ...ctx.session, user: ctx.session.user },
    },
  });
});

/**
 * Middleware factory to check if user has a specific permission
 */
export function requirePermission(permissionKey: string) {
  return t.middleware(async ({ ctx, next }) => {
    if (!ctx.session || !ctx.session.user?.id) {
      throw new TRPCError({ code: 'UNAUTHORIZED' });
    }

    const hasAccess = await hasPermission(ctx.session.user.id, permissionKey);

    if (!hasAccess) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: `Permission denied: ${permissionKey} is required`,
      });
    }

    return next({
      ctx: {
        ...ctx,
        session: { ...ctx.session, user: ctx.session.user },
      },
    });
  });
}

/**
 * Middleware factory to check if user has any of the provided permissions
 */
export function requireAnyPermission(permissionKeys: string[]) {
  return t.middleware(async ({ ctx, next }) => {
    if (!ctx.session || !ctx.session.user?.id) {
      throw new TRPCError({ code: 'UNAUTHORIZED' });
    }

    const hasAccess = await hasAnyPermission(ctx.session.user.id, permissionKeys);

    if (!hasAccess) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: `Permission denied: One of [${permissionKeys.join(', ')}] is required`,
      });
    }

    return next({
      ctx: {
        ...ctx,
        session: { ...ctx.session, user: ctx.session.user },
      },
    });
  });
}

/**
 * Helper to create a procedure that requires a specific permission
 */
export function permissionProcedure(permissionKey: string) {
  return publicProcedure.use(requirePermission(permissionKey));
}

/**
 * Helper to create a procedure that requires any of the provided permissions
 */
export function anyPermissionProcedure(permissionKeys: string[]) {
  return publicProcedure.use(requireAnyPermission(permissionKeys));
}

export const protectedProcedure = publicProcedure.use(isAuthed);
export const developerProcedure = publicProcedure.use(isDeveloper);
export const adminProcedure = publicProcedure.use(isAdmin);
export const adminOrProductionAdminProcedure = publicProcedure.use(isAdminOrProductionAdmin);
