
import { prisma } from "./db";
import { Role } from "@prisma/client";
import { TRPCError } from "@trpc/server";

/**
 * Permission Checker Utility
 * Provides functions to check user permissions based on system roles and custom roles
 */

interface UserPermissions {
  systemRole: Role;
  customRoleId?: string | null;
  permissions: string[];
}

/**
 * Fetch all effective permissions for a user
 */
export async function getUserPermissions(userId: string): Promise<UserPermissions> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      customRole: {
        include: {
          rolePermissions: {
            include: {
              permission: true,
            },
          },
        },
      },
    },
  });

  if (!user) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "User not found",
    });
  }

  // DEVELOPER role gets all permissions (wildcard)
  if (user.role === "DEVELOPER") {
    return {
      systemRole: user.role,
      customRoleId: user.customRoleId,
      permissions: ["*"], // Wildcard = all permissions
    };
  }

  // Collect permissions from custom role
  const customPermissions =
    user.customRole?.rolePermissions.map((rp) => rp.permission.key) || [];

  return {
    systemRole: user.role,
    customRoleId: user.customRoleId,
    permissions: customPermissions,
  };
}

/**
 * Check if user has a specific permission
 */
export async function hasPermission(
  userId: string,
  permissionKey: string
): Promise<boolean> {
  const userPerms = await getUserPermissions(userId);

  // Check for wildcard permission (DEVELOPER)
  if (userPerms.permissions.includes("*")) {
    return true;
  }

  // Check for exact permission match
  return userPerms.permissions.includes(permissionKey);
}

/**
 * Check if user has any of the provided permissions (OR logic)
 */
export async function hasAnyPermission(
  userId: string,
  permissionKeys: string[]
): Promise<boolean> {
  const userPerms = await getUserPermissions(userId);

  // Check for wildcard permission
  if (userPerms.permissions.includes("*")) {
    return true;
  }

  // Check if user has at least one of the required permissions
  return permissionKeys.some((key) => userPerms.permissions.includes(key));
}

/**
 * Check if user has all of the provided permissions (AND logic)
 */
export async function hasAllPermissions(
  userId: string,
  permissionKeys: string[]
): Promise<boolean> {
  const userPerms = await getUserPermissions(userId);

  // Check for wildcard permission
  if (userPerms.permissions.includes("*")) {
    return true;
  }

  // Check if user has all required permissions
  return permissionKeys.every((key) => userPerms.permissions.includes(key));
}

/**
 * Assert that user has a permission, throw error if not
 */
export async function assertPermission(
  userId: string,
  permissionKey: string,
  errorMessage?: string
): Promise<void> {
  const hasAccess = await hasPermission(userId, permissionKey);

  if (!hasAccess) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: errorMessage || `Permission denied: ${permissionKey} is required`,
    });
  }
}

/**
 * Assert that user has any of the provided permissions, throw error if not
 */
export async function assertAnyPermission(
  userId: string,
  permissionKeys: string[],
  errorMessage?: string
): Promise<void> {
  const hasAccess = await hasAnyPermission(userId, permissionKeys);

  if (!hasAccess) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message:
        errorMessage ||
        `Permission denied: One of [${permissionKeys.join(", ")}] is required`,
    });
  }
}

/**
 * Check permission with fallback to system role
 * Useful for hybrid permission checking where certain system roles always have access
 */
export async function hasPermissionOrRole(
  userId: string,
  permissionKey: string,
  allowedRoles: Role[]
): Promise<boolean> {
  const userPerms = await getUserPermissions(userId);

  // Check if user's system role is in allowed roles
  if (allowedRoles.includes(userPerms.systemRole)) {
    return true;
  }

  // Check for permission
  return hasPermission(userId, permissionKey);
}

/**
 * Permission categories for organizing permissions
 */
export const PermissionKeys = {
  // PAGES
  PAGES: {
    DASHBOARD: "pages.dashboard.view",
    SHOWS: "pages.shows.view",
    SCENES: "pages.scenes.view",
    CALENDAR: "pages.calendar.view",
    ACTORS: "pages.actors.view",
    ANNOUNCEMENTS: "pages.announcements.view",
    MESSAGES: "pages.messages.view",
    USERS: "pages.users.view",
    COMPANIES: "pages.companies.view",
    APPROVALS: "pages.approvals.view",
    USER_APPROVALS: "pages.user_approvals.view",
    CONVERSATIONS: "pages.conversations.view",
    CALL_SHEET: "pages.call_sheet.view",
  },
  // FEATURES
  FEATURES: {
    SHOWS: {
      CREATE: "features.shows.create",
      EDIT: "features.shows.edit",
      DELETE: "features.shows.delete",
    },
    SCENES: {
      CREATE: "features.scenes.create",
      EDIT: "features.scenes.edit",
      DELETE: "features.scenes.delete",
    },
    ACTORS: {
      CREATE: "features.actors.create",
      EDIT: "features.actors.edit",
      DELETE: "features.actors.delete",
    },
    ANNOUNCEMENTS: {
      CREATE: "features.announcements.create",
      EDIT: "features.announcements.edit",
      DELETE: "features.announcements.delete",
    },
    USERS: {
      CREATE: "features.users.create",
      EDIT: "features.users.edit",
      DELETE: "features.users.delete",
    },
    COMPANIES: {
      CREATE: "features.companies.create",
      EDIT: "features.companies.edit",
      DELETE: "features.companies.delete",
    },
    ROLES: {
      CREATE: "features.roles.create",
      EDIT: "features.roles.edit",
      DELETE: "features.roles.delete",
    },
  },
  // MESSAGING
  MESSAGING: {
    ALL: "messaging.message_all",
    COMPANY: "messaging.message_company",
    SHOW: "messaging.message_show",
    CREW: "messaging.message_crew",
    ACTORS: "messaging.message_actors",
  },
  // CONTENT
  CONTENT: {
    APPROVE_SHOWS: "content.approve_shows",
    APPROVE_USERS: "content.approve_users",
    SCENE_TIMERS: "content.control_scene_timers",
    CALL_SHEETS: "content.generate_call_sheets",
    REPORTS: "content.view_reports",
  },
};
