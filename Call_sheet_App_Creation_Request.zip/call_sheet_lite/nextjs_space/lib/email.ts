
import { Resend } from 'resend';
import fs from 'fs';
import path from 'path';

// Read Resend API key from auth secrets file
function getResendApiKey(): string | null {
  try {
    // Only try to read if HOME environment variable is set (development environment)
    if (!process.env.HOME) {
      console.warn('HOME environment variable not set - email functionality will be disabled');
      return null;
    }

    const secretsPath = path.join(process.env.HOME, '.config', 'abacusai_auth_secrets.json');
    
    if (fs.existsSync(secretsPath)) {
      const secrets = JSON.parse(fs.readFileSync(secretsPath, 'utf-8'));
      const apiKey = secrets?.resend?.secrets?.api_key?.value;
      if (apiKey) {
        console.log('Resend API key loaded successfully');
        return apiKey;
      }
    }

    console.warn('Resend API key not found - email functionality will be disabled');
    return null;
  } catch (error) {
    console.error('Failed to read Resend API key:', error);
    return null;
  }
}

// Lazy initialization of Resend client
let resendClient: Resend | null = null;

function getResendClient(): Resend | null {
  if (resendClient === null) {
    const apiKey = getResendApiKey();
    if (apiKey) {
      resendClient = new Resend(apiKey);
    } else {
      console.warn('Resend client not initialized - email functionality will be disabled');
      return null;
    }
  }
  return resendClient;
}

interface SceneNotificationData {
  sceneName: string;
  sceneNumber: string;
  showTitle: string;
  scheduledDate?: Date | null;
  estimatedDuration?: number | null;
  description?: string;
  actors: Array<{
    name: string;
    email: string;
  }>;
  additionalRecipients?: string[];
}

export async function sendSceneCreatedEmail(data: SceneNotificationData) {
  const resend = getResendClient();
  if (!resend) {
    console.warn('Email functionality disabled - skipping scene created email');
    return;
  }

  const recipients = [
    ...data.actors.map(a => a.email),
    ...(data.additionalRecipients || [])
  ];

  if (recipients.length === 0) {
    console.warn('No recipients for scene created email');
    return;
  }

  const scheduledDateStr = data.scheduledDate 
    ? new Date(data.scheduledDate).toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      })
    : 'Not scheduled';

  const durationStr = data.estimatedDuration 
    ? `${data.estimatedDuration} minutes`
    : 'Not specified';

  try {
    await resend.emails.send({
      from: 'Call Sheet <onboarding@resend.dev>',
      to: recipients,
      subject: `New Scene Added: ${data.sceneName} - ${data.showTitle}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #1a1a1a; color: #ffffff;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #f59e0b; margin: 0;">Call Sheet</h1>
            <p style="color: #9ca3af; margin: 5px 0;">Production Management Platform</p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h2 style="color: #f59e0b; margin-top: 0;">New Scene Added</h2>
            <p style="color: #d1d5db;">A new scene has been added to your production schedule.</p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #ffffff; margin-top: 0;">Scene Details</h3>
            <table style="width: 100%; color: #d1d5db;">
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Show:</td>
                <td style="padding: 8px 0;">${data.showTitle}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Scene:</td>
                <td style="padding: 8px 0;">${data.sceneNumber} - ${data.sceneName}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Scheduled Date:</td>
                <td style="padding: 8px 0;">${scheduledDateStr}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Estimated Duration:</td>
                <td style="padding: 8px 0;">${durationStr}</td>
              </tr>
            </table>
            ${data.description ? `
              <div style="margin-top: 15px;">
                <p style="font-weight: bold; margin-bottom: 5px;">Description:</p>
                <p style="color: #9ca3af; margin: 0;">${data.description}</p>
              </div>
            ` : ''}
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #ffffff; margin-top: 0;">Cast Members</h3>
            <ul style="color: #d1d5db; padding-left: 20px;">
              ${data.actors.map(actor => `<li>${actor.name}</li>`).join('')}
            </ul>
          </div>
          
          <div style="text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #374151;">
            <p>This is an automated notification from Call Sheet Production Management Platform.</p>
            <p>Please do not reply to this email.</p>
          </div>
        </div>
      `,
    });

    console.log(`Scene created email sent to ${recipients.length} recipient(s)`);
  } catch (error) {
    console.error('Failed to send scene created email:', error);
  }
}

export async function sendSceneUpdatedEmail(data: SceneNotificationData & { changes: string[] }) {
  const resend = getResendClient();
  if (!resend) {
    console.warn('Email functionality disabled - skipping scene updated email');
    return;
  }

  const recipients = [
    ...data.actors.map(a => a.email),
    ...(data.additionalRecipients || [])
  ];

  if (recipients.length === 0) {
    console.warn('No recipients for scene updated email');
    return;
  }

  const scheduledDateStr = data.scheduledDate 
    ? new Date(data.scheduledDate).toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      })
    : 'Not scheduled';

  const durationStr = data.estimatedDuration 
    ? `${data.estimatedDuration} minutes`
    : 'Not specified';

  try {
    await resend.emails.send({
      from: 'Call Sheet <onboarding@resend.dev>',
      to: recipients,
      subject: `Scene Updated: ${data.sceneName} - ${data.showTitle}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #1a1a1a; color: #ffffff;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #f59e0b; margin: 0;">Call Sheet</h1>
            <p style="color: #9ca3af; margin: 5px 0;">Production Management Platform</p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h2 style="color: #f59e0b; margin-top: 0;">Scene Updated</h2>
            <p style="color: #d1d5db;">Important updates have been made to your scene.</p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #ffffff; margin-top: 0;">Scene Details</h3>
            <table style="width: 100%; color: #d1d5db;">
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Show:</td>
                <td style="padding: 8px 0;">${data.showTitle}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Scene:</td>
                <td style="padding: 8px 0;">${data.sceneNumber} - ${data.sceneName}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Scheduled Date:</td>
                <td style="padding: 8px 0;">${scheduledDateStr}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Estimated Duration:</td>
                <td style="padding: 8px 0;">${durationStr}</td>
              </tr>
            </table>
            ${data.description ? `
              <div style="margin-top: 15px;">
                <p style="font-weight: bold; margin-bottom: 5px;">Description:</p>
                <p style="color: #9ca3af; margin: 0;">${data.description}</p>
              </div>
            ` : ''}
          </div>
          
          ${data.changes && data.changes.length > 0 ? `
            <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
              <h3 style="color: #ffffff; margin-top: 0;">What Changed</h3>
              <ul style="color: #d1d5db; padding-left: 20px;">
                ${data.changes.map(change => `<li>${change}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #ffffff; margin-top: 0;">Cast Members</h3>
            <ul style="color: #d1d5db; padding-left: 20px;">
              ${data.actors.map(actor => `<li>${actor.name}</li>`).join('')}
            </ul>
          </div>
          
          <div style="text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #374151;">
            <p>This is an automated notification from Call Sheet Production Management Platform.</p>
            <p>Please do not reply to this email.</p>
          </div>
        </div>
      `,
    });

    console.log(`Scene updated email sent to ${recipients.length} recipient(s)`);
  } catch (error) {
    console.error('Failed to send scene updated email:', error);
  }
}

export async function sendUserApprovedEmail(userEmail: string, userName: string) {
  const resend = getResendClient();
  if (!resend) {
    console.warn('Email functionality disabled - skipping user approved email');
    return;
  }

  try {
    await resend.emails.send({
      from: 'Call Sheet <onboarding@resend.dev>',
      to: userEmail,
      subject: 'Your Call Sheet Account Has Been Approved',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #1a1a1a; color: #ffffff;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #f59e0b; margin: 0;">Call Sheet</h1>
            <p style="color: #9ca3af; margin: 5px 0;">Production Management Platform</p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h2 style="color: #10b981; margin-top: 0;">Account Approved!</h2>
            <p style="color: #d1d5db;">Hello ${userName},</p>
            <p style="color: #d1d5db;">Great news! Your Call Sheet account has been approved by an administrator.</p>
            <p style="color: #d1d5db;">You can now log in and start using the platform.</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXTAUTH_URL || 'https://call.abacusai.app'}/auth/login" 
               style="display: inline-block; background-color: #f59e0b; color: #000000; text-decoration: none; padding: 12px 30px; border-radius: 6px; font-weight: bold;">
              Login Now
            </a>
          </div>
          
          <div style="text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #374151;">
            <p>This is an automated notification from Call Sheet Production Management Platform.</p>
            <p>Please do not reply to this email.</p>
          </div>
        </div>
      `,
    });

    console.log(`User approved email sent to ${userEmail}`);
  } catch (error) {
    console.error('Failed to send user approved email:', error);
  }
}

export async function sendTestEmail(userEmail: string, userName: string) {
  const resend = getResendClient();
  if (!resend) {
    const error = new Error('Email functionality is disabled - Resend API key not configured');
    console.error('Failed to send test email:', error);
    throw error;
  }

  try {
    await resend.emails.send({
      from: 'Call Sheet <onboarding@resend.dev>',
      to: userEmail,
      subject: 'Hey Busy Buddy',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #1a1a1a; color: #ffffff;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #f59e0b; margin: 0;">Call Sheet</h1>
            <p style="color: #9ca3af; margin: 5px 0;">Production Management Platform</p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 30px; margin-bottom: 20px; text-align: center;">
            <h2 style="color: #f59e0b; margin-top: 0; margin-bottom: 20px;">Hey Busy Buddy</h2>
            <p style="color: #d1d5db; font-size: 16px; line-height: 1.6; margin: 0;">
              We're just checking in because we care. Enjoy the rest of your busy day — and don't forget to smile! 🙂
            </p>
          </div>
          
          <div style="background-color: #262626; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <p style="color: #9ca3af; font-size: 14px; margin: 0; text-align: center;">
              This is a test email to verify that <strong style="color: #ffffff;">${userName}</strong> can receive system communications from Call Sheet.
            </p>
          </div>
          
          <div style="text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #374151;">
            <p>This is a test notification from Call Sheet Production Management Platform.</p>
            <p>If you received this email, your account is correctly configured to receive system communications.</p>
          </div>
        </div>
      `,
    });

    console.log(`Test email sent to ${userEmail}`);
  } catch (error) {
    console.error('Failed to send test email:', error);
    throw error; // Re-throw so the API can handle it
  }
}
