
import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Starting database seed...");

  // Check if test users already exist
  const existingDeveloper = await prisma.user.findUnique({
    where: { email: "developer@callsheet.com" },
  });

  if (existingDeveloper) {
    console.log("✅ Test users already exist, skipping seed");
    return;
  }

  // Create test users with different roles
  const hashedPassword = await bcrypt.hash("password123", 10);
  
  // Create Developer user (full access)
  const developerUser = await prisma.user.create({
    data: {
      name: "Master Prince",
      email: "developer@callsheet.com",
      password: hashedPassword,
      role: Role.DEVELOPER,
      isActive: true,
    },
  });

  // Create Admin user first (will be assigned to company)
  const adminUser = await prisma.user.create({
    data: {
      name: "Sarah Admin",
      email: "admin@callsheet.com",
      password: hashedPassword,
      role: Role.ADMIN,
      isActive: true,
    },
  });

  // Create Admin user for second company
  const adminUser2 = await prisma.user.create({
    data: {
      name: "John Admin",
      email: "admin2@callsheet.com",
      password: hashedPassword,
      role: Role.ADMIN,
      isActive: true,
    },
  });

  // Create companies with admins
  const company1 = await prisma.company.create({
    data: {
      name: "Sunset Productions",
      description: "Leading film production company specializing in drama and thriller",
      isActive: true,
      admins: {
        connect: { id: adminUser.id },
      },
    },
  });

  const company2 = await prisma.company.create({
    data: {
      name: "Moonlight Studios",
      description: "Independent studio focused on creative storytelling",
      isActive: true,
      admins: {
        connect: { id: adminUser2.id },
      },
    },
  });

  // Create shows (approved shows for testing)
  const show1 = await prisma.show.create({
    data: {
      title: "The Midnight Chronicles",
      description: "A thrilling detective series set in noir-style Los Angeles",
      status: "Shooting",
      creatorId: adminUser.id,
      companyId: company1.id,
      isActive: true,
      isApproved: true, // Pre-approved for testing
    },
  });

  const show2 = await prisma.show.create({
    data: {
      title: "Sunset Boulevard",
      description: "A romantic drama about finding love in unexpected places",
      status: "Pre-Production",
      creatorId: adminUser.id,
      companyId: company1.id,
      isActive: true,
      isApproved: true, // Pre-approved for testing
    },
  });

  // Create a pending approval show
  const show3 = await prisma.show.create({
    data: {
      title: "Urban Legends",
      description: "A horror anthology series",
      status: "Pre-Production",
      creatorId: adminUser2.id,
      companyId: company2.id,
      isActive: true,
      isApproved: false, // Pending approval
    },
  });

  // Create Production Admin user assigned to show
  const productionAdminUser = await prisma.user.create({
    data: {
      name: "Mike Production",
      email: "productionadmin@callsheet.com",
      password: hashedPassword,
      role: Role.PRODUCTION_ADMIN,
      assignedShowId: show1.id,
      isActive: true,
    },
  });

  // Create Crew user
  const crewUser = await prisma.user.create({
    data: {
      name: "Jessica Crew",
      email: "crew@callsheet.com",
      password: hashedPassword,
      role: Role.CREW,
      isActive: true,
    },
  });

  // Create Actor user
  const actorUser = await prisma.user.create({
    data: {
      name: "Tom Actor",
      email: "actor@callsheet.com",
      password: hashedPassword,
      role: Role.ACTOR,
      isActive: true,
    },
  });

  // Also create the default test user for compatibility
  const defaultTestPassword = await bcrypt.hash("johndoe123", 10);
  await prisma.user.create({
    data: {
      name: "John Doe",
      email: "john@doe.com",
      password: defaultTestPassword,
      role: Role.CREW,
      isActive: true,
    },
  });

  console.log("✅ Created test users:");
  console.log("   Developer (Master Prince): developer@callsheet.com / password123");
  console.log("   Admin 1: admin@callsheet.com / password123 (Company: Sunset Productions)");
  console.log("   Admin 2: admin2@callsheet.com / password123 (Company: Moonlight Studios)");
  console.log("   Production Admin: productionadmin@callsheet.com / password123 (Show: The Midnight Chronicles)");
  console.log("   Crew: crew@callsheet.com / password123");
  console.log("   Actor: actor@callsheet.com / password123");
  console.log("   Default: john@doe.com / johndoe123");

  console.log("✅ Created sample companies with admins");
  console.log("✅ Created sample shows (2 approved, 1 pending approval)");

  // Create sample scenes for show 1
  await prisma.scene.createMany({
    data: [
      {
        showId: show1.id,
        sceneNumber: "1A",
        name: "Detective's office - morning",
        description: "Opening scene establishing the main character",
        estimatedDuration: 900, // 15 minutes
        status: "Completed",
        actualElapsedTime: 840, // 14 minutes
      },
      {
        showId: show1.id,
        sceneNumber: "2B",
        name: "Crime scene investigation",
        description: "Detective arrives at the crime scene",
        estimatedDuration: 1200, // 20 minutes
        status: "In Progress",
        timerStartedAt: new Date(),
        actualElapsedTime: 300, // 5 minutes elapsed
        accumulatedPauseTime: 0,
      },
      {
        showId: show1.id,
        sceneNumber: "3A",
        name: "Interrogation room",
        description: "First suspect interview",
        estimatedDuration: 600, // 10 minutes
        status: "Not Started",
      },
    ],
  });

  // Create sample scenes for show 2
  await prisma.scene.createMany({
    data: [
      {
        showId: show2.id,
        sceneNumber: "1",
        name: "Coffee shop meet-cute",
        description: "Main characters meet for the first time",
        estimatedDuration: 720, // 12 minutes
        status: "Not Started",
      },
      {
        showId: show2.id,
        sceneNumber: "2",
        name: "Walk in the park",
        description: "Second encounter, conversation deepens",
        estimatedDuration: 900, // 15 minutes
        status: "Not Started",
      },
    ],
  });

  console.log("✅ Created sample scenes");
  console.log("🎉 Database seeding completed!");
}

main()
  .catch((e) => {
    console.error("❌ Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
