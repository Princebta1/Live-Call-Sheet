
import 'dotenv/config';
import { PrismaClient, PermissionCategory } from '@prisma/client';

const prisma = new PrismaClient();

const defaultPermissions = [
  // PAGES permissions - what pages users can access
  {
    category: PermissionCategory.PAGES,
    key: 'pages.dashboard.view',
    name: 'View Dashboard',
    description: 'Access to view the main dashboard',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.shows.view',
    name: 'View Shows',
    description: 'Access to view shows listing page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.scenes.view',
    name: 'View Scenes',
    description: 'Access to view scenes page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.calendar.view',
    name: 'View Calendar',
    description: 'Access to view calendar page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.announcements.view',
    name: 'View Announcements',
    description: 'Access to view announcements page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.actors.view',
    name: 'View Actors',
    description: 'Access to view actors/cast page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.messages.view',
    name: 'View Messages',
    description: 'Access to view messages page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.profile.view',
    name: 'View Profile',
    description: 'Access to view profile page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.companies.view',
    name: 'View Companies',
    description: 'Access to view companies page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.users.view',
    name: 'View Users',
    description: 'Access to view user management page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.approvals.view',
    name: 'View Approvals',
    description: 'Access to view approvals page',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.conversations.view',
    name: 'View Conversations',
    description: 'Access to view direct messages/conversations',
  },
  {
    category: PermissionCategory.PAGES,
    key: 'pages.callsheet.view',
    name: 'View Call Sheet',
    description: 'Access to view and generate call sheets',
  },

  // FEATURES permissions - what features users can use
  {
    category: PermissionCategory.FEATURES,
    key: 'features.shows.create',
    name: 'Create Shows',
    description: 'Ability to create new shows',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.shows.edit',
    name: 'Edit Shows',
    description: 'Ability to edit existing shows',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.shows.delete',
    name: 'Delete Shows',
    description: 'Ability to delete shows',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.scenes.create',
    name: 'Create Scenes',
    description: 'Ability to create new scenes',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.scenes.edit',
    name: 'Edit Scenes',
    description: 'Ability to edit existing scenes',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.scenes.delete',
    name: 'Delete Scenes',
    description: 'Ability to delete scenes',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.actors.create',
    name: 'Create Actors',
    description: 'Ability to add new actors/cast members',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.actors.edit',
    name: 'Edit Actors',
    description: 'Ability to edit actor/cast information',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.actors.delete',
    name: 'Delete Actors',
    description: 'Ability to remove actors/cast members',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.announcements.create',
    name: 'Create Announcements',
    description: 'Ability to create announcements',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.announcements.edit',
    name: 'Edit Announcements',
    description: 'Ability to edit announcements',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.announcements.delete',
    name: 'Delete Announcements',
    description: 'Ability to delete announcements',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.users.create',
    name: 'Create Users',
    description: 'Ability to create new users',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.users.edit',
    name: 'Edit Users',
    description: 'Ability to edit user information',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.users.delete',
    name: 'Delete Users',
    description: 'Ability to delete users',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.companies.create',
    name: 'Create Companies',
    description: 'Ability to create new companies',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.companies.edit',
    name: 'Edit Companies',
    description: 'Ability to edit company information',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.companies.delete',
    name: 'Delete Companies',
    description: 'Ability to delete companies',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.roles.create',
    name: 'Create Roles',
    description: 'Ability to create custom roles',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.roles.edit',
    name: 'Edit Roles',
    description: 'Ability to edit custom roles',
  },
  {
    category: PermissionCategory.FEATURES,
    key: 'features.roles.delete',
    name: 'Delete Roles',
    description: 'Ability to delete custom roles',
  },

  // MESSAGING permissions - who can message whom
  {
    category: PermissionCategory.MESSAGING,
    key: 'messaging.all.send',
    name: 'Message Anyone',
    description: 'Ability to send messages to any user',
  },
  {
    category: PermissionCategory.MESSAGING,
    key: 'messaging.company.send',
    name: 'Message Company Members',
    description: 'Ability to send messages to company members only',
  },
  {
    category: PermissionCategory.MESSAGING,
    key: 'messaging.show.send',
    name: 'Message Show Members',
    description: 'Ability to send messages to show members only',
  },
  {
    category: PermissionCategory.MESSAGING,
    key: 'messaging.crew.send',
    name: 'Message Crew',
    description: 'Ability to send messages to crew members',
  },
  {
    category: PermissionCategory.MESSAGING,
    key: 'messaging.actors.send',
    name: 'Message Actors',
    description: 'Ability to send messages to actors',
  },

  // CONTENT permissions - specific content management
  {
    category: PermissionCategory.CONTENT,
    key: 'content.shows.approve',
    name: 'Approve Shows',
    description: 'Ability to approve/reject show requests',
  },
  {
    category: PermissionCategory.CONTENT,
    key: 'content.users.approve',
    name: 'Approve Users',
    description: 'Ability to approve/reject user registrations',
  },
  {
    category: PermissionCategory.CONTENT,
    key: 'content.scenes.timer',
    name: 'Control Scene Timers',
    description: 'Ability to start/stop/pause scene timers',
  },
  {
    category: PermissionCategory.CONTENT,
    key: 'content.callsheet.generate',
    name: 'Generate Call Sheets',
    description: 'Ability to generate and download call sheets',
  },
  {
    category: PermissionCategory.CONTENT,
    key: 'content.reports.view',
    name: 'View Reports',
    description: 'Ability to view production reports and analytics',
  },
];

async function seedPermissions() {
  console.log('🔐 Seeding permissions...');

  for (const permission of defaultPermissions) {
    await prisma.permission.upsert({
      where: { key: permission.key },
      update: {
        name: permission.name,
        description: permission.description,
      },
      create: permission,
    });
  }

  const count = await prisma.permission.count();
  console.log(`✅ Seeded ${count} permissions`);
}

async function main() {
  try {
    await seedPermissions();
    console.log('🎉 Permission seeding completed!');
  } catch (error) {
    console.error('❌ Permission seed error:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
