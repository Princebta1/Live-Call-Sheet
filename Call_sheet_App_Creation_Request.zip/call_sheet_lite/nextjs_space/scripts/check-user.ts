
import { PrismaClient } from '@prisma/client';
import 'dotenv/config';

const prisma = new PrismaClient();

async function main() {
  const users = await prisma.user.findMany({ 
    where: { email: 'dev@example.com' },
    select: { id: true, email: true, role: true, customRoleId: true, isActive: true }
  });
  console.log(JSON.stringify(users, null, 2));
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => {
    console.error(e);
    prisma.$disconnect();
    process.exit(1);
  });
