
import { z } from 'zod';
import { router, protectedProcedure, adminOrProductionAdminProcedure, developerProcedure } from '../../lib/trpc';
import { TRPCError } from '@trpc/server';
import { Role } from '@prisma/client';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const showsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const user = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true, companyId: true, assignedShowId: true, isActive: true },
    });

    if (!user) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
    }

    // Check if user is active
    if (!user.isActive) {
      throw new TRPCError({ 
        code: 'FORBIDDEN', 
        message: 'Your account has been deactivated. Please contact production for access.' 
      });
    }

    // Check permission to view shows page
    const canViewShows = await hasPermission(ctx.session.user.id, PermissionKeys.PAGES.SHOWS);
    if (!canViewShows) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: 'You do not have permission to view shows',
      });
    }

    // Build filter based on user role
    let whereClause: any = { 
      isActive: true,
      isApproved: true, // Only show approved shows by default
    };

    if (user.role === Role.DEVELOPER) {
      // Developer sees all active shows (approved or not)
      delete whereClause.isApproved;
    } else if (user.role === Role.ADMIN && user.companyId) {
      // Admin sees shows in their company
      whereClause.companyId = user.companyId;
    } else if (user.role === Role.PRODUCTION_ADMIN && user.assignedShowId) {
      // Production Admin sees their assigned show
      whereClause.id = user.assignedShowId;
    } else {
      // Crew and Actor see shows they created or are assigned to
      whereClause.creatorId = ctx.session.user.id;
    }

    const shows = await ctx.prisma.show.findMany({
      where: whereClause,
      include: {
        _count: {
          select: { scenes: true },
        },
        company: {
          select: {
            id: true,
            name: true,
            isActive: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Filter out shows from inactive companies
    const activeShows = shows.filter(show => show.company?.isActive !== false);

    return activeShows;
  }),

  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const user = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true, isActive: true },
      });

      if (!user || !user.isActive) {
        throw new TRPCError({ 
          code: 'FORBIDDEN', 
          message: 'Your account has been deactivated. Please contact production for access.' 
        });
      }

      const show = await ctx.prisma.show.findUnique({
        where: { id: input.id },
        include: {
          scenes: {
            orderBy: { sceneNumber: 'asc' },
            include: {
              sceneActors: {
                include: {
                  actor: true,
                },
              },
            },
          },
          company: {
            select: {
              id: true,
              name: true,
              description: true,
              isActive: true,
            },
          },
          creator: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
          productionAdmins: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
      });

      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }

      // Check if show is active
      if (!show.isActive) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This show has been deactivated. Please contact production for access.',
        });
      }

      // Check if company is active
      if (!show.company?.isActive) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This show\'s company has been deactivated. Please contact production for access.',
        });
      }

      // Check if user has access to this show
      const hasAccess = 
        user.role === Role.DEVELOPER ||
        (user.role === Role.ADMIN && user.companyId === show.companyId) ||
        (user.role === Role.PRODUCTION_ADMIN && user.assignedShowId === show.id) ||
        show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have access to this show',
        });
      }

      // Non-developers can't see unapproved shows
      if (!show.isApproved && user.role !== Role.DEVELOPER) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This show is pending approval',
        });
      }

      return show;
    }),

  create: adminOrProductionAdminProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        status: z.enum(['Pre-Production', 'Shooting', 'Wrapped']).default('Pre-Production'),
        companyId: z.string(), // Required - every show must belong to a company
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create shows
      const canCreateShow = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.SHOWS.CREATE);
      if (!canCreateShow) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create shows',
        });
      }

      const user = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true },
      });

      // Check if user has access to the company
      if (user?.role === Role.ADMIN && user.companyId !== input.companyId) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You can only create shows for your company',
        });
      }

      const show = await ctx.prisma.show.create({
        data: {
          title: input.title,
          description: input.description,
          status: input.status,
          companyId: input.companyId,
          creatorId: ctx.session.user.id,
          isActive: true,
          isApproved: user?.role === Role.DEVELOPER, // Auto-approve for developers
        },
      });

      return show;
    }),

  update: adminOrProductionAdminProcedure
    .input(
      z.object({
        id: z.string(),
        title: z.string().min(1).optional(),
        description: z.string().optional(),
        status: z.enum(['Pre-Production', 'Shooting', 'Wrapped']).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit shows
      const canEditShow = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.SHOWS.EDIT);
      if (!canEditShow) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit shows',
        });
      }

      const { id, ...data } = input;

      const user = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true },
      });

      // Developers can edit any show, others can only edit shows they created
      const whereClause = user?.role === Role.DEVELOPER 
        ? { id } 
        : { id, creatorId: ctx.session.user.id };

      const show = await ctx.prisma.show.findFirst({
        where: whereClause,
      });

      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found or you do not have permission to edit it',
        });
      }

      const updatedShow = await ctx.prisma.show.update({
        where: { id },
        data,
      });

      return updatedShow;
    }),

  delete: adminOrProductionAdminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete shows
      const canDeleteShow = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.SHOWS.DELETE);
      if (!canDeleteShow) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete shows',
        });
      }

      const user = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true },
      });

      // Developers can delete any show, others can only delete shows they created
      const whereClause = user?.role === Role.DEVELOPER 
        ? { id: input.id } 
        : { id: input.id, creatorId: ctx.session.user.id };

      const show = await ctx.prisma.show.findFirst({
        where: whereClause,
      });

      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found or you do not have permission to delete it',
        });
      }

      await ctx.prisma.show.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Developer-only: Approve show
  approve: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to approve shows
      const canApproveShows = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.APPROVE_SHOWS);
      if (!canApproveShows) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to approve shows',
        });
      }

      // Check if show has at least one production admin assigned
      const productionAdminsCount = await ctx.prisma.user.count({
        where: {
          role: Role.PRODUCTION_ADMIN,
          assignedShowId: input.id,
          isActive: true,
        },
      });

      if (productionAdminsCount === 0) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Cannot approve show: At least one active Production Admin must be assigned to this show',
        });
      }

      const show = await ctx.prisma.show.update({
        where: { id: input.id },
        data: { isApproved: true },
      });

      return show;
    }),

  // Developer-only: Reject show (delete it)
  reject: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to approve/reject shows
      const canApproveShows = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.APPROVE_SHOWS);
      if (!canApproveShows) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to reject shows',
        });
      }

      const show = await ctx.prisma.show.findUnique({
        where: { id: input.id },
      });

      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }

      await ctx.prisma.show.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Developer-only: Toggle show active status
  toggleActive: developerProcedure
    .input(z.object({ id: z.string(), isActive: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // If activating the show, check if it has at least one production admin assigned
      if (input.isActive) {
        const productionAdminsCount = await ctx.prisma.user.count({
          where: {
            role: Role.PRODUCTION_ADMIN,
            assignedShowId: input.id,
            isActive: true,
          },
        });

        if (productionAdminsCount === 0) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Cannot activate show: At least one active Production Admin must be assigned to this show',
          });
        }
      }

      const show = await ctx.prisma.show.update({
        where: { id: input.id },
        data: { isActive: input.isActive },
      });

      return show;
    }),

  // Get pending approval shows (Developer only)
  pendingApproval: developerProcedure.query(async ({ ctx }) => {
    const shows = await ctx.prisma.show.findMany({
      where: {
        isApproved: false,
        isActive: true,
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        company: {
          select: {
            id: true,
            name: true,
          },
        },
        _count: {
          select: { scenes: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return shows;
  }),

  // Assign production admin to show
  assignProductionAdmin: developerProcedure
    .input(
      z.object({
        showId: z.string(),
        userId: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if user is a PRODUCTION_ADMIN
      const user = await ctx.prisma.user.findUnique({
        where: { id: input.userId },
      });

      if (!user || user.role !== 'PRODUCTION_ADMIN') {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'User must be a Production Admin',
        });
      }

      // Check if user is already assigned to this show
      if (user.assignedShowId === input.showId) {
        return { message: 'User is already assigned to this show' };
      }

      // Update user's assignedShowId
      await ctx.prisma.user.update({
        where: { id: input.userId },
        data: { assignedShowId: input.showId },
      });

      return { message: 'Production admin assigned successfully' };
    }),

  // Remove production admin from show
  removeProductionAdmin: developerProcedure
    .input(
      z.object({
        showId: z.string(),
        userId: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Update user's assignedShowId to null
      await ctx.prisma.user.update({
        where: { id: input.userId },
        data: { assignedShowId: null },
      });

      return { message: 'Production admin removed successfully' };
    }),
});
