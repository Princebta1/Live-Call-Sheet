
import { z } from 'zod';
import { router, protectedProcedure } from '../../lib/trpc';
import { prisma } from '../../lib/db';
import { TRPCError } from '@trpc/server';

export const messagesRouter = router({
  // List messages for a show
  list: protectedProcedure
    .input(z.object({ showId: z.string() }))
    .query(async ({ input }) => {
      return await prisma.message.findMany({
        where: { showId: input.showId },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    }),

  // Create message (any authenticated user can send messages)
  create: protectedProcedure
    .input(
      z.object({
        showId: z.string(),
        content: z.string().min(1),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return await prisma.message.create({
        data: {
          ...input,
          senderId: ctx.session.user.id,
        },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
      });
    }),

  // Delete message (only the sender or admins can delete)
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const message = await prisma.message.findUnique({
        where: { id: input.id },
      });

      if (!message) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Message not found' });
      }

      // Check if user is the sender or has admin privileges
      const userRole = ctx.session.user.role || '';
      const isAdmin = ['DEVELOPER', 'ADMIN', 'PRODUCTION_ADMIN'].includes(userRole);
      const isSender = message.senderId === ctx.session.user.id;

      if (!isAdmin && !isSender) {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Not authorized to delete this message' });
      }

      return await prisma.message.delete({
        where: { id: input.id },
      });
    }),
});
