
import { z } from 'zod';
import { router, developerProcedure, protectedProcedure, adminOrProductionAdminProcedure } from '../../lib/trpc';
import { TRPCError } from '@trpc/server';
import bcrypt from 'bcryptjs';
import { sendUserApprovedEmail, sendTestEmail } from '../../lib/email';
import { Role } from '@prisma/client';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const usersRouter = router({
  // List all users (Developer, Admin, Production Admin)
  list: protectedProcedure.query(async ({ ctx }) => {
    const currentUser = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true, assignedShowId: true, companyId: true },
    });

    if (!currentUser) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
    }

    const selectFields = {
      id: true,
      name: true,
      email: true,
      role: true,
      customRoleId: true,
      isActive: true,
      companyId: true,
      assignedShowId: true,
      createdAt: true,
      company: {
        select: {
          id: true,
          name: true,
        },
      },
      assignedShow: {
        select: {
          id: true,
          title: true,
        },
      },
      customRole: {
        select: {
          id: true,
          name: true,
        },
      },
    };

    // Developer sees all users
    if (currentUser.role === 'DEVELOPER') {
      return await ctx.prisma.user.findMany({
        select: selectFields,
        orderBy: { createdAt: 'desc' },
      });
    }

    // Production Admin sees users assigned to their show + actors/crew
    if (currentUser.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId) {
      return await ctx.prisma.user.findMany({
        where: {
          OR: [
            { assignedShowId: currentUser.assignedShowId },
            { role: 'ACTOR' },
            { role: 'CREW' },
          ],
        },
        select: selectFields,
        orderBy: { createdAt: 'desc' },
      });
    }

    // Admin sees users in their company
    if (currentUser.role === 'ADMIN' && currentUser.companyId) {
      return await ctx.prisma.user.findMany({
        where: {
          OR: [
            { companyId: currentUser.companyId },
            { role: 'ACTOR' },
            { role: 'CREW' },
          ],
        },
        select: selectFields,
        orderBy: { createdAt: 'desc' },
      });
    }

    return [];
  }),

  // Get user by ID (Developer only)
  getById: developerProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const user = await ctx.prisma.user.findUnique({
        where: { id: input.id },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          companyId: true,
          assignedShowId: true,
          createdAt: true,
          company: {
            select: {
              id: true,
              name: true,
            },
          },
          assignedShow: {
            select: {
              id: true,
              title: true,
            },
          },
        },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      return user;
    }),

  // Create user (Developer, Admin, Production Admin)
  create: adminOrProductionAdminProcedure
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        password: z.string().min(6),
        role: z.nativeEnum(Role),
        customRoleId: z.string().optional(),
        companyId: z.string().optional(),
        assignedShowId: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create users
      const canCreateUser = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.USERS.CREATE);
      if (!canCreateUser) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create users',
        });
      }

      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, assignedShowId: true, companyId: true },
      });

      if (!currentUser) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
      }

      // Production Admin can only create users with ACTOR or CREW role assigned to their show
      if (currentUser.role === 'PRODUCTION_ADMIN') {
        if (!['ACTOR', 'CREW'].includes(input.role)) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Production Admin can only create ACTOR or CREW users',
          });
        }
        if (!currentUser.assignedShowId) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Production Admin must be assigned to a show',
          });
        }
        // Force assignedShowId to be the Production Admin's show
        input.assignedShowId = currentUser.assignedShowId;
      }

      // Admin can create users but only assign them to their company
      if (currentUser.role === 'ADMIN') {
        if (input.role === 'DEVELOPER') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Admin cannot create DEVELOPER users',
          });
        }
        if (input.companyId && input.companyId !== currentUser.companyId) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Admin can only assign users to their own company',
          });
        }
      }
      // Check if user already exists
      const existingUser = await ctx.prisma.user.findUnique({
        where: { email: input.email },
      });

      if (existingUser) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'User with this email already exists',
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(input.password, 10);

      // Create user
      const user = await ctx.prisma.user.create({
        data: {
          name: input.name,
          email: input.email,
          password: hashedPassword,
          role: input.role,
          customRoleId: input.customRoleId,
          isActive: true, // Users created by admins are automatically active
          companyId: input.companyId,
          assignedShowId: input.assignedShowId,
        },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          customRoleId: true,
          isActive: true,
          companyId: true,
          assignedShowId: true,
          customRole: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      return user;
    }),

  // Update user (Developer, Admin, Production Admin)
  update: adminOrProductionAdminProcedure
    .input(
      z.object({
        id: z.string(),
        name: z.string().min(1).optional(),
        email: z.string().email().optional(),
        password: z.string().min(6).optional(),
        role: z.nativeEnum(Role).optional(),
        customRoleId: z.string().nullable().optional(),
        companyId: z.string().nullable().optional(),
        assignedShowId: z.string().nullable().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit users
      const canEditUser = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.USERS.EDIT);
      if (!canEditUser) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit users',
        });
      }

      const { id, password, ...data } = input;

      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, assignedShowId: true, companyId: true },
      });

      if (!currentUser) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Current user not found' });
      }

      // Check if user exists
      const user = await ctx.prisma.user.findUnique({
        where: { id },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Production Admin can only update users in their show and only ACTOR/CREW roles
      if (currentUser.role === 'PRODUCTION_ADMIN') {
        if (user.assignedShowId !== currentUser.assignedShowId) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'You can only update users assigned to your show',
          });
        }
        if (!['ACTOR', 'CREW'].includes(user.role)) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Production Admin can only update ACTOR or CREW users',
          });
        }
        if (data.role && !['ACTOR', 'CREW'].includes(data.role)) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Production Admin can only assign ACTOR or CREW roles',
          });
        }
        // Prevent Production Admin from changing show assignment
        delete data.assignedShowId;
        delete data.companyId;
      }

      // Admin can update users but only in their company
      if (currentUser.role === 'ADMIN') {
        if (data.role === 'DEVELOPER') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Admin cannot assign DEVELOPER role',
          });
        }
        if (data.companyId && data.companyId !== currentUser.companyId) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Admin can only assign users to their own company',
          });
        }
      }

      // If email is being updated, check it doesn't conflict
      if (data.email && data.email !== user.email) {
        const existingUser = await ctx.prisma.user.findUnique({
          where: { email: data.email },
        });

        if (existingUser) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'Email already in use',
          });
        }
      }

      // Prepare update data
      const updateData: any = { ...data };

      // Hash new password if provided
      if (password) {
        updateData.password = await bcrypt.hash(password, 10);
      }

      // Update user
      const updatedUser = await ctx.prisma.user.update({
        where: { id },
        data: updateData,
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          companyId: true,
          assignedShowId: true,
        },
      });

      return updatedUser;
    }),

  // Delete user (Developer, Admin, Production Admin)
  delete: adminOrProductionAdminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete users
      const canDeleteUser = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.USERS.DELETE);
      if (!canDeleteUser) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete users',
        });
      }

      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, assignedShowId: true, companyId: true },
      });

      if (!currentUser) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Current user not found' });
      }

      // Check if user exists
      const user = await ctx.prisma.user.findUnique({
        where: { id: input.id },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Prevent deleting yourself
      if (user.id === ctx.session.user.id) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Cannot delete your own account',
        });
      }

      // Production Admin can only delete users in their show and only ACTOR/CREW roles
      if (currentUser.role === 'PRODUCTION_ADMIN') {
        if (user.assignedShowId !== currentUser.assignedShowId) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'You can only delete users assigned to your show',
          });
        }
        if (!['ACTOR', 'CREW'].includes(user.role)) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Production Admin can only delete ACTOR or CREW users',
          });
        }
      }

      // Admin can delete users but only in their company
      if (currentUser.role === 'ADMIN') {
        if (user.companyId !== currentUser.companyId) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Admin can only delete users in their own company',
          });
        }
        if (user.role === 'DEVELOPER') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Admin cannot delete DEVELOPER users',
          });
        }
      }

      // Delete user
      await ctx.prisma.user.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Toggle user active status (Developer only)
  toggleActive: developerProcedure
    .input(z.object({ id: z.string(), isActive: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Prevent deactivating yourself
      if (input.id === ctx.session.user.id && !input.isActive) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Cannot deactivate your own account',
        });
      }

      const user = await ctx.prisma.user.update({
        where: { id: input.id },
        data: { isActive: input.isActive },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          isActive: true,
        },
      });

      return user;
    }),

  // Get current user profile
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const user = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
        companyId: true,
        assignedShowId: true,
        company: {
          select: {
            id: true,
            name: true,
            isActive: true,
          },
        },
        assignedShow: {
          select: {
            id: true,
            title: true,
            isActive: true,
            isApproved: true,
          },
        },
      },
    });

    return user;
  }),

  // List pending user approvals (Developer only)
  pendingApproval: developerProcedure.query(async ({ ctx }) => {
    const users = await ctx.prisma.user.findMany({
      where: { isActive: false },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
    });

    return users;
  }),

  // Approve user (Developer only)
  approveUser: developerProcedure
    .input(z.object({ 
      id: z.string(),
      companyId: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to approve users
      const canApproveUsers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.APPROVE_USERS);
      if (!canApproveUsers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to approve users',
        });
      }

      // Get user info before approval
      const userToApprove = await ctx.prisma.user.findUnique({
        where: { id: input.id },
        select: { name: true, email: true, role: true },
      });

      if (!userToApprove) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Check if company assignment is required for ADMIN or PRODUCTION_ADMIN
      if ((userToApprove.role === 'ADMIN' || userToApprove.role === 'PRODUCTION_ADMIN') && !input.companyId) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: `${userToApprove.role === 'ADMIN' ? 'Admin' : 'Production Admin'} users must be assigned to a company`,
        });
      }

      // Approve and optionally assign to company
      const user = await ctx.prisma.user.update({
        where: { id: input.id },
        data: { 
          isActive: true,
          ...(input.companyId && { companyId: input.companyId }),
        },
      });

      // Send approval email notification
      try {
        await sendUserApprovedEmail(user.email, user.name);
      } catch (emailError) {
        console.error('Failed to send user approved email:', emailError);
        // Don't throw - user was approved successfully
      }

      return user;
    }),

  // Reject user (Developer only)
  rejectUser: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to approve/reject users
      const canApproveUsers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.APPROVE_USERS);
      if (!canApproveUsers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to reject users',
        });
      }

      // Delete the user account
      await ctx.prisma.user.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Send test email (Developer only)
  sendTestEmail: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Get user info
      const user = await ctx.prisma.user.findUnique({
        where: { id: input.id },
        select: { name: true, email: true },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Send test email
      try {
        await sendTestEmail(user.email, user.name);
        return { success: true, message: `Test email sent to ${user.email}` };
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to send test email. Please check the email configuration.',
        });
      }
    }),

  // Reset user password (Developer only)
  resetPassword: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit users
      const canEditUser = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.USERS.EDIT);
      if (!canEditUser) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to reset user passwords',
        });
      }

      // Get user info
      const user = await ctx.prisma.user.findUnique({
        where: { id: input.id },
        select: { name: true, email: true },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Generate a temporary password (8 characters: mix of letters and numbers)
      const tempPassword = Math.random().toString(36).slice(-8).toUpperCase();
      
      // Hash the temporary password
      const hashedPassword = await bcrypt.hash(tempPassword, 10);

      // Set expiry to 7 days from now
      const tempPasswordExpiry = new Date();
      tempPasswordExpiry.setDate(tempPasswordExpiry.getDate() + 7);

      // Update user with temporary password
      await ctx.prisma.user.update({
        where: { id: input.id },
        data: {
          password: hashedPassword,
          mustChangePassword: true,
          tempPasswordExpiry,
        },
      });

      return { 
        success: true, 
        tempPassword,
        expiresAt: tempPasswordExpiry,
        message: `Temporary password generated for ${user.email}` 
      };
    }),

  // Change password (for users with temporary passwords)
  changePassword: protectedProcedure
    .input(
      z.object({
        currentPassword: z.string().min(1),
        newPassword: z.string().min(6, 'New password must be at least 6 characters'),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Get user with current password
      const user = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: {
          id: true,
          email: true,
          password: true,
          mustChangePassword: true,
          tempPasswordExpiry: true,
        },
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Verify current password
      const isValidPassword = await bcrypt.compare(input.currentPassword, user.password);
      if (!isValidPassword) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Current password is incorrect',
        });
      }

      // Check if temporary password is expired (if applicable)
      if (user.tempPasswordExpiry && new Date() > user.tempPasswordExpiry) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'Temporary password has expired. Please contact an administrator.',
        });
      }

      // Hash the new password
      const hashedNewPassword = await bcrypt.hash(input.newPassword, 10);

      // Update user password and clear temporary password flags
      await ctx.prisma.user.update({
        where: { id: user.id },
        data: {
          password: hashedNewPassword,
          mustChangePassword: false,
          tempPasswordExpiry: null,
        },
      });

      return { success: true, message: 'Password changed successfully' };
    }),
});
