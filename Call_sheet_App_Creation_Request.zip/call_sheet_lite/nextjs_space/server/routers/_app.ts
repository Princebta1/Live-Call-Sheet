
import { router } from '../../lib/trpc';
import { authRouter } from './auth';
import { showsRouter } from './shows';
import { scenesRouter } from './scenes';
import { usersRouter } from './users';
import { companiesRouter } from './companies';
import { statsRouter } from './stats';
import { actorsRouter } from './actors';
import { announcementsRouter } from './announcements';
import { messagesRouter } from './messages';
import { actorScenesRouter } from './actor-scenes';
import { conversationsRouter } from './conversations';
import { callSheetRouter } from './call-sheet';
import { rolesRouter } from './roles';
import { permissionsRouter } from './permissions';

export const appRouter = router({
  auth: authRouter,
  shows: showsRouter,
  scenes: scenesRouter,
  users: usersRouter,
  companies: companiesRouter,
  stats: statsRouter,
  actors: actorsRouter,
  announcements: announcementsRouter,
  messages: messagesRouter,
  actorScenes: actorScenesRouter,
  conversations: conversationsRouter,
  callSheet: callSheetRouter,
  roles: rolesRouter,
  permissions: permissionsRouter,
});

export type AppRouter = typeof appRouter;
