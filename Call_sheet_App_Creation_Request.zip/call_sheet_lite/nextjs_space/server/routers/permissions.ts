
import { z } from 'zod';
import { router, protectedProcedure, developerProcedure } from '../../lib/trpc';
import { TRPCError } from '@trpc/server';
import { PermissionCategory } from '@prisma/client';

export const permissionsRouter = router({
  // List all permissions
  list: protectedProcedure.query(async ({ ctx }) => {
    return await ctx.prisma.permission.findMany({
      orderBy: [{ category: 'asc' }, { key: 'asc' }],
    });
  }),

  // List permissions by category
  byCategory: protectedProcedure
    .input(z.object({ category: z.nativeEnum(PermissionCategory) }))
    .query(async ({ ctx, input }) => {
      return await ctx.prisma.permission.findMany({
        where: { category: input.category },
        orderBy: { key: 'asc' },
      });
    }),

  // Get a specific permission by ID
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const permission = await ctx.prisma.permission.findUnique({
        where: { id: input.id },
      });

      if (!permission) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Permission not found' });
      }

      return permission;
    }),

  // Create a new permission (Developer only)
  create: developerProcedure
    .input(
      z.object({
        category: z.nativeEnum(PermissionCategory),
        key: z.string().min(1).regex(/^[a-z]+\.[a-z]+\.[a-z]+$/, 'Key must be in format: category.resource.action'),
        name: z.string().min(1),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if permission key already exists
      const existingPermission = await ctx.prisma.permission.findUnique({
        where: { key: input.key },
      });

      if (existingPermission) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'A permission with this key already exists',
        });
      }

      const permission = await ctx.prisma.permission.create({
        data: input,
      });

      return permission;
    }),

  // Update a permission (Developer only)
  update: developerProcedure
    .input(
      z.object({
        id: z.string(),
        name: z.string().min(1).optional(),
        description: z.string().optional().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...updateData } = input;

      const permission = await ctx.prisma.permission.update({
        where: { id },
        data: updateData,
      });

      return permission;
    }),

  // Delete a permission (Developer only)
  delete: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await ctx.prisma.permission.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Get permissions for a user (includes both system role and custom role permissions)
  getUserPermissions: protectedProcedure
    .input(z.object({ userId: z.string().optional() }))
    .query(async ({ ctx, input }) => {
      const userId = input.userId || ctx.session.user.id;

      const user = await ctx.prisma.user.findUnique({
        where: { id: userId },
        include: {
          customRole: {
            include: {
              rolePermissions: {
                include: {
                  permission: true,
                },
              },
            },
          },
        },
      });

      if (!user) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
      }

      const permissions: string[] = [];

      // Add custom role permissions if user has a custom role
      if (user.customRole) {
        user.customRole.rolePermissions.forEach((rp) => {
          permissions.push(rp.permission.key);
        });
      }

      // Add system role permissions
      // DEVELOPER gets all permissions
      if (user.role === 'DEVELOPER') {
        permissions.push('*'); // Wildcard for all permissions
      }

      return {
        userId: user.id,
        role: user.role,
        customRole: user.customRole?.name,
        permissions,
      };
    }),
});
