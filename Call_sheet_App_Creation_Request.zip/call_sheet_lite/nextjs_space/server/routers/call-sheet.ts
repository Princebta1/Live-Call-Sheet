
import { z } from 'zod';
import { router, protectedProcedure } from '../../lib/trpc';
import { prisma } from '../../lib/db';
import { TRPCError } from '@trpc/server';

export const callSheetRouter = router({
  // Generate call sheet data for a show based on date range
  generate: protectedProcedure
    .input(
      z.object({
        showId: z.string(),
        startDate: z.string(), // ISO date string
        endDate: z.string(),   // ISO date string
      })
    )
    .query(async ({ ctx, input }) => {
      // Verify user has access to this show
      const show = await prisma.show.findUnique({
        where: { id: input.showId },
        include: {
          company: {
            select: {
              id: true,
              name: true,
              logoUrl: true,
            },
          },
          creator: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }

      // Check user access
      const user = await prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      const hasAccess =
        user?.role === 'DEVELOPER' ||
        (user?.role === 'ADMIN' && user.companyId === show.companyId) ||
        (user?.role === 'PRODUCTION_ADMIN' && user.assignedShowId === show.id) ||
        show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have access to this show',
        });
      }

      // Fetch scenes within the date range
      const startDate = new Date(input.startDate);
      const endDate = new Date(input.endDate);
      endDate.setHours(23, 59, 59, 999); // Include the entire end date

      const scenes = await prisma.scene.findMany({
        where: {
          showId: input.showId,
          scheduledDate: {
            gte: startDate,
            lte: endDate,
          },
        },
        include: {
          sceneActors: {
            include: {
              actor: true,
            },
          },
        },
        orderBy: [
          { scheduledDate: 'asc' },
          { sceneNumber: 'asc' },
        ],
      });

      // Group scenes by date
      const scenesByDate: Record<string, typeof scenes> = {};
      
      scenes.forEach((scene) => {
        if (scene.scheduledDate) {
          const dateKey = scene.scheduledDate.toISOString().split('T')[0];
          if (!scenesByDate[dateKey]) {
            scenesByDate[dateKey] = [];
          }
          scenesByDate[dateKey].push(scene);
        }
      });

      // Get all unique actors
      const actorIds = new Set<string>();
      scenes.forEach((scene) => {
        scene.sceneActors.forEach((sa) => {
          actorIds.add(sa.actorId);
        });
      });

      const actors = await prisma.actor.findMany({
        where: {
          id: {
            in: Array.from(actorIds),
          },
        },
      });

      return {
        show: {
          id: show.id,
          title: show.title,
          description: show.description,
          status: show.status,
          company: show.company,
        },
        dateRange: {
          start: startDate,
          end: endDate,
        },
        scenesByDate,
        totalScenes: scenes.length,
        actors,
      };
    }),
});
