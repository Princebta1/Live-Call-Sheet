
import { z } from 'zod';
import { router, protectedProcedure, adminOrProductionAdminProcedure } from '../../lib/trpc';
import { TRPCError } from '@trpc/server';
import { sendSceneCreatedEmail, sendSceneUpdatedEmail } from '../../lib/email';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const scenesRouter = router({
  create: adminOrProductionAdminProcedure
    .input(
      z.object({
        showId: z.string(),
        sceneNumber: z.string(),
        name: z.string().min(1),
        description: z.string().nullable().optional(),
        estimatedDuration: z.number().nullable().optional(),
        scheduledDate: z.string().nullable().optional(),
        status: z.string().optional(),
        actorIds: z.array(z.string()).min(1, 'At least one actor must be assigned to the scene'),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create scenes
      const canCreateScene = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.SCENES.CREATE);
      if (!canCreateScene) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create scenes',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      // Verify user has access to this show
      const show = await ctx.prisma.show.findUnique({
        where: { id: input.showId },
        select: {
          id: true,
          companyId: true,
          creatorId: true,
        },
      });

      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === show.id) ||
        show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to add scenes to this show',
        });
      }

      // Create scene with actor assignments
      const { actorIds, ...sceneData } = input;
      const scene = await ctx.prisma.scene.create({
        data: {
          ...sceneData,
          scheduledDate: input.scheduledDate ? new Date(input.scheduledDate) : null,
          sceneActors: {
            create: actorIds.map((actorId) => ({
              actorId,
            })),
          },
        },
        include: {
          sceneActors: {
            include: {
              actor: true,
            },
          },
          show: {
            select: {
              title: true,
            },
          },
        },
      });

      // Send email notifications to assigned actors
      if (scene.sceneActors && scene.sceneActors.length > 0) {
        try {
          // Filter out actors without email addresses
          const actorsWithEmail = scene.sceneActors
            .filter(sa => sa.actor.email)
            .map(sa => ({
              name: sa.actor.name,
              email: sa.actor.email as string,
            }));

          if (actorsWithEmail.length > 0) {
            await sendSceneCreatedEmail({
              sceneName: scene.name,
              sceneNumber: scene.sceneNumber,
              showTitle: scene.show.title,
              scheduledDate: scene.scheduledDate,
              estimatedDuration: scene.estimatedDuration,
              description: scene.description || undefined,
              actors: actorsWithEmail,
            });
          }
        } catch (emailError) {
          console.error('Failed to send scene created email:', emailError);
          // Don't throw - scene was created successfully
        }
      }

      return scene;
    }),

  update: adminOrProductionAdminProcedure
    .input(
      z.object({
        id: z.string(),
        sceneNumber: z.string().optional(),
        name: z.string().min(1).optional(),
        description: z.string().nullable().optional(),
        estimatedDuration: z.number().nullable().optional(),
        scheduledDate: z.string().nullable().optional(),
        status: z.string().optional(),
        actorIds: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit scenes
      const canEditScene = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.SCENES.EDIT);
      if (!canEditScene) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit scenes',
        });
      }

      const { id, scheduledDate, actorIds, ...data } = input;

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      // Verify the scene exists and get show info
      const scene = await ctx.prisma.scene.findUnique({
        where: { id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to update this scene',
        });
      }

      // Validate actorIds if provided
      if (actorIds !== undefined && actorIds.length === 0) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'At least one actor must be assigned to the scene',
        });
      }

      // Track what changed for email notification
      const changes: string[] = [];
      if (data.name && data.name !== scene.name) {
        changes.push(`Scene name changed to "${data.name}"`);
      }
      if (scheduledDate !== undefined) {
        const oldDate = scene.scheduledDate ? new Date(scene.scheduledDate).toLocaleDateString() : 'Unscheduled';
        const newDate = scheduledDate ? new Date(scheduledDate).toLocaleDateString() : 'Unscheduled';
        if (oldDate !== newDate) {
          changes.push(`Scheduled date changed to ${newDate}`);
        }
      }
      if (data.estimatedDuration !== undefined && data.estimatedDuration !== scene.estimatedDuration) {
        changes.push(`Estimated duration updated to ${data.estimatedDuration} minutes`);
      }
      if (data.status && data.status !== scene.status) {
        changes.push(`Status changed to ${data.status}`);
      }
      if (actorIds !== undefined) {
        changes.push('Cast members updated');
      }

      // Update scene and optionally update actor assignments
      const updatedScene = await ctx.prisma.scene.update({
        where: { id },
        data: {
          ...data,
          scheduledDate: scheduledDate !== undefined 
            ? (scheduledDate ? new Date(scheduledDate) : null)
            : undefined,
          ...(actorIds !== undefined && {
            sceneActors: {
              deleteMany: {}, // Remove all existing assignments
              create: actorIds.map((actorId) => ({
                actorId,
              })),
            },
          }),
        },
        include: {
          sceneActors: {
            include: {
              actor: true,
            },
          },
          show: {
            select: {
              title: true,
            },
          },
        },
      });

      // Send email notifications if there were changes
      if (changes.length > 0 && updatedScene.sceneActors && updatedScene.sceneActors.length > 0) {
        try {
          // Filter out actors without email addresses
          const actorsWithEmail = updatedScene.sceneActors
            .filter(sa => sa.actor.email)
            .map(sa => ({
              name: sa.actor.name,
              email: sa.actor.email as string,
            }));

          if (actorsWithEmail.length > 0) {
            await sendSceneUpdatedEmail({
              sceneName: updatedScene.name,
              sceneNumber: updatedScene.sceneNumber,
              showTitle: updatedScene.show.title,
              scheduledDate: updatedScene.scheduledDate,
              estimatedDuration: updatedScene.estimatedDuration,
              description: updatedScene.description || undefined,
              actors: actorsWithEmail,
              changes,
            });
          }
        } catch (emailError) {
          console.error('Failed to send scene updated email:', emailError);
          // Don't throw - scene was updated successfully
        }
      }

      return updatedScene;
    }),

  delete: adminOrProductionAdminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete scenes
      const canDeleteScene = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.SCENES.DELETE);
      if (!canDeleteScene) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete scenes',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      // Verify the scene exists and get show info
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete this scene',
        });
      }

      await ctx.prisma.scene.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Timer operations - all authenticated users can use timers
  startTimer: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to control scene timers
      const canControlTimers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.SCENE_TIMERS);
      if (!canControlTimers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to control scene timers',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to access this scene',
        });
      }

      if (scene.status === 'In Progress') {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Timer is already running',
        });
      }

      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.id },
        data: {
          status: 'In Progress',
          timerStartedAt: new Date(),
          timerPausedAt: null,
        },
      });

      return updatedScene;
    }),

  pauseTimer: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to control scene timers
      const canControlTimers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.SCENE_TIMERS);
      if (!canControlTimers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to control scene timers',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to access this scene',
        });
      }

      if (scene.status !== 'In Progress' || !scene.timerStartedAt) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Timer is not running',
        });
      }

      const now = new Date();
      const elapsedSinceStart = Math.floor(
        (now.getTime() - scene.timerStartedAt.getTime()) / 1000
      );

      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.id },
        data: {
          status: 'Paused',
          timerPausedAt: now,
          actualElapsedTime: scene.actualElapsedTime + elapsedSinceStart,
        },
      });

      return updatedScene;
    }),

  resumeTimer: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to control scene timers
      const canControlTimers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.SCENE_TIMERS);
      if (!canControlTimers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to control scene timers',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to access this scene',
        });
      }

      if (scene.status !== 'Paused' || !scene.timerPausedAt) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Timer is not paused',
        });
      }

      const now = new Date();
      const pauseDuration = Math.floor(
        (now.getTime() - scene.timerPausedAt.getTime()) / 1000
      );

      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.id },
        data: {
          status: 'In Progress',
          timerStartedAt: now,
          timerPausedAt: null,
          accumulatedPauseTime: scene.accumulatedPauseTime + pauseDuration,
        },
      });

      return updatedScene;
    }),

  stopTimer: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to control scene timers
      const canControlTimers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.SCENE_TIMERS);
      if (!canControlTimers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to control scene timers',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to access this scene',
        });
      }

      if (scene.status !== 'In Progress' || !scene.timerStartedAt) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Timer is not running',
        });
      }

      const now = new Date();
      const elapsedSinceStart = Math.floor(
        (now.getTime() - scene.timerStartedAt.getTime()) / 1000
      );

      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.id },
        data: {
          status: 'Completed',
          timerStartedAt: null,
          timerPausedAt: null,
          actualElapsedTime: scene.actualElapsedTime + elapsedSinceStart,
        },
      });

      return updatedScene;
    }),

  resetTimer: adminOrProductionAdminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to control scene timers
      const canControlTimers = await hasPermission(ctx.session.user.id, PermissionKeys.CONTENT.SCENE_TIMERS);
      if (!canControlTimers) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to control scene timers',
        });
      }

      // Get current user info
      const currentUser = await ctx.prisma.user.findUnique({
        where: { id: ctx.session.user.id },
        select: { role: true, companyId: true, assignedShowId: true },
      });

      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: { 
          show: {
            select: {
              id: true,
              companyId: true,
              creatorId: true,
            }
          }
        },
      });

      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }

      // Check permissions
      const hasAccess =
        currentUser?.role === 'DEVELOPER' ||
        (currentUser?.role === 'ADMIN' && currentUser.companyId === scene.show.companyId) ||
        (currentUser?.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId === scene.show.id) ||
        scene.show.creatorId === ctx.session.user.id;

      if (!hasAccess) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to reset this scene timer',
        });
      }

      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.id },
        data: {
          status: 'Not Started',
          timerStartedAt: null,
          timerPausedAt: null,
          actualElapsedTime: 0,
          accumulatedPauseTime: 0,
        },
      });

      return updatedScene;
    }),
});
