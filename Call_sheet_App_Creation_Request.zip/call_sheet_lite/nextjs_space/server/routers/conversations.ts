import { z } from 'zod';
import { router, protectedProcedure } from '../../lib/trpc';
import { prisma } from '../../lib/db';
import { TRPCError } from '@trpc/server';

export const conversationsRouter = router({
  // Get available contacts based on user permissions
  getAvailableContacts: protectedProcedure.query(async ({ ctx }) => {
    const currentUser = await prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true, companyId: true, assignedShowId: true, email: true },
    });

    if (!currentUser) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
    }

    let whereClause: any = {
      id: { not: ctx.session.user.id }, // Exclude self
      isActive: true,
    };

    // DEVELOPER can message anyone
    if (currentUser.role === 'DEVELOPER') {
      // No additional restrictions
    }
    // ADMIN can message users in their company + actors/crew
    else if (currentUser.role === 'ADMIN' && currentUser.companyId) {
      whereClause.OR = [
        { companyId: currentUser.companyId },
        { role: 'ACTOR' },
        { role: 'CREW' },
      ];
    }
    // PRODUCTION_ADMIN can message users in their show + actors/crew
    else if (currentUser.role === 'PRODUCTION_ADMIN' && currentUser.assignedShowId) {
      whereClause.OR = [
        { assignedShowId: currentUser.assignedShowId },
        { role: 'ACTOR' },
        { role: 'CREW' },
      ];
    }
    // CREW and ACTOR can message users from shows they're involved in
    else if (currentUser.role === 'CREW' || currentUser.role === 'ACTOR') {
      // Find all shows the user is associated with
      const userShows = await prisma.show.findMany({
        where: {
          OR: [
            { creatorId: ctx.session.user.id },
            { productionAdmins: { some: { id: ctx.session.user.id } } },
          ],
        },
        select: { id: true, companyId: true },
      });

      // For actors, also find shows where they have scenes
      let actorShowIds: string[] = [];
      if (currentUser.role === 'ACTOR') {
        const actor = await prisma.actor.findFirst({
          where: { email: currentUser.email },
          include: {
            sceneActors: {
              select: { scene: { select: { showId: true } } },
            },
          },
        });
        if (actor) {
          actorShowIds = [...new Set(actor.sceneActors.map(sa => sa.scene.showId))];
        }
      }

      const allShowIds = [...new Set([...userShows.map(s => s.id), ...actorShowIds])];
      const companyIds = [...new Set(userShows.map(s => s.companyId).filter(Boolean))];

      if (allShowIds.length === 0 && companyIds.length === 0) {
        return []; // No accessible shows/companies
      }

      whereClause.OR = [
        { assignedShowId: { in: allShowIds } },
        { companyId: { in: companyIds } },
        { createdShows: { some: { id: { in: allShowIds } } } },
      ];
    }

    const users = await prisma.user.findMany({
      where: whereClause,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
      },
      orderBy: { name: 'asc' },
    });

    return users;
  }),

  // List all conversations for the current user
  list: protectedProcedure.query(async ({ ctx }) => {
    const conversations = await prisma.conversation.findMany({
      where: {
        participants: {
          some: { userId: ctx.session.user.id },
        },
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
                role: true,
              },
            },
          },
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1,
          include: {
            sender: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: { updatedAt: 'desc' },
    });

    return conversations.map(conv => ({
      ...conv,
      otherParticipants: conv.participants.filter(p => p.userId !== ctx.session.user.id),
      lastMessage: conv.messages[0] || null,
      unreadCount: conv.messages.filter(m => m.senderId !== ctx.session.user.id && !m.isRead).length,
    }));
  }),

  // Get or create a conversation with a specific user
  getOrCreate: protectedProcedure
    .input(z.object({ otherUserId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check if conversation already exists
      const existingConversation = await prisma.conversation.findFirst({
        where: {
          AND: [
            { participants: { some: { userId: ctx.session.user.id } } },
            { participants: { some: { userId: input.otherUserId } } },
          ],
        },
        include: {
          participants: {
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                  role: true,
                },
              },
            },
          },
        },
      });

      if (existingConversation) {
        return existingConversation;
      }

      // Verify the other user is in the available contacts list
      const availableContacts = await prisma.user.findFirst({
        where: { id: input.otherUserId },
      });

      if (!availableContacts) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to message this user',
        });
      }

      // Create new conversation
      const conversation = await prisma.conversation.create({
        data: {
          participants: {
            create: [
              { userId: ctx.session.user.id },
              { userId: input.otherUserId },
            ],
          },
        },
        include: {
          participants: {
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                  role: true,
                },
              },
            },
          },
        },
      });

      return conversation;
    }),

  // Get conversation by ID with messages
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const conversation = await prisma.conversation.findFirst({
        where: {
          id: input.id,
          participants: {
            some: { userId: ctx.session.user.id },
          },
        },
        include: {
          participants: {
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                  role: true,
                },
              },
            },
          },
          messages: {
            include: {
              sender: {
                select: {
                  id: true,
                  name: true,
                  role: true,
                },
              },
            },
            orderBy: { createdAt: 'asc' },
          },
        },
      });

      if (!conversation) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Conversation not found',
        });
      }

      return conversation;
    }),

  // Send a message in a conversation
  sendMessage: protectedProcedure
    .input(
      z.object({
        conversationId: z.string(),
        content: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify user is part of the conversation
      const conversation = await prisma.conversation.findFirst({
        where: {
          id: input.conversationId,
          participants: {
            some: { userId: ctx.session.user.id },
          },
        },
      });

      if (!conversation) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You are not part of this conversation',
        });
      }

      const message = await prisma.directMessage.create({
        data: {
          conversationId: input.conversationId,
          senderId: ctx.session.user.id,
          content: input.content,
        },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
      });

      // Update conversation's updatedAt
      await prisma.conversation.update({
        where: { id: input.conversationId },
        data: { updatedAt: new Date() },
      });

      return message;
    }),

  // Mark messages as read
  markAsRead: protectedProcedure
    .input(z.object({ conversationId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await prisma.directMessage.updateMany({
        where: {
          conversationId: input.conversationId,
          senderId: { not: ctx.session.user.id },
          isRead: false,
        },
        data: { isRead: true },
      });

      return { success: true };
    }),
});
