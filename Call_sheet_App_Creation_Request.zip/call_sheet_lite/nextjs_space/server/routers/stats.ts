
import { router, protectedProcedure, developerProcedure } from '../../lib/trpc';
import { Role } from '@prisma/client';

export const statsRouter = router({
  // Get overall stats (accessible to all authenticated users)
  overall: protectedProcedure.query(async ({ ctx }) => {
    const user = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true, companyId: true, assignedShowId: true },
    });

    if (!user) {
      return null;
    }

    // Base filter based on role
    let showFilter: any = {};
    
    if (user.role === Role.ADMIN && user.companyId) {
      // Admins see stats for their company's shows
      showFilter = { companyId: user.companyId };
    } else if (user.role === Role.PRODUCTION_ADMIN && user.assignedShowId) {
      // Production Admins see stats for their assigned show
      showFilter = { id: user.assignedShowId };
    } else if (user.role === Role.DEVELOPER) {
      // Developers see all stats
      showFilter = {};
    } else {
      // Crew and Actors see shows they created
      showFilter = { creatorId: ctx.session.user.id };
    }

    // Get counts
    const [totalShows, totalScenes, totalUsers, totalCompanies] = await Promise.all([
      ctx.prisma.show.count({ where: showFilter }),
      ctx.prisma.scene.count({
        where: {
          show: showFilter,
        },
      }),
      user.role === Role.DEVELOPER ? ctx.prisma.user.count() : Promise.resolve(null),
      user.role === Role.DEVELOPER ? ctx.prisma.company.count() : Promise.resolve(null),
    ]);

    // Get scene stats
    const sceneStats = await ctx.prisma.scene.groupBy({
      by: ['status'],
      where: {
        show: showFilter,
      },
      _count: {
        status: true,
      },
    });

    // Get show stats
    const showStats = await ctx.prisma.show.groupBy({
      by: ['status'],
      where: showFilter,
      _count: {
        status: true,
      },
    });

    // Calculate total production time
    const totalProductionTime = await ctx.prisma.scene.aggregate({
      where: {
        show: showFilter,
      },
      _sum: {
        actualElapsedTime: true,
        estimatedDuration: true,
      },
    });

    // Get recent scenes
    const recentScenes = await ctx.prisma.scene.findMany({
      where: {
        show: showFilter,
        status: {
          in: ['In Progress', 'Completed'],
        },
      },
      include: {
        show: {
          select: {
            id: true,
            title: true,
          },
        },
      },
      orderBy: {
        updatedAt: 'desc',
      },
      take: 5,
    });

    return {
      totalShows,
      totalScenes,
      totalUsers,
      totalCompanies,
      sceneStats: sceneStats.map(s => ({
        status: s.status,
        count: s._count.status,
      })),
      showStats: showStats.map(s => ({
        status: s.status,
        count: s._count.status,
      })),
      totalActualTime: totalProductionTime._sum.actualElapsedTime || 0,
      totalEstimatedTime: totalProductionTime._sum.estimatedDuration || 0,
      recentScenes,
    };
  }),

  // Get user stats (Developer only)
  users: developerProcedure.query(async ({ ctx }) => {
    const usersByRole = await ctx.prisma.user.groupBy({
      by: ['role'],
      _count: {
        role: true,
      },
    });

    return usersByRole.map(u => ({
      role: u.role,
      count: u._count.role,
    }));
  }),

  // Get company stats
  companies: protectedProcedure.query(async ({ ctx }) => {
    const user = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true },
    });

    if (!user || (user.role !== Role.DEVELOPER && user.role !== Role.ADMIN)) {
      return [];
    }

    const companies = await ctx.prisma.company.findMany({
      select: {
        id: true,
        name: true,
        _count: {
          select: {
            shows: true,
            admins: true,
          },
        },
      },
    });

    return companies;
  }),
});
