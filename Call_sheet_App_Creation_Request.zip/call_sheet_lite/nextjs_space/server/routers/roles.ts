
import { z } from 'zod';
import { router, protectedProcedure, developerProcedure, adminOrProductionAdminProcedure } from '../../lib/trpc';
import { TRPCError } from '@trpc/server';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const rolesRouter = router({
  // List all custom roles
  list: protectedProcedure.query(async ({ ctx }) => {
    const currentUser = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true },
    });

    if (!currentUser) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
    }

    // All authenticated users can see active roles
    return await ctx.prisma.customRole.findMany({
      where: { isActive: true },
      include: {
        rolePermissions: {
          include: {
            permission: true,
          },
        },
        _count: {
          select: { users: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }),

  // Get a specific role by ID
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const role = await ctx.prisma.customRole.findUnique({
        where: { id: input.id },
        include: {
          rolePermissions: {
            include: {
              permission: true,
            },
          },
          users: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
      });

      if (!role) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Role not found' });
      }

      return role;
    }),

  // Create a new custom role
  create: adminOrProductionAdminProcedure
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        permissionIds: z.array(z.string()).min(1, 'At least one permission is required'),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create roles
      const canCreateRole = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ROLES.CREATE);
      if (!canCreateRole) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create roles',
        });
      }

      // Check if role name already exists
      const existingRole = await ctx.prisma.customRole.findUnique({
        where: { name: input.name },
      });

      if (existingRole) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'A role with this name already exists',
        });
      }

      // Create the role and its permissions in a transaction
      const role = await ctx.prisma.$transaction(async (prisma) => {
        const newRole = await prisma.customRole.create({
          data: {
            name: input.name,
            description: input.description,
            createdById: ctx.session.user.id,
          },
        });

        // Create role-permission associations
        await prisma.rolePermission.createMany({
          data: input.permissionIds.map((permissionId) => ({
            roleId: newRole.id,
            permissionId,
          })),
        });

        return newRole;
      });

      return role;
    }),

  // Update an existing custom role
  update: adminOrProductionAdminProcedure
    .input(
      z.object({
        id: z.string(),
        name: z.string().min(1).optional(),
        description: z.string().optional().nullable(),
        permissionIds: z.array(z.string()).optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit roles
      const canEditRole = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ROLES.EDIT);
      if (!canEditRole) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit roles',
        });
      }

      const { id, permissionIds, ...updateData } = input;

      // Check if role exists
      const existingRole = await ctx.prisma.customRole.findUnique({
        where: { id },
      });

      if (!existingRole) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Role not found' });
      }

      // If updating name, check for conflicts
      if (updateData.name && updateData.name !== existingRole.name) {
        const nameConflict = await ctx.prisma.customRole.findUnique({
          where: { name: updateData.name },
        });

        if (nameConflict) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'A role with this name already exists',
          });
        }
      }

      // Update role and permissions in a transaction
      const role = await ctx.prisma.$transaction(async (prisma) => {
        const updatedRole = await prisma.customRole.update({
          where: { id },
          data: updateData,
        });

        // If permissionIds provided, update role permissions
        if (permissionIds) {
          // Delete existing permissions
          await prisma.rolePermission.deleteMany({
            where: { roleId: id },
          });

          // Create new permissions
          if (permissionIds.length > 0) {
            await prisma.rolePermission.createMany({
              data: permissionIds.map((permissionId) => ({
                roleId: id,
                permissionId,
              })),
            });
          }
        }

        return updatedRole;
      });

      return role;
    }),

  // Delete a custom role
  delete: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete roles
      const canDeleteRole = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ROLES.DELETE);
      if (!canDeleteRole) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete roles',
        });
      }

      // Check if role has users
      const roleWithUsers = await ctx.prisma.customRole.findUnique({
        where: { id: input.id },
        include: {
          _count: {
            select: { users: true },
          },
        },
      });

      if (!roleWithUsers) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Role not found' });
      }

      if (roleWithUsers._count.users > 0) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: 'Cannot delete role with assigned users. Please reassign users first.',
        });
      }

      await ctx.prisma.customRole.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Toggle role active status
  toggleActive: developerProcedure
    .input(z.object({ id: z.string(), isActive: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit roles (toggle is an edit operation)
      const canEditRole = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ROLES.EDIT);
      if (!canEditRole) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to toggle role status',
        });
      }

      const role = await ctx.prisma.customRole.update({
        where: { id: input.id },
        data: { isActive: input.isActive },
      });

      return role;
    }),
});
