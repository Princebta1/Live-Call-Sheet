
import { z } from 'zod';
import { router, protectedProcedure, adminOrProductionAdminProcedure } from '../../lib/trpc';
import { prisma } from '../../lib/db';
import { TRPCError } from '@trpc/server';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const actorsRouter = router({
  // List actors for a show
  list: protectedProcedure
    .input(z.object({ showId: z.string() }))
    .query(async ({ input }) => {
      return await prisma.actor.findMany({
        where: { showId: input.showId },
        include: {
          assignedProductionAdmin: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
        orderBy: { name: 'asc' },
      });
    }),

  // Get actor by ID
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const actor = await prisma.actor.findUnique({
        where: { id: input.id },
        include: { show: true },
      });
      
      if (!actor) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Actor not found' });
      }
      
      return actor;
    }),

  // Create actor (ADMIN, PRODUCTION_ADMIN, DEVELOPER only)
  create: adminOrProductionAdminProcedure
    .input(
      z.object({
        showId: z.string(),
        assignedProductionAdminId: z.string(),
        name: z.string().min(1),
        role: z.string().min(1),
        character: z.string().optional().nullable(),
        email: z.string().email().optional().nullable(),
        phone: z.string().optional().nullable(),
        photoUrl: z.string().optional().nullable(),
        notes: z.string().optional().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create actors
      const canCreateActor = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ACTORS.CREATE);
      if (!canCreateActor) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create actors',
        });
      }


      return await prisma.actor.create({
        data: input,
        include: {
          assignedProductionAdmin: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
      });
    }),

  // Update actor
  update: adminOrProductionAdminProcedure
    .input(
      z.object({
        id: z.string(),
        assignedProductionAdminId: z.string().optional(),
        name: z.string().min(1).optional(),
        role: z.string().min(1).optional(),
        character: z.string().optional().nullable(),
        email: z.string().email().optional().nullable(),
        phone: z.string().optional().nullable(),
        photoUrl: z.string().optional().nullable(),
        notes: z.string().optional().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit actors
      const canEditActor = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ACTORS.EDIT);
      if (!canEditActor) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit actors',
        });
      }

      const { id, ...data } = input;
      
      return await prisma.actor.update({
        where: { id },
        data,
        include: {
          assignedProductionAdmin: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
      });
    }),

  // Delete actor
  delete: adminOrProductionAdminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete actors
      const canDeleteActor = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ACTORS.DELETE);
      if (!canDeleteActor) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete actors',
        });
      }

      return await prisma.actor.delete({
        where: { id: input.id },
      });
    }),
});
