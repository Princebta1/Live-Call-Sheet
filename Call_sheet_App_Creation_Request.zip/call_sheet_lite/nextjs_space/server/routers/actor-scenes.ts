import { z } from 'zod';
import { router, protectedProcedure } from '../../lib/trpc';
import { prisma } from '../../lib/db';
import { TRPCError } from '@trpc/server';

export const actorScenesRouter = router({
  // Get scenes for logged-in actor
  myScenes: protectedProcedure.query(async ({ ctx }) => {
    const user = await prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true, email: true },
    });

    if (user?.role !== 'ACTOR') {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: 'Only actors can access this',
      });
    }

    // Find actor record by matching email
    const actor = await prisma.actor.findFirst({
      where: { email: user.email },
      include: {
        sceneActors: {
          include: {
            scene: {
              include: {
                show: true,
              },
            },
          },
        },
      },
    });

    if (!actor) {
      return [];
    }

    return actor.sceneActors.map((sa) => sa.scene);
  }),

  // Get upcoming scenes (call sheet)
  callSheet: protectedProcedure.query(async ({ ctx }) => {
    const user = await prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true, email: true },
    });

    if (user?.role !== 'ACTOR') {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: 'Only actors can access this',
      });
    }

    const actor = await prisma.actor.findFirst({
      where: { email: user.email },
      include: {
        sceneActors: {
          include: {
            scene: {
              include: {
                show: true,
              },
            },
          },
          where: {
            scene: {
              scheduledDate: {
                gte: new Date(),
              },
              status: {
                in: ['Not Started', 'In Progress'],
              },
            },
          },
          orderBy: {
            scene: {
              scheduledDate: 'asc',
            },
          },
        },
      },
    });

    if (!actor) {
      return [];
    }

    return actor.sceneActors.map((sa) => sa.scene);
  }),
});
