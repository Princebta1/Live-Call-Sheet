
import { z } from 'zod';
import { router, adminProcedure, protectedProcedure, developerProcedure } from '../../lib/trpc';
import { TRPCError } from '@trpc/server';
import { Role } from '@prisma/client';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const companiesRouter = router({
  // List all companies (filter by active status for non-developers)
  list: protectedProcedure.query(async ({ ctx }) => {
    const user = await ctx.prisma.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true },
    });

    const whereClause: any = user?.role === Role.DEVELOPER ? {} : { isActive: true };

    const companies = await ctx.prisma.company.findMany({
      where: whereClause,
      include: {
        _count: {
          select: {
            admins: true,
            shows: true,
          },
        },
        admins: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return companies;
  }),

  // Get company by ID
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const company = await ctx.prisma.company.findUnique({
        where: { id: input.id },
        include: {
          admins: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
          shows: {
            select: {
              id: true,
              title: true,
              status: true,
              _count: {
                select: { scenes: true },
              },
            },
          },
        },
      });

      if (!company) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Company not found',
        });
      }

      return company;
    }),

  // Create company (Developer only - must assign an admin)
  create: developerProcedure
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        logoUrl: z.string().optional(),
        adminId: z.string(), // Required - every company must have an admin
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create companies
      const canCreateCompany = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.COMPANIES.CREATE);
      if (!canCreateCompany) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create companies',
        });
      }

      // Verify the admin user exists and has ADMIN role
      const adminUser = await ctx.prisma.user.findUnique({
        where: { id: input.adminId },
        select: { role: true, companyId: true },
      });

      if (!adminUser) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Admin user not found',
        });
      }

      if (adminUser.role !== Role.ADMIN) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Selected user must have ADMIN role',
        });
      }

      if (adminUser.companyId) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Admin is already assigned to another company',
        });
      }

      const company = await ctx.prisma.company.create({
        data: {
          name: input.name,
          description: input.description,
          logoUrl: input.logoUrl,
          isActive: true,
          admins: {
            connect: { id: input.adminId },
          },
        },
        include: {
          admins: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      return company;
    }),

  // Update company (Admin or Developer only)
  update: adminProcedure
    .input(
      z.object({
        id: z.string(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        logoUrl: z.string().nullable().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit companies
      const canEditCompany = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.COMPANIES.EDIT);
      if (!canEditCompany) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit companies',
        });
      }

      const { id, ...data } = input;

      const company = await ctx.prisma.company.findUnique({
        where: { id },
      });

      if (!company) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Company not found',
        });
      }

      const updatedCompany = await ctx.prisma.company.update({
        where: { id },
        data,
      });

      return updatedCompany;
    }),

  // Delete company (Developer only)
  delete: developerProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete companies
      const canDeleteCompany = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.COMPANIES.DELETE);
      if (!canDeleteCompany) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete companies',
        });
      }

      const company = await ctx.prisma.company.findUnique({
        where: { id: input.id },
      });

      if (!company) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Company not found',
        });
      }

      await ctx.prisma.company.delete({
        where: { id: input.id },
      });

      return { success: true };
    }),

  // Toggle company active status (Developer only)
  toggleActive: developerProcedure
    .input(z.object({ id: z.string(), isActive: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit companies (toggle is an edit operation)
      const canEditCompany = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.COMPANIES.EDIT);
      if (!canEditCompany) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to toggle company status',
        });
      }

      const company = await ctx.prisma.company.update({
        where: { id: input.id },
        data: { isActive: input.isActive },
      });

      return company;
    }),

  // Create company for user approval (Developer only)
  // This allows creating a company without immediately assigning an admin
  createForApproval: developerProcedure
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to create companies
      const canCreateCompany = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.COMPANIES.CREATE);
      if (!canCreateCompany) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create companies',
        });
      }

      const company = await ctx.prisma.company.create({
        data: {
          name: input.name,
          description: input.description,
          isActive: true,
        },
      });

      return company;
    }),
});
