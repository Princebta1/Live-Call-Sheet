
import { z } from 'zod';
import { router, protectedProcedure, adminOrProductionAdminProcedure } from '../../lib/trpc';
import { prisma } from '../../lib/db';
import { TRPCError } from '@trpc/server';
import { hasPermission, PermissionKeys } from '../../lib/permissions';

export const announcementsRouter = router({
  // List announcements for a show
  list: protectedProcedure
    .input(z.object({ showId: z.string() }))
    .query(async ({ input }) => {
      return await prisma.announcement.findMany({
        where: { showId: input.showId },
        include: {
          createdBy: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    }),

  // Get announcement by ID
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const announcement = await prisma.announcement.findUnique({
        where: { id: input.id },
        include: {
          show: true,
          createdBy: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
      });
      
      if (!announcement) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Announcement not found' });
      }
      
      return announcement;
    }),

  // Create announcement (ADMIN, PRODUCTION_ADMIN, DEVELOPER only)
  create: adminOrProductionAdminProcedure
    .input(
      z.object({
        showId: z.string(),
        title: z.string().min(1),
        content: z.string().min(1),
        priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Check permission to create announcements
      const canCreateAnnouncement = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ANNOUNCEMENTS.CREATE);
      if (!canCreateAnnouncement) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to create announcements',
        });
      }

      return await prisma.announcement.create({
        data: {
          ...input,
          createdById: ctx.session.user.id,
        },
        include: {
          createdBy: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
      });
    }),

  // Update announcement
  update: adminOrProductionAdminProcedure
    .input(
      z.object({
        id: z.string(),
        title: z.string().min(1).optional(),
        content: z.string().min(1).optional(),
        priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check permission to edit announcements
      const canEditAnnouncement = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ANNOUNCEMENTS.EDIT);
      if (!canEditAnnouncement) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to edit announcements',
        });
      }

      const { id, ...data } = input;
      
      return await prisma.announcement.update({
        where: { id },
        data,
        include: {
          createdBy: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
      });
    }),

  // Delete announcement
  delete: adminOrProductionAdminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // Check permission to delete announcements
      const canDeleteAnnouncement = await hasPermission(ctx.session.user.id, PermissionKeys.FEATURES.ANNOUNCEMENTS.DELETE);
      if (!canDeleteAnnouncement) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have permission to delete announcements',
        });
      }

      return await prisma.announcement.delete({
        where: { id: input.id },
      });
    }),
});
