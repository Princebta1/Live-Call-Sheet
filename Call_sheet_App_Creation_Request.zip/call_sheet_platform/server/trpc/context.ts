
import { inferAsyncReturnType } from '@trpc/server';
import { CreateExpressContextOptions } from '@trpc/server/adapters/express';
import { verifyToken, JWTPayload } from '../utils/auth';
import { prisma } from '../db';

export async function createContext({ req, res }: CreateExpressContextOptions) {
  // Get token from header
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  let user: JWTPayload | null = null;
  
  if (token) {
    try {
      user = verifyToken(token);
    } catch (error) {
      // Token invalid or expired
      user = null;
    }
  }
  
  return {
    req,
    res,
    user,
    prisma,
  };
}

export type Context = inferAsyncReturnType<typeof createContext>;
