
import { router, protectedProcedure } from '../trpc';

export const dashboardRouter = router({
  stats: protectedProcedure.query(async ({ ctx }) => {
    // Get shows stats
    const [totalShows, activeShows, wrappedShows] = await Promise.all([
      ctx.prisma.show.count(),
      ctx.prisma.show.count({ where: { status: 'SHOOTING' } }),
      ctx.prisma.show.count({ where: { status: 'WRAPPED' } }),
    ]);
    
    // Get scenes stats
    const [totalScenes, unshotScenes, inProgressScenes, completeScenes, activeTimers] = await Promise.all([
      ctx.prisma.scene.count(),
      ctx.prisma.scene.count({ where: { status: 'UNSHOT' } }),
      ctx.prisma.scene.count({ where: { status: 'IN_PROGRESS' } }),
      ctx.prisma.scene.count({ where: { status: 'COMPLETE' } }),
      ctx.prisma.scene.count({ where: { isTimerRunning: true } }),
    ]);
    
    // Get recent shows
    const recentShows = await ctx.prisma.show.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: { scenes: true },
        },
      },
    });
    
    // Get scenes with active timers
    const activeScenesWithTimers = await ctx.prisma.scene.findMany({
      where: { isTimerRunning: true },
      include: {
        show: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });
    
    return {
      shows: {
        total: totalShows,
        active: activeShows,
        wrapped: wrappedShows,
      },
      scenes: {
        total: totalScenes,
        unshot: unshotScenes,
        inProgress: inProgressScenes,
        complete: completeScenes,
        activeTimers,
      },
      recentShows: recentShows.map(show => ({
        ...show,
        sceneCount: show._count.scenes,
      })),
      activeScenesWithTimers,
    };
  }),
});
