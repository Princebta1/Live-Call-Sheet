
import { router, protectedProcedure, adminOrADProcedure } from '../trpc';
import { z } from 'zod';
import { TRPCError } from '@trpc/server';

export const showsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const shows = await ctx.prisma.show.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: { scenes: true },
        },
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    });
    
    return shows.map(show => ({
      ...show,
      sceneCount: show._count.scenes,
    }));
  }),
  
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const show = await ctx.prisma.show.findUnique({
        where: { id: input.id },
        include: {
          createdBy: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
          _count: {
            select: { scenes: true },
          },
        },
      });
      
      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }
      
      return {
        ...show,
        sceneCount: show._count.scenes,
      };
    }),
    
  create: adminOrADProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        status: z.enum(['PRE_PRODUCTION', 'SHOOTING', 'WRAPPED']).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const show = await ctx.prisma.show.create({
        data: {
          title: input.title,
          description: input.description,
          startDate: input.startDate ? new Date(input.startDate) : null,
          endDate: input.endDate ? new Date(input.endDate) : null,
          status: input.status || 'PRE_PRODUCTION',
          createdById: ctx.user.userId,
        },
        include: {
          createdBy: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });
      
      return show;
    }),
    
  update: adminOrADProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        description: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        status: z.enum(['PRE_PRODUCTION', 'SHOOTING', 'WRAPPED']).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      
      // Check if show exists
      const show = await ctx.prisma.show.findUnique({
        where: { id },
      });
      
      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }
      
      // Update show
      const updatedShow = await ctx.prisma.show.update({
        where: { id },
        data: {
          ...data,
          startDate: data.startDate ? new Date(data.startDate) : undefined,
          endDate: data.endDate ? new Date(data.endDate) : undefined,
        },
        include: {
          createdBy: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });
      
      return updatedShow;
    }),
    
  delete: adminOrADProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Check if show exists
      const show = await ctx.prisma.show.findUnique({
        where: { id: input.id },
      });
      
      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }
      
      // Delete show (cascades to scenes)
      await ctx.prisma.show.delete({
        where: { id: input.id },
      });
      
      return { success: true };
    }),
    
  stats: protectedProcedure.query(async ({ ctx }) => {
    const [totalShows, activeShows, wrappedShows] = await Promise.all([
      ctx.prisma.show.count(),
      ctx.prisma.show.count({
        where: { status: 'SHOOTING' },
      }),
      ctx.prisma.show.count({
        where: { status: 'WRAPPED' },
      }),
    ]);
    
    return {
      total: totalShows,
      active: activeShows,
      wrapped: wrappedShows,
    };
  }),
});
