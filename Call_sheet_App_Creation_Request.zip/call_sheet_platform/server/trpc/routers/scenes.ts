
import { router, protectedProcedure, adminOrADProcedure } from '../trpc';
import { z } from 'zod';
import { TRPCError } from '@trpc/server';

export const scenesRouter = router({
  list: protectedProcedure
    .input(z.object({ showId: z.number() }))
    .query(async ({ ctx, input }) => {
      const scenes = await ctx.prisma.scene.findMany({
        where: { showId: input.showId },
        orderBy: { sceneNumber: 'asc' },
        include: {
          show: {
            select: {
              id: true,
              title: true,
            },
          },
        },
      });
      
      return scenes;
    }),
    
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
        include: {
          show: {
            select: {
              id: true,
              title: true,
            },
          },
          timerLogs: {
            orderBy: { timestamp: 'desc' },
            take: 10,
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      return scene;
    }),
    
  create: adminOrADProcedure
    .input(
      z.object({
        showId: z.number(),
        sceneNumber: z.string().min(1),
        title: z.string().min(1),
        description: z.string().optional(),
        location: z.string().optional(),
        scheduledTime: z.string().optional(),
        notes: z.string().optional(),
        assignedActors: z.string().optional(),
        assignedCrew: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if show exists
      const show = await ctx.prisma.show.findUnique({
        where: { id: input.showId },
      });
      
      if (!show) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Show not found',
        });
      }
      
      // Check if scene number already exists for this show
      const existingScene = await ctx.prisma.scene.findUnique({
        where: {
          showId_sceneNumber: {
            showId: input.showId,
            sceneNumber: input.sceneNumber,
          },
        },
      });
      
      if (existingScene) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Scene number already exists for this show',
        });
      }
      
      // Create scene
      const scene = await ctx.prisma.scene.create({
        data: {
          showId: input.showId,
          sceneNumber: input.sceneNumber,
          title: input.title,
          description: input.description,
          location: input.location,
          scheduledTime: input.scheduledTime ? new Date(input.scheduledTime) : null,
          notes: input.notes,
          assignedActors: input.assignedActors,
          assignedCrew: input.assignedCrew,
        },
        include: {
          show: {
            select: {
              id: true,
              title: true,
            },
          },
        },
      });
      
      return scene;
    }),
    
  update: adminOrADProcedure
    .input(
      z.object({
        id: z.number(),
        sceneNumber: z.string().min(1).optional(),
        title: z.string().min(1).optional(),
        description: z.string().optional(),
        location: z.string().optional(),
        scheduledTime: z.string().optional(),
        status: z.enum(['UNSHOT', 'IN_PROGRESS', 'COMPLETE']).optional(),
        notes: z.string().optional(),
        assignedActors: z.string().optional(),
        assignedCrew: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      
      // Check if scene exists
      const scene = await ctx.prisma.scene.findUnique({
        where: { id },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      // Update scene
      const updatedScene = await ctx.prisma.scene.update({
        where: { id },
        data: {
          ...data,
          scheduledTime: data.scheduledTime ? new Date(data.scheduledTime) : undefined,
        },
        include: {
          show: {
            select: {
              id: true,
              title: true,
            },
          },
        },
      });
      
      return updatedScene;
    }),
    
  delete: adminOrADProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Check if scene exists
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.id },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      // Delete scene
      await ctx.prisma.scene.delete({
        where: { id: input.id },
      });
      
      return { success: true };
    }),
    
  stats: protectedProcedure
    .input(z.object({ showId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      const where = input.showId ? { showId: input.showId } : {};
      
      const [total, unshot, inProgress, complete, activeTimers] = await Promise.all([
        ctx.prisma.scene.count({ where }),
        ctx.prisma.scene.count({ where: { ...where, status: 'UNSHOT' } }),
        ctx.prisma.scene.count({ where: { ...where, status: 'IN_PROGRESS' } }),
        ctx.prisma.scene.count({ where: { ...where, status: 'COMPLETE' } }),
        ctx.prisma.scene.count({ where: { ...where, isTimerRunning: true } }),
      ]);
      
      return {
        total,
        unshot,
        inProgress,
        complete,
        activeTimers,
      };
    }),
});
