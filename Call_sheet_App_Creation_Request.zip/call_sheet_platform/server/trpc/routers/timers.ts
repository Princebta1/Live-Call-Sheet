
import { router, adminOrADProcedure, protectedProcedure } from '../trpc';
import { z } from 'zod';
import { TRPCError } from '@trpc/server';

export const timersRouter = router({
  start: adminOrADProcedure
    .input(z.object({ sceneId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.sceneId },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      if (scene.isTimerRunning) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Timer is already running for this scene',
        });
      }
      
      const now = new Date();
      
      // Start or resume timer
      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.sceneId },
        data: {
          timerStart: scene.timerStart || now,
          timerPausedAt: null,
          isTimerRunning: true,
          status: 'IN_PROGRESS',
        },
      });
      
      // Log the action
      await ctx.prisma.timerLog.create({
        data: {
          sceneId: input.sceneId,
          userId: ctx.user.userId,
          action: scene.timerStart ? 'RESUME' : 'START',
          timestamp: now,
        },
      });
      
      return updatedScene;
    }),
    
  pause: adminOrADProcedure
    .input(z.object({ sceneId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.sceneId },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      if (!scene.isTimerRunning) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Timer is not running for this scene',
        });
      }
      
      const now = new Date();
      
      // Calculate elapsed time since start/resume
      const elapsedMs = scene.timerStart 
        ? now.getTime() - scene.timerStart.getTime()
        : 0;
      
      // Update accumulated time
      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.sceneId },
        data: {
          timerPausedAt: now,
          timerAccumulatedMs: scene.timerAccumulatedMs + elapsedMs,
          isTimerRunning: false,
        },
      });
      
      // Log the action
      await ctx.prisma.timerLog.create({
        data: {
          sceneId: input.sceneId,
          userId: ctx.user.userId,
          action: 'PAUSE',
          timestamp: now,
        },
      });
      
      return updatedScene;
    }),
    
  stop: adminOrADProcedure
    .input(z.object({ sceneId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.sceneId },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      const now = new Date();
      
      // Calculate total duration
      let totalMs = scene.timerAccumulatedMs;
      
      if (scene.isTimerRunning && scene.timerStart) {
        const currentElapsed = now.getTime() - scene.timerStart.getTime();
        totalMs += currentElapsed;
      }
      
      const totalSeconds = Math.floor(totalMs / 1000);
      
      // Stop timer and record duration
      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.sceneId },
        data: {
          timerStart: null,
          timerPausedAt: null,
          timerAccumulatedMs: 0,
          isTimerRunning: false,
          durationSeconds: totalSeconds,
          status: 'COMPLETE',
        },
      });
      
      // Log the action
      await ctx.prisma.timerLog.create({
        data: {
          sceneId: input.sceneId,
          userId: ctx.user.userId,
          action: 'STOP',
          timestamp: now,
          notes: `Duration: ${totalSeconds}s`,
        },
      });
      
      return updatedScene;
    }),
    
  reset: adminOrADProcedure
    .input(z.object({ sceneId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.sceneId },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      // Reset timer
      const updatedScene = await ctx.prisma.scene.update({
        where: { id: input.sceneId },
        data: {
          timerStart: null,
          timerPausedAt: null,
          timerAccumulatedMs: 0,
          isTimerRunning: false,
          durationSeconds: null,
          status: 'UNSHOT',
        },
      });
      
      return updatedScene;
    }),
    
  getCurrentTime: protectedProcedure
    .input(z.object({ sceneId: z.number() }))
    .query(async ({ ctx, input }) => {
      const scene = await ctx.prisma.scene.findUnique({
        where: { id: input.sceneId },
      });
      
      if (!scene) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Scene not found',
        });
      }
      
      let totalMs = scene.timerAccumulatedMs;
      
      if (scene.isTimerRunning && scene.timerStart) {
        const now = new Date();
        const currentElapsed = now.getTime() - scene.timerStart.getTime();
        totalMs += currentElapsed;
      }
      
      const totalSeconds = Math.floor(totalMs / 1000);
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      
      return {
        totalSeconds,
        hours,
        minutes,
        seconds,
        isRunning: scene.isTimerRunning,
        formatted: `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`,
      };
    }),
    
  getLogs: protectedProcedure
    .input(z.object({ sceneId: z.number() }))
    .query(async ({ ctx, input }) => {
      const logs = await ctx.prisma.timerLog.findMany({
        where: { sceneId: input.sceneId },
        orderBy: { timestamp: 'desc' },
        include: {
          user: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });
      
      return logs;
    }),
});
