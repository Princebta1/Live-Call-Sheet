
import { router } from './trpc';
import { authRouter } from './routers/auth';
import { usersRouter } from './routers/users';
import { showsRouter } from './routers/shows';
import { scenesRouter } from './routers/scenes';
import { timersRouter } from './routers/timers';
import { dashboardRouter } from './routers/dashboard';

export const appRouter = router({
  auth: authRouter,
  users: usersRouter,
  shows: showsRouter,
  scenes: scenesRouter,
  timers: timersRouter,
  dashboard: dashboardRouter,
});

export type AppRouter = typeof appRouter;
