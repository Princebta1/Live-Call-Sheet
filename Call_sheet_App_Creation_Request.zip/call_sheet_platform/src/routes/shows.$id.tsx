
import { createFileRoute, useNavigate, redirect } from '@tanstack/react-router';
import { DashboardLayout } from '../components/DashboardLayout';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import { Plus, ArrowLeft, Clock, CheckCircle2 } from 'lucide-react';
import { Loading } from '../components/Loading';
import { formatDate, formatDuration } from '../lib/utils';
import { useState } from 'react';
import toast from 'react-hot-toast';

export const Route = createFileRoute('/shows/$id')({
  beforeLoad: () => {
    const { isAuthenticated } = useAuthStore.getState();
    if (!isAuthenticated()) {
      throw redirect({ to: '/login' });
    }
  },
  component: ShowDetailPage,
});

function ShowDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { hasRole } = useAuthStore();
  const [showCreateSceneModal, setShowCreateSceneModal] = useState(false);
  
  const showId = parseInt(id);
  
  const { data: show, isLoading: showLoading } = trpc.shows.getById.useQuery({ id: showId });
  const { data: scenes, isLoading: scenesLoading, refetch } = trpc.scenes.list.useQuery({ showId });
  
  if (showLoading || scenesLoading) {
    return (
      <DashboardLayout>
        <Loading />
      </DashboardLayout>
    );
  }
  
  if (!show) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <p className="text-gray-500">Show not found</p>
        </div>
      </DashboardLayout>
    );
  }
  
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'UNSHOT':
        return 'status-unshot';
      case 'IN_PROGRESS':
        return 'status-in-progress';
      case 'COMPLETE':
        return 'status-complete';
      default:
        return 'badge-gray';
    }
  };
  
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <button
            onClick={() => navigate({ to: '/shows' })}
            className="btn-ghost mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Shows
          </button>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-100">{show.title}</h1>
              {show.description && (
                <p className="mt-2 text-gray-500">{show.description}</p>
              )}
              <div className="mt-4 flex items-center gap-4 text-sm text-gray-500">
                {show.startDate && (
                  <div>Start: {formatDate(show.startDate)}</div>
                )}
                {show.endDate && (
                  <div>End: {formatDate(show.endDate)}</div>
                )}
                <div className="badge badge-info">
                  {show.status.replace('_', ' ')}
                </div>
              </div>
            </div>
            
            {hasRole(['ADMIN', 'AD']) && (
              <button
                onClick={() => setShowCreateSceneModal(true)}
                className="btn-primary"
              >
                <Plus className="h-4 w-4" />
                Add Scene
              </button>
            )}
          </div>
        </div>
        
        {/* Scenes */}
        <div className="card">
          <h2 className="mb-4 text-lg font-semibold text-gray-200">
            Scenes ({scenes?.length ?? 0})
          </h2>
          
          {scenes && scenes.length > 0 ? (
            <div className="space-y-3">
              {scenes.map((scene) => (
                <div
                  key={scene.id}
                  onClick={() => navigate({ to: `/scenes/${scene.id}` })}
                  className="flex cursor-pointer items-center justify-between rounded-lg bg-cinematic-dark p-4 transition-colors hover:bg-gray-800"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-sm text-gray-500">
                        Scene {scene.sceneNumber}
                      </span>
                      <span className={`badge ${getStatusBadgeClass(scene.status)}`}>
                        {scene.status.replace('_', ' ')}
                      </span>
                      {scene.isTimerRunning && (
                        <div className="flex items-center gap-1 text-gold-500">
                          <Clock className="h-4 w-4 animate-pulse" />
                          <span className="text-xs">Running</span>
                        </div>
                      )}
                    </div>
                    <p className="mt-1 font-medium text-gray-200">{scene.title}</p>
                    {scene.location && (
                      <p className="mt-1 text-sm text-gray-500">{scene.location}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    {scene.durationSeconds && (
                      <div className="flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                        {formatDuration(scene.durationSeconds)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">No scenes yet</p>
          )}
        </div>
      </div>
      
      {/* Create Scene Modal */}
      {showCreateSceneModal && (
        <CreateSceneModal
          showId={showId}
          onClose={() => setShowCreateSceneModal(false)}
          onSuccess={() => {
            refetch();
            setShowCreateSceneModal(false);
          }}
        />
      )}
    </DashboardLayout>
  );
}

function CreateSceneModal({
  showId,
  onClose,
  onSuccess,
}: {
  showId: number;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [sceneNumber, setSceneNumber] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  
  const createMutation = trpc.scenes.create.useMutation({
    onSuccess: () => {
      toast.success('Scene created successfully');
      onSuccess();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      showId,
      sceneNumber,
      title,
      description: description || undefined,
      location: location || undefined,
      scheduledTime: scheduledTime || undefined,
    });
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="card w-full max-w-md">
        <h2 className="mb-4 text-xl font-bold text-gray-100">Create Scene</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Scene Number *</label>
            <input
              type="text"
              value={sceneNumber}
              onChange={(e) => setSceneNumber(e.target.value)}
              className="input"
              placeholder="1A"
              required
            />
          </div>
          
          <div>
            <label className="label">Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="input"
              required
            />
          </div>
          
          <div>
            <label className="label">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="textarea"
              rows={2}
            />
          </div>
          
          <div>
            <label className="label">Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="input"
            />
          </div>
          
          <div>
            <label className="label">Scheduled Time</label>
            <input
              type="datetime-local"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              className="input"
            />
          </div>
          
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="btn-outline flex-1"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="btn-primary flex-1"
            >
              {createMutation.isPending ? 'Creating...' : 'Create Scene'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
