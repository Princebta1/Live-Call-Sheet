
import { createFileRoute, useNavigate, redirect } from '@tanstack/react-router';
import { DashboardLayout } from '../components/DashboardLayout';
import { SceneTimer } from '../components/SceneTimer';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import { ArrowLeft, MapPin, Calendar, FileText } from 'lucide-react';
import { Loading } from '../components/Loading';
import { formatDateTime, formatDuration } from '../lib/utils';

export const Route = createFileRoute('/scenes/$id')({
  beforeLoad: () => {
    const { isAuthenticated } = useAuthStore.getState();
    if (!isAuthenticated()) {
      throw redirect({ to: '/login' });
    }
  },
  component: SceneDetailPage,
});

function SceneDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  
  const sceneId = parseInt(id);
  
  const { data: scene, isLoading, refetch } = trpc.scenes.getById.useQuery({ id: sceneId });
  const { data: logs, refetch: refetchLogs } = trpc.timers.getLogs.useQuery({ sceneId });
  
  if (isLoading) {
    return (
      <DashboardLayout>
        <Loading />
      </DashboardLayout>
    );
  }
  
  if (!scene) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <p className="text-gray-500">Scene not found</p>
        </div>
      </DashboardLayout>
    );
  }
  
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'UNSHOT':
        return 'status-unshot';
      case 'IN_PROGRESS':
        return 'status-in-progress';
      case 'COMPLETE':
        return 'status-complete';
      default:
        return 'badge-gray';
    }
  };
  
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <button
            onClick={() => navigate({ to: `/shows/${scene.showId}` })}
            className="btn-ghost mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to {scene.show.title}
          </button>
          
          <div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-sm text-gray-500">
                Scene {scene.sceneNumber}
              </span>
              <span className={`badge ${getStatusBadgeClass(scene.status)}`}>
                {scene.status.replace('_', ' ')}
              </span>
            </div>
            <h1 className="mt-2 text-3xl font-bold text-gray-100">{scene.title}</h1>
          </div>
        </div>
        
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Scene Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Info Card */}
            <div className="card">
              <h2 className="mb-4 text-lg font-semibold text-gray-200">
                Scene Information
              </h2>
              
              <div className="space-y-4">
                {scene.description && (
                  <div>
                    <div className="mb-1 flex items-center gap-2 text-sm text-gray-500">
                      <FileText className="h-4 w-4" />
                      Description
                    </div>
                    <p className="text-gray-300">{scene.description}</p>
                  </div>
                )}
                
                {scene.location && (
                  <div>
                    <div className="mb-1 flex items-center gap-2 text-sm text-gray-500">
                      <MapPin className="h-4 w-4" />
                      Location
                    </div>
                    <p className="text-gray-300">{scene.location}</p>
                  </div>
                )}
                
                {scene.scheduledTime && (
                  <div>
                    <div className="mb-1 flex items-center gap-2 text-sm text-gray-500">
                      <Calendar className="h-4 w-4" />
                      Scheduled Time
                    </div>
                    <p className="text-gray-300">{formatDateTime(scene.scheduledTime)}</p>
                  </div>
                )}
                
                {scene.durationSeconds && (
                  <div>
                    <div className="mb-1 text-sm text-gray-500">
                      Final Duration
                    </div>
                    <p className="text-gray-300">{formatDuration(scene.durationSeconds)}</p>
                  </div>
                )}
                
                {scene.notes && (
                  <div>
                    <div className="mb-1 text-sm text-gray-500">Notes</div>
                    <p className="text-gray-300">{scene.notes}</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Timer Logs */}
            {logs && logs.length > 0 && (
              <div className="card">
                <h2 className="mb-4 text-lg font-semibold text-gray-200">
                  Timer History
                </h2>
                
                <div className="space-y-2">
                  {logs.map((log) => (
                    <div
                      key={log.id}
                      className="flex items-center justify-between rounded-lg bg-cinematic-dark p-3 text-sm"
                    >
                      <div>
                        <span className="font-medium text-gray-300">
                          {log.action}
                        </span>
                        <span className="ml-2 text-gray-500">
                          by {log.user.name}
                        </span>
                      </div>
                      <div className="text-gray-500">
                        {formatDateTime(log.timestamp)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Timer Sidebar */}
          <div>
            <SceneTimer
              sceneId={sceneId}
              initialStatus={scene.status}
              initialIsRunning={scene.isTimerRunning}
              onUpdate={() => {
                refetch();
                refetchLogs();
              }}
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
