
import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useState, useEffect } from 'react';
import { AuthLayout } from '../components/AuthLayout';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import toast from 'react-hot-toast';
import { LoadingSpinner } from '../components/Loading';

export const Route = createFileRoute('/login')({
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { setAuth, isAuthenticated } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: (data) => {
      setAuth(data.token, data.user);
      toast.success('Login successful!');
      navigate({ to: '/' });
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  useEffect(() => {
    if (isAuthenticated()) {
      navigate({ to: '/' });
    }
  }, [isAuthenticated, navigate]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ email, password });
  };
  
  return (
    <AuthLayout
      title="Welcome Back"
      subtitle="Sign in to your Call Sheet account"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input"
            placeholder="you@example.com"
            required
          />
        </div>
        
        <div>
          <label className="label" htmlFor="password">
            Password
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input"
            placeholder="••••••••"
            required
          />
        </div>
        
        <button
          type="submit"
          disabled={loginMutation.isPending}
          className="btn-primary w-full"
        >
          {loginMutation.isPending ? (
            <>
              <LoadingSpinner size="sm" />
              Signing in...
            </>
          ) : (
            'Sign In'
          )}
        </button>
      </form>
      
      <div className="mt-4 text-center text-sm text-gray-500">
        Don't have an account?{' '}
        <button
          onClick={() => navigate({ to: '/signup' })}
          className="text-gold-500 hover:text-gold-400"
        >
          Sign up
        </button>
      </div>
      
      <div className="mt-6 rounded-lg bg-blue-500/10 p-4 text-sm text-blue-400">
        <p className="font-medium">Test Credentials:</p>
        <p className="mt-1">Email: john@doe.com</p>
        <p>Password: johndoe123</p>
        <p className="mt-2 text-xs text-gray-500">(Admin account)</p>
      </div>
    </AuthLayout>
  );
}
