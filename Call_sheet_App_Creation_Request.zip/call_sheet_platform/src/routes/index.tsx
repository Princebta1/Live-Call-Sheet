
import { createFileRoute, useNavigate, redirect } from '@tanstack/react-router';
import { DashboardLayout } from '../components/DashboardLayout';
import { StatsCard } from '../components/StatsCard';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import { Film, Clapperboard, Clock, CheckCircle2, PlayCircle } from 'lucide-react';
import { Loading } from '../components/Loading';
import { formatDate } from '../lib/utils';

export const Route = createFileRoute('/')({
  beforeLoad: () => {
    const { isAuthenticated } = useAuthStore.getState();
    if (!isAuthenticated()) {
      throw redirect({ to: '/login' });
    }
  },
  component: DashboardPage,
});

function DashboardPage() {
  const navigate = useNavigate();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  
  if (isLoading) {
    return (
      <DashboardLayout>
        <Loading />
      </DashboardLayout>
    );
  }
  
  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-100">Dashboard</h1>
          <p className="mt-1 text-gray-500">
            Welcome to your production management platform
          </p>
        </div>
        
        {/* Stats Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Shows"
            value={stats?.shows?.total ?? 0}
            icon={Film}
            color="gold"
          />
          <StatsCard
            title="Active Shows"
            value={stats?.shows?.active ?? 0}
            icon={PlayCircle}
            color="blue"
          />
          <StatsCard
            title="Total Scenes"
            value={stats?.scenes?.total ?? 0}
            icon={Clapperboard}
            color="green"
          />
          <StatsCard
            title="Active Timers"
            value={stats?.scenes?.activeTimers ?? 0}
            icon={Clock}
            color="red"
          />
        </div>
        
        {/* Scene Stats */}
        <div className="card">
          <h2 className="mb-4 text-lg font-semibold text-gray-200">
            Scene Overview
          </h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg bg-cinematic-dark p-4">
              <p className="text-sm text-gray-500">Unshot</p>
              <p className="mt-1 text-2xl font-bold text-gray-400">
                {stats?.scenes?.unshot ?? 0}
              </p>
            </div>
            <div className="rounded-lg bg-cinematic-dark p-4">
              <p className="text-sm text-gray-500">In Progress</p>
              <p className="mt-1 text-2xl font-bold text-orange-400">
                {stats?.scenes?.inProgress ?? 0}
              </p>
            </div>
            <div className="rounded-lg bg-cinematic-dark p-4">
              <p className="text-sm text-gray-500">Complete</p>
              <p className="mt-1 text-2xl font-bold text-emerald-400">
                {stats?.scenes?.complete ?? 0}
              </p>
            </div>
          </div>
        </div>
        
        {/* Active Scenes with Timers */}
        {stats?.activeScenesWithTimers && stats.activeScenesWithTimers.length > 0 && (
          <div className="card">
            <h2 className="mb-4 text-lg font-semibold text-gray-200">
              Active Scene Timers
            </h2>
            <div className="space-y-3">
              {stats.activeScenesWithTimers.map((scene) => (
                <div
                  key={scene.id}
                  className="flex items-center justify-between rounded-lg bg-cinematic-dark p-4"
                >
                  <div>
                    <p className="font-medium text-gray-200">
                      Scene {scene.sceneNumber}: {scene.title}
                    </p>
                    <p className="text-sm text-gray-500">{scene.show.title}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 animate-pulse text-gold-500" />
                    <button
                      onClick={() => navigate({ to: `/scenes/${scene.id}` })}
                      className="btn-outline btn-sm"
                    >
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Recent Shows */}
        <div className="card">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-200">Recent Shows</h2>
            <button
              onClick={() => navigate({ to: '/shows' })}
              className="text-sm text-gold-500 hover:text-gold-400"
            >
              View all
            </button>
          </div>
          
          {stats?.recentShows && stats.recentShows.length > 0 ? (
            <div className="space-y-3">
              {stats.recentShows.map((show) => (
                <div
                  key={show.id}
                  onClick={() => navigate({ to: `/shows/${show.id}` })}
                  className="flex cursor-pointer items-center justify-between rounded-lg bg-cinematic-dark p-4 transition-colors hover:bg-gray-800"
                >
                  <div>
                    <p className="font-medium text-gray-200">{show.title}</p>
                    <p className="text-sm text-gray-500">
                      {show.sceneCount} scenes · {show.status.replace('_', ' ')}
                    </p>
                  </div>
                  <div className="text-sm text-gray-500">
                    {formatDate(show.createdAt)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">No shows yet</p>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
