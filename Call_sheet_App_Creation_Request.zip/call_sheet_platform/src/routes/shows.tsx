
import { createFileRoute, useNavigate, redirect } from '@tanstack/react-router';
import { DashboardLayout } from '../components/DashboardLayout';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import { Plus, Film, Calendar } from 'lucide-react';
import { Loading } from '../components/Loading';
import { formatDate } from '../lib/utils';
import { useState } from 'react';
import toast from 'react-hot-toast';

export const Route = createFileRoute('/shows')({
  beforeLoad: () => {
    const { isAuthenticated } = useAuthStore.getState();
    if (!isAuthenticated()) {
      throw redirect({ to: '/login' });
    }
  },
  component: ShowsPage,
});

function ShowsPage() {
  const navigate = useNavigate();
  const { hasRole } = useAuthStore();
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  const { data: shows, isLoading, refetch } = trpc.shows.list.useQuery();
  
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'PRE_PRODUCTION':
        return 'badge-info';
      case 'SHOOTING':
        return 'badge-warning';
      case 'WRAPPED':
        return 'badge-success';
      default:
        return 'badge-gray';
    }
  };
  
  const getStatusText = (status: string) => {
    return status.replace('_', ' ');
  };
  
  if (isLoading) {
    return (
      <DashboardLayout>
        <Loading />
      </DashboardLayout>
    );
  }
  
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-100">Shows</h1>
            <p className="mt-1 text-gray-500">Manage your productions</p>
          </div>
          
          {hasRole(['ADMIN', 'AD']) && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="btn-primary"
            >
              <Plus className="h-4 w-4" />
              Create Show
            </button>
          )}
        </div>
        
        {/* Shows Grid */}
        {shows && shows.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {shows.map((show) => (
              <div
                key={show.id}
                onClick={() => navigate({ to: `/shows/${show.id}` })}
                className="card cursor-pointer"
              >
                <div className="mb-4 flex items-start justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gold-500/10">
                    <Film className="h-6 w-6 text-gold-500" />
                  </div>
                  <span className={`badge ${getStatusBadgeClass(show.status)}`}>
                    {getStatusText(show.status)}
                  </span>
                </div>
                
                <h3 className="mb-2 text-lg font-semibold text-gray-200">
                  {show.title}
                </h3>
                
                {show.description && (
                  <p className="mb-4 line-clamp-2 text-sm text-gray-500">
                    {show.description}
                  </p>
                )}
                
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {show.startDate ? formatDate(show.startDate) : 'Not scheduled'}
                  </div>
                  <div>{show.sceneCount} scenes</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card text-center">
            <Film className="mx-auto h-12 w-12 text-gray-700" />
            <p className="mt-4 text-gray-500">No shows yet</p>
            {hasRole(['ADMIN', 'AD']) && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="btn-primary mt-4"
              >
                <Plus className="h-4 w-4" />
                Create Your First Show
              </button>
            )}
          </div>
        )}
      </div>
      
      {/* Create Show Modal */}
      {showCreateModal && (
        <CreateShowModal
          onClose={() => setShowCreateModal(false)}
          onSuccess={() => {
            refetch();
            setShowCreateModal(false);
          }}
        />
      )}
    </DashboardLayout>
  );
}

function CreateShowModal({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState<'PRE_PRODUCTION' | 'SHOOTING' | 'WRAPPED'>('PRE_PRODUCTION');
  
  const createMutation = trpc.shows.create.useMutation({
    onSuccess: () => {
      toast.success('Show created successfully');
      onSuccess();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      title,
      description: description || undefined,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
      status,
    });
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="card w-full max-w-md">
        <h2 className="mb-4 text-xl font-bold text-gray-100">Create Show</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="input"
              required
            />
          </div>
          
          <div>
            <label className="label">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="textarea"
              rows={3}
            />
          </div>
          
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="input"
              />
            </div>
            
            <div>
              <label className="label">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="input"
              />
            </div>
          </div>
          
          <div>
            <label className="label">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'PRE_PRODUCTION' | 'SHOOTING' | 'WRAPPED')}
              className="input"
            >
              <option value="PRE_PRODUCTION">Pre-Production</option>
              <option value="SHOOTING">Shooting</option>
              <option value="WRAPPED">Wrapped</option>
            </select>
          </div>
          
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="btn-outline flex-1"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="btn-primary flex-1"
            >
              {createMutation.isPending ? 'Creating...' : 'Create Show'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
