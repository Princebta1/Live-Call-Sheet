
import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useState, useEffect } from 'react';
import { AuthLayout } from '../components/AuthLayout';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import toast from 'react-hot-toast';
import { LoadingSpinner } from '../components/Loading';

export const Route = createFileRoute('/signup')({
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const { setAuth, isAuthenticated } = useAuthStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'ADMIN' | 'AD' | 'CREW'>('CREW');
  
  const signupMutation = trpc.auth.signup.useMutation({
    onSuccess: (data) => {
      setAuth(data.token, data.user);
      toast.success('Account created successfully!');
      navigate({ to: '/' });
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  useEffect(() => {
    if (isAuthenticated()) {
      navigate({ to: '/' });
    }
  }, [isAuthenticated, navigate]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    signupMutation.mutate({ name, email, password, role });
  };
  
  return (
    <AuthLayout
      title="Create Account"
      subtitle="Join the Call Sheet platform"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label" htmlFor="name">
            Full Name
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input"
            placeholder="John Doe"
            required
          />
        </div>
        
        <div>
          <label className="label" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input"
            placeholder="you@example.com"
            required
          />
        </div>
        
        <div>
          <label className="label" htmlFor="password">
            Password
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input"
            placeholder="••••••••"
            required
            minLength={6}
          />
        </div>
        
        <div>
          <label className="label" htmlFor="role">
            Role
          </label>
          <select
            id="role"
            value={role}
            onChange={(e) => setRole(e.target.value as 'ADMIN' | 'AD' | 'CREW')}
            className="input"
          >
            <option value="CREW">Crew</option>
            <option value="AD">Assistant Director (AD)</option>
            <option value="ADMIN">Admin</option>
          </select>
        </div>
        
        <button
          type="submit"
          disabled={signupMutation.isPending}
          className="btn-primary w-full"
        >
          {signupMutation.isPending ? (
            <>
              <LoadingSpinner size="sm" />
              Creating account...
            </>
          ) : (
            'Create Account'
          )}
        </button>
      </form>
      
      <div className="mt-4 text-center text-sm text-gray-500">
        Already have an account?{' '}
        <button
          onClick={() => navigate({ to: '/login' })}
          className="text-gold-500 hover:text-gold-400"
        >
          Sign in
        </button>
      </div>
    </AuthLayout>
  );
}
