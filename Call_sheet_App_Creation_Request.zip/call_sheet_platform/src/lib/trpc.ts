
import { createTRPCReact } from '@trpc/react-query';
import { httpBatchLink } from '@trpc/client';
import type { AppRouter } from '../../server/trpc/root';
import superjson from 'superjson';
import { useAuthStore } from '../stores/authStore';

export const trpc = createTRPCReact<AppRouter>();

export function getTRPCClient() {
  return trpc.createClient({
    transformer: superjson,
    links: [
      httpBatchLink({
        url: 'http://localhost:3001/api/trpc',
        headers() {
          const token = useAuthStore.getState().token;
          return token
            ? {
                authorization: `Bearer ${token}`,
              }
            : {};
        },
      }),
    ],
  });
}
