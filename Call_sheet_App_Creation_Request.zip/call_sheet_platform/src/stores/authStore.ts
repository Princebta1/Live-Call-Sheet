
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface User {
  id: number;
  name: string;
  email: string;
  role: 'ADMIN' | 'AD' | 'CREW';
}

interface AuthStore {
  token: string | null;
  user: User | null;
  setAuth: (token: string, user: User) => void;
  clearAuth: () => void;
  isAuthenticated: () => boolean;
  hasRole: (roles: string[]) => boolean;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      setAuth: (token: string, user: User) => set({ token, user }),
      clearAuth: () => set({ token: null, user: null }),
      isAuthenticated: () => {
        const state = get();
        return state.token !== null && state.user !== null;
      },
      hasRole: (roles: string[]) => {
        const state = get();
        return state.user ? roles.includes(state.user.role) : false;
      },
    }),
    {
      name: 'call-sheet-auth',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
