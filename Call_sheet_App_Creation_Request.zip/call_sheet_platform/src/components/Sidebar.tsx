
import { Film, LayoutDashboard, Users, LogOut, Clapperboard } from 'lucide-react';
import { useNavigate } from '@tanstack/react-router';
import { useAuthStore } from '../stores/authStore';
import toast from 'react-hot-toast';

export function Sidebar() {
  const navigate = useNavigate();
  const { user, clearAuth, hasRole } = useAuthStore();
  
  const handleLogout = () => {
    clearAuth();
    toast.success('Logged out successfully');
    navigate({ to: '/login' });
  };
  
  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { name: 'Shows', icon: Film, path: '/shows' },
    ...(hasRole(['ADMIN'])
      ? [{ name: 'Users', icon: Users, path: '/users' }]
      : []),
  ];
  
  return (
    <div className="flex h-screen w-64 flex-col border-r border-gray-800 bg-cinematic-gray">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-gray-800 px-6 py-4">
        <Clapperboard className="h-8 w-8 text-gold-500" />
        <div>
          <h1 className="text-lg font-bold text-gold-500">Call Sheet</h1>
          <p className="text-xs text-gray-500">v1.0</p>
        </div>
      </div>
      
      {/* User info */}
      <div className="border-b border-gray-800 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-500/10 text-gold-500">
            {user?.name?.charAt(0)?.toUpperCase()}
          </div>
          <div className="flex-1 overflow-hidden">
            <p className="truncate text-sm font-medium text-gray-200">
              {user?.name}
            </p>
            <p className="text-xs text-gray-500">{user?.role}</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 space-y-1 p-4">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => navigate({ to: item.path })}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-gray-400 transition-colors hover:bg-gray-800 hover:text-gray-200"
            >
              <Icon className="h-5 w-5" />
              {item.name}
            </button>
          );
        })}
      </nav>
      
      {/* Logout */}
      <div className="border-t border-gray-800 p-4">
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-red-400 transition-colors hover:bg-red-500/10 hover:text-red-300"
        >
          <LogOut className="h-5 w-5" />
          Logout
        </button>
      </div>
    </div>
  );
}
