
import { ReactNode } from 'react';
import { Clapperboard } from 'lucide-react';

interface AuthLayoutProps {
  children: ReactNode;
  title: string;
  subtitle?: string;
}

export function AuthLayout({ children, title, subtitle }: AuthLayoutProps) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-cinematic-darker px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gold-500/10">
            <Clapperboard className="h-10 w-10 text-gold-500" />
          </div>
          <h1 className="text-3xl font-bold text-gold-500">Call Sheet</h1>
          <p className="text-sm text-gray-500">Production Management Platform</p>
        </div>
        
        {/* Content */}
        <div className="card">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-100">{title}</h2>
            {subtitle && <p className="mt-1 text-sm text-gray-500">{subtitle}</p>}
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
