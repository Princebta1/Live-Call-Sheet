
import { useState, useEffect } from 'react';
import { Play, Pause, Square, RotateCcw, Clock } from 'lucide-react';
import { trpc } from '../lib/trpc';
import { useAuthStore } from '../stores/authStore';
import { formatDuration } from '../lib/utils';
import toast from 'react-hot-toast';

interface SceneTimerProps {
  sceneId: number;
  initialStatus: string;
  initialIsRunning: boolean;
  onUpdate?: () => void;
}

export function SceneTimer({
  sceneId,
  initialStatus,
  initialIsRunning,
  onUpdate,
}: SceneTimerProps) {
  const { hasRole } = useAuthStore();
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  
  const { data: currentTime, refetch } = trpc.timers.getCurrentTime.useQuery(
    { sceneId },
    {
      refetchInterval: initialIsRunning ? 1000 : false,
    }
  );
  
  const startMutation = trpc.timers.start.useMutation({
    onSuccess: () => {
      toast.success('Timer started');
      refetch();
      onUpdate?.();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  const pauseMutation = trpc.timers.pause.useMutation({
    onSuccess: () => {
      toast.success('Timer paused');
      refetch();
      onUpdate?.();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  const stopMutation = trpc.timers.stop.useMutation({
    onSuccess: () => {
      toast.success('Timer stopped and scene marked complete');
      refetch();
      onUpdate?.();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  const resetMutation = trpc.timers.reset.useMutation({
    onSuccess: () => {
      toast.success('Timer reset');
      refetch();
      onUpdate?.();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  
  useEffect(() => {
    if (currentTime) {
      setElapsedSeconds(currentTime.totalSeconds);
    }
  }, [currentTime]);
  
  const canControl = hasRole(['ADMIN', 'AD']);
  const isRunning = currentTime?.isRunning ?? initialIsRunning;
  
  return (
    <div className="rounded-lg border border-gray-800 bg-cinematic-gray p-6">
      <div className="mb-4 flex items-center gap-2">
        <Clock className="h-5 w-5 text-gold-500" />
        <h3 className="text-lg font-semibold text-gray-200">Scene Timer</h3>
      </div>
      
      {/* Timer Display */}
      <div className="mb-6 rounded-lg bg-cinematic-dark p-8 text-center">
        <div
          className={`text-5xl font-bold tabular-nums ${
            isRunning ? 'text-gold-500 animate-pulse-slow' : 'text-gray-400'
          }`}
        >
          {formatDuration(elapsedSeconds)}
        </div>
        <div className="mt-2 text-sm text-gray-500">
          {isRunning ? 'Running' : initialStatus === 'COMPLETE' ? 'Completed' : 'Stopped'}
        </div>
      </div>
      
      {/* Controls */}
      {canControl && (
        <div className="flex gap-2">
          {!isRunning && initialStatus !== 'COMPLETE' && (
            <button
              onClick={() => startMutation.mutate({ sceneId })}
              disabled={startMutation.isPending}
              className="btn-primary flex-1"
            >
              <Play className="h-4 w-4" />
              {elapsedSeconds > 0 ? 'Resume' : 'Start'}
            </button>
          )}
          
          {isRunning && (
            <>
              <button
                onClick={() => pauseMutation.mutate({ sceneId })}
                disabled={pauseMutation.isPending}
                className="btn-secondary flex-1"
              >
                <Pause className="h-4 w-4" />
                Pause
              </button>
              <button
                onClick={() => stopMutation.mutate({ sceneId })}
                disabled={stopMutation.isPending}
                className="btn-danger flex-1"
              >
                <Square className="h-4 w-4" />
                Stop
              </button>
            </>
          )}
          
          {!isRunning && elapsedSeconds > 0 && initialStatus !== 'COMPLETE' && (
            <button
              onClick={() => resetMutation.mutate({ sceneId })}
              disabled={resetMutation.isPending}
              className="btn-outline"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          )}
        </div>
      )}
      
      {!canControl && (
        <p className="text-center text-sm text-gray-500">
          Only Admins and ADs can control timers
        </p>
      )}
    </div>
  );
}
