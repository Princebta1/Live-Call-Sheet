
# 🚀 Call Sheet v1.0 - Deployment Guide

## Current Status

✅ **Application is running successfully!**

- Backend tRPC server: http://localhost:3001
- Frontend Vite dev server: http://localhost:3000
- Database: PostgreSQL (hosted)
- Test data: Seeded with 2 shows, 5 scenes, 1 active timer

## Quick Start

### 1. Start Backend Server

```bash
cd /home/ubuntu/call_sheet_platform
yarn dev:server
```

This starts the Express + tRPC server on port 3001.

### 2. Start Frontend Server

```bash
cd /home/ubuntu/call_sheet_platform
yarn dev:client
```

This starts the Vite development server on port 3000.

### 3. Access the Application

Open your browser and navigate to:
```
http://localhost:3000
```

### 4. Login

Use one of the test accounts:

**Admin:**
- Email: john@doe.com
- Password: johndoe123

**Assistant Director:**
- Email: sarah@example.com  
- Password: password123

**Crew:**
- Email: mike@example.com
- Password: password123

## Testing the Real-Time Timer Feature

1. Login as Admin or AD
2. Navigate to Dashboard
3. Click on "The Last Stand" show
4. Click on "Scene 2: Hero Introduction" (has an active timer)
5. Observe the real-time timer counting up
6. Test Pause/Resume/Stop controls

## Environment Variables

The application uses these environment variables (already configured):

```bash
DATABASE_URL="postgresql://..."  # Auto-provisioned PostgreSQL
JWT_SECRET="..."                  # JWT signing secret
PORT=3001                         # Backend server port
```

## Database Commands

```bash
# Push schema changes
yarn db:push

# Seed test data
yarn db:seed

# Open Prisma Studio (database GUI)
yarn db:studio
```

## Production Build

To create a production build:

```bash
# Build frontend
yarn build

# Preview production build
yarn preview
```

For production deployment, you would need to:
1. Set up a production PostgreSQL database
2. Configure environment variables
3. Build the frontend (`yarn build`)
4. Serve the built files with a web server (nginx, etc.)
5. Run the backend server with process management (PM2, systemd, etc.)

## Troubleshooting

### Port Already in Use

If ports 3000 or 3001 are already in use:

```bash
# Kill existing processes
pkill -f "vite"
pkill -f "tsx.*server"

# Or specify different ports
yarn vite --port 3002
PORT=3003 yarn dev:server
```

### Database Connection Issues

Ensure the DATABASE_URL in `.env` is correct and the database is accessible.

### Build Errors

Clear node_modules and reinstall:

```bash
rm -rf node_modules yarn.lock
yarn install
```

## Performance Notes

- The real-time timer uses polling (refetchInterval: 1000ms) which is acceptable for v1.0
- For production, consider WebSockets or Server-Sent Events for more efficient real-time updates
- Database queries are optimized with proper indexes and eager loading

## Security Notes

- JWT tokens expire after 30 days
- Passwords are hashed with bcrypt (10 rounds)
- Role-based access control enforced at API level
- CORS is enabled for development (configure for production)

## Support

For issues or questions, refer to the main README.md or check the application logs:
- Backend: Check server console output
- Frontend: Check browser console (F12)
