
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');
  
  // Clear existing data
  await prisma.timerLog.deleteMany();
  await prisma.scene.deleteMany();
  await prisma.show.deleteMany();
  await prisma.user.deleteMany();
  
  console.log('✅ Cleared existing data');
  
  // Create users
  const adminUser = await prisma.user.create({
    data: {
      name: 'John Doe',
      email: 'john@doe.com',
      passwordHash: bcrypt.hashSync('johndoe123', 10),
      role: 'ADMIN',
      isActive: true,
    },
  });
  
  const adUser = await prisma.user.create({
    data: {
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      passwordHash: bcrypt.hashSync('password123', 10),
      role: 'AD',
      isActive: true,
    },
  });
  
  const crewUser = await prisma.user.create({
    data: {
      name: 'Mike Wilson',
      email: 'mike@example.com',
      passwordHash: bcrypt.hashSync('password123', 10),
      role: 'CREW',
      isActive: true,
    },
  });
  
  console.log('✅ Created users:', {
    admin: adminUser.email,
    ad: adUser.email,
    crew: crewUser.email,
  });
  
  // Create shows
  const show1 = await prisma.show.create({
    data: {
      title: 'The Last Stand',
      description: 'An epic action thriller set in a post-apocalyptic world',
      startDate: new Date('2024-12-01'),
      endDate: new Date('2025-03-31'),
      status: 'SHOOTING',
      createdById: adminUser.id,
    },
  });
  
  const show2 = await prisma.show.create({
    data: {
      title: 'Midnight Dreams',
      description: 'A psychological drama exploring the depths of human consciousness',
      startDate: new Date('2025-02-01'),
      endDate: null,
      status: 'PRE_PRODUCTION',
      createdById: adminUser.id,
    },
  });
  
  console.log('✅ Created shows:', show1.title, show2.title);
  
  // Create scenes for show 1
  const scene1 = await prisma.scene.create({
    data: {
      showId: show1.id,
      sceneNumber: '1',
      title: 'Opening Sequence',
      description: 'Establishing shot of the wasteland',
      location: 'Desert Location A',
      scheduledTime: new Date('2024-12-05T09:00:00'),
      status: 'COMPLETE',
      durationSeconds: 3600,
      notes: 'Weather was perfect, completed ahead of schedule',
    },
  });
  
  const scene2 = await prisma.scene.create({
    data: {
      showId: show1.id,
      sceneNumber: '2',
      title: 'Hero Introduction',
      description: 'First appearance of the protagonist',
      location: 'Abandoned Building',
      scheduledTime: new Date('2024-12-06T10:00:00'),
      status: 'IN_PROGRESS',
      timerStart: new Date(Date.now() - 1800000), // Started 30 minutes ago
      isTimerRunning: true,
      notes: 'Complex lighting setup',
    },
  });
  
  const scene3 = await prisma.scene.create({
    data: {
      showId: show1.id,
      sceneNumber: '3',
      title: 'First Encounter',
      description: 'Protagonist meets the antagonist',
      location: 'City Ruins',
      scheduledTime: new Date('2024-12-07T14:00:00'),
      status: 'UNSHOT',
    },
  });
  
  const scene4 = await prisma.scene.create({
    data: {
      showId: show1.id,
      sceneNumber: '4',
      title: 'Chase Sequence',
      description: 'High-octane chase through the ruins',
      location: 'Highway Set',
      scheduledTime: new Date('2024-12-08T08:00:00'),
      status: 'UNSHOT',
    },
  });
  
  // Create scenes for show 2
  const scene5 = await prisma.scene.create({
    data: {
      showId: show2.id,
      sceneNumber: '1',
      title: 'Dream Opening',
      description: 'Surreal dream sequence',
      location: 'Studio Stage 1',
      scheduledTime: null,
      status: 'UNSHOT',
    },
  });
  
  console.log('✅ Created scenes:', scene1.sceneNumber, scene2.sceneNumber, scene3.sceneNumber, scene4.sceneNumber, scene5.sceneNumber);
  
  // Create timer logs
  await prisma.timerLog.create({
    data: {
      sceneId: scene1.id,
      userId: adUser.id,
      action: 'START',
      timestamp: new Date(Date.now() - 7200000),
    },
  });
  
  await prisma.timerLog.create({
    data: {
      sceneId: scene1.id,
      userId: adUser.id,
      action: 'STOP',
      timestamp: new Date(Date.now() - 3600000),
      notes: 'Duration: 3600s',
    },
  });
  
  await prisma.timerLog.create({
    data: {
      sceneId: scene2.id,
      userId: adUser.id,
      action: 'START',
      timestamp: new Date(Date.now() - 1800000),
    },
  });
  
  console.log('✅ Created timer logs');
  
  console.log('');
  console.log('✨ Database seeded successfully!');
  console.log('');
  console.log('📝 Test Credentials:');
  console.log('   Admin:');
  console.log('     Email: john@doe.com');
  console.log('     Password: johndoe123');
  console.log('');
  console.log('   Assistant Director:');
  console.log('     Email: sarah@example.com');
  console.log('     Password: password123');
  console.log('');
  console.log('   Crew:');
  console.log('     Email: mike@example.com');
  console.log('     Password: password123');
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
